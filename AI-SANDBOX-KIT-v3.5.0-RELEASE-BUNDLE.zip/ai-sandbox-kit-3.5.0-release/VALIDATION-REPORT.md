# AI Sandbox Kit v3.5.0 — independent build and validation report

**Date:** 20 November 2026  
**Release posture:** controlled-workload hardening candidate; not enterprise hostile-code production approved  
**Source basis:** locally available v3.4.0 MIT implementation, compared against the v3.3.0 archive inventory and the v3.3.0 README, policy, license-status and security documentation. The GitHub Actions runner could not be assigned to extract and execute the archive on a remote runner, so this is not a complete source-level diff or exhaustive v3.3.0 code audit. The v3.3.0 source was not copied because its `LICENSE_STATUS.md` explicitly states that no project licence was selected and redistribution rights were not granted.

## 1. Source and baseline evidence

- v3.3.0: private GitHub repository `Abhijeetjain4075/Ai-sandbox-kit`, archive `ai-sandbox-kit-v3.3.0-validated-candidate.zip`, 36 ZIP entries. GitHub blob SHA: `3e85979fd31fe1d2a8ce6cbc7ff15b479b9fd847` (Git blob identifier, not the archive SHA-256). The repository's `main` branch contains the archive and a one-line README, not an extracted source tree or a tagged release.
- v3.4.0: local archive `AI-SANDBOX-KIT-3.4.0.zip`, SHA-256 `2351ba0c6d17edbfa3f5dc37b4a8fb721fc0a24d1b3ac101142f8dd182a5074b`; test suite reproduced at 76 passing tests and one expected duplicate-ZIP warning.
- v3.5.0: new package based on the available v3.4.0 MIT source with targeted hardening described in `CHANGELOG.md` and `docs/VERSION-COMPARISON.md`.

## 2. v3.5.0 changes

1. Raw command arguments are no longer persisted in execution receipts or audit events. Receipts contain executable basename, argument count and SHA-256 of normalized argv. Receipt schema is v2; raw bounded stdout/stderr is returned to the caller but not persisted in the receipt.
2. Added no-follow descriptor-based live workspace byte and entry accounting before launch, during execution at 250 ms sampling intervals, and after the process stops. Byte accounting is sampled and may overshoot; it is not a hard filesystem quota.
3. Added compiled runtime and archive ceilings so user policy can tighten but not enlarge resource limits beyond the build's safety envelope.
4. Hardened policy loading with `O_NOFOLLOW`, regular-file identity checks, a 1 MiB bound, strict JSON duplicate-key rejection and stricter environment-variable names.
5. Reworked cgroup-v2 parent/child path handling to pin directory FDs with no-follow traversal; child attachment and cleanup use the pinned descriptors.
6. Improved supervisor cleanup on exceptions, timeouts, output overflow and workspace-accounting failure.
7. Streamed workspace archive payloads in bounded chunks rather than loading whole files into memory during snapshot and restore.
8. Release metadata now derives version from `VERSION`; reproducibility and package verification run on the generated 3.5.0 source ZIP.
9. Added a GitHub Actions CI workflow using a full-SHA-pinned checkout action, read-only repository permission, tests, compilation and double-build verification.

## 3. Executed validation

| Check | Result | Evidence / scope |
|---|---|---|
| `python -m pytest -q` | **85 passed** | 1 expected warning from an adversarial test that deliberately writes duplicate ZIP member names |
| `python -m compileall -q sandboxkit scripts tests` | Passed | All package, script and test Python files compiled |
| CLI `--version` | Passed | Reports `3.5.0` |
| CLI `doctor` | Passed | Reported `bwrap: null`, `strict_backend_available: false`, `cgroup_v2_writable: false`, `landlock_abi: 0`, `unshare` present |
| CLI `policy-check` | Passed | Default policy accepted |
| strict-mode negative test | Passed (fail-closed) | Run returned exit 2: `bubblewrap (bwrap) is not installed; strict mode refuses an unisolated fallback`; task payload did not run |
| Wheel build + isolated install | Passed | `ai_sandbox_kit-3.5.0-py3-none-any.whl`, 38,009 bytes, SHA-256 `1852fb3fd9b39ba57efd1c0835c48ac94b6d5ac8a693a5e7006c97bffbb46987`; installed into a clean virtual environment, CLI reports `3.5.0`, default policy check passes and `pip check` reports no broken requirements |
| Source ZIP build A/B | Passed | Final two independent builds were byte-identical; the exact SHA-256 is in the adjacent `.zip.sha256` sidecar (kept outside the ZIP to avoid a self-referential checksum) |
| Release verifier | Passed | 47 ZIP entries, 45 manifest files, 45 SPDX file records, SHA-256 sidecar and unsigned local provenance structure checked |
| Unit-test coverage areas | Passed locally | Raw-argv receipt/audit privacy; workspace byte/entry enforcement; policy maxima and duplicate keys; policy symlink/non-regular handling; cgroup path traversal and pinned-FD behavior via test doubles; archive integrity/streaming; supervisor timeout and exception handling |

The warning in the test suite is intentional: the test creates a ZIP with a duplicate member to prove that the verifier rejects it.

## 4. Host capability and unavailable integration tests

The current build host reports Linux x86_64, Python 3.13.5 and kernel 6.18.57. `/usr/bin/unshare`, GCC, libseccomp and libcap are present. A basic combined user/mount/PID/network/IPC/UTS namespace smoke command (`unshare --user --map-root-user --mount --pid --net --ipc --uts --fork /bin/true`) exited successfully; this is not a strict bwrap task or mount-topology test. `bwrap` is absent; the cgroup-v2 mount is not writable/delegated; Landlock ABI probe returns 0. Docker, Podman, Firecracker, QEMU and KVM are not available in this environment.

Accordingly, the following have **not** been claimed as passing:

- Real strict bwrap end-to-end task launch, mount topology and network-isolation verification.
- Live cgroup-v2 controller attachment/limits/kill/cleanup against a writable delegated subtree. Unit tests use controlled filesystem doubles.
- Landlock runtime policy enforcement inside the bwrap payload.
- Hard live filesystem block/inode quotas; current workspace scan is sampled and can overshoot between samples.
- Kernel escape resistance, cross-kernel/architecture validation, adversarial multi-tenant isolation, formal verification, independent penetration testing or security certification.
- Production CI run: this environment's GitHub Actions workflow attempts failed before runner assignment (`runner_id=0`, no steps and no artifacts). The workflow file is authored but has not had a successful remote run verified here.

## 5. Security and production decision

**Do not expose this build to hostile multi-tenant code or production secrets.** v3.5.0 improves concrete defects found in v3.4.0 but remains a single-host, shared-kernel sandbox candidate.

Before enterprise hostile-code workloads, require at minimum: one independently provisioned gVisor or Firecracker/KVM boundary per task/trust domain; aggregate resource quotas; hardened default-deny egress proxy with DNS and redirect revalidation; short-lived task identities and secret brokerage; external immutable audit; artifact quarantine/scanning; signed build provenance; CI on protected runners; backup/recovery and incident-response drills; supported-platform integration testing; and an independent penetration/kernel security review.

## 6. Release integrity

The source ZIP is named `ai-sandbox-kit-3.5.0.zip`; its exact SHA-256 is recorded in the adjacent `.zip.sha256` sidecar. It contains 45 inventoried source/document/test files plus the release manifest and SPDX document (47 ZIP entries total). It is accompanied by a SHA-256 sidecar, a per-file release manifest, an SPDX 2.3 source-file inventory and a local in-toto/SLSA-v1-shaped provenance record. The provenance record is **unsigned local metadata** and is not an authenticated SLSA attestation or a compliance claim. The optional Ed25519 signing path requires a separately managed and trusted key; it was not used for this build.

## 7. Scope / preservation

The original v3.3.0 repository `main` branch was not modified. A separate `v3.5.0` GitHub staging branch was created, but it does not yet contain this locally built v3.5.0 source package; the package is supplied as a verified downloadable artifact. Work occurred in a separate local build directory. No workspace cleanup, deployment, service creation or paid infrastructure was performed.
