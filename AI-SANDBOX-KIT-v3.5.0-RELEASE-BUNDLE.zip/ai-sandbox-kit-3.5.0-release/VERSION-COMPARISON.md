# AI Sandbox Kit: v3.3.0 vs v3.4.0 vs v3.5.0

## Evidence basis

- v3.3.0: private GitHub repository `Abhijeetjain4075/Ai-sandbox-kit`, uploaded `ai-sandbox-kit-v3.3.0-validated-candidate.zip`; archive inspected through authenticated GitHub file access. GitHub blob SHA: `3e85979fd31fe1d2a8ce6cbc7ff15b479b9fd847`; archive has 36 entries, including the runtime, installer, policy, snapshot, tests, SBOM and release metadata.
- v3.4.0: local `AI-SANDBOX-KIT-3.4.0.zip`, SHA-256 `2351ba0c6d17edbfa3f5dc37b4a8fb721fc0a24d1b3ac101142f8dd182a5074b`; its validation report was reviewed and its unit suite was reproduced locally (76 passed, one expected duplicate-ZIP warning).
- v3.5.0: built from the v3.4.0 MIT source in this workspace with the changes described below. Its own test count and final digests are in the accompanying validation report and checksum files.

## Side-by-side capability matrix

| Capability | v3.3.0 candidate | v3.4.0 candidate | v3.5.0 candidate |
|---|---|---|---|
| Primary backend | Custom `unshare` namespaces + chroot/bootstrap | Bubblewrap-only strict backend | Bubblewrap-only strict backend, fail-closed |
| CLI | `aisandbox` / `sandboxctl.py` | `sandboxkit` | `sandboxkit` |
| Installer | Transactional no-follow installer | Python package install | Python package install |
| Namespace isolation | user, mount, net, PID, IPC, UTS, cgroup namespace view | bwrap namespace isolation | unchanged bwrap backend |
| Filesystem | minimal `/etc`, readonly runtime, isolated workspace/tmpfs | readonly system mounts, workspace bind, tmpfs `/tmp` | same + sampled live workspace byte/entry controls |
| Resource controls | RLIMITs; cgroup delegation unavailable on measured host | RLIMITs; optional delegated cgroups; no live disk enforcement | bounded compiled policy ceilings; optional FD-pinned cgroup controls; live sampled workspace byte/entry enforcement |
| Seccomp | default-allow deny-list | default-allow deny-list | default-allow deny-list; no allow-list claim |
| Snapshot/restore | deterministic workspace import/verify/restore, per-file hashes | deterministic ZIP snapshots and integrity verification | preserved with v3.4 APIs, test suite, format v1 |
| Receipts | command hash and bounded output; documentation says raw argv not persisted | code persisted raw `argv` in receipt/audit despite documentation saying otherwise | raw argv removed; safe metadata + digest; receipt v2 |
| Policy | strict runtime subset, policy read no-follow, compiled caps described | strict keys but no compiled upper ceilings; JSON duplicate keys accepted; policy file read through `Path.read_text` | duplicate keys rejected, no-follow regular file, 1 MiB cap, compiled maxima |
| cgroup path security | descriptor-relative filesystem operations in workspace; no evidence of dirfd-pinned cgroup paths | path symlink check followed by later path string operations | cgroup parent/child dirfds pinned; O_NOFOLLOW traversal and attach/cleanup |
| Supply chain | local manifest, CycloneDX SBOM, unsigned provenance | release manifest, SPDX SBOM, unsigned provenance | version-derived deterministic ZIP, manifest, SPDX SBOM, unsigned provenance |
| Production boundary | explicitly single-user/session runner, not hostile multi-tenant | explicitly not production multi-tenant; no strict bwrap run on build host | controlled-workload hardening candidate; still not hostile multi-tenant or certified |
| Licence | `LICENSE_STATUS.md`: no project-level licence; no redistribution rights granted | MIT package | MIT-derived v3.4/v3.5 implementation; no v3.3 source copied |

## Principal findings

### v3.3.0

The available v3.3.0 README and archive inventory describe a broader integrated Linux runner: `sandbox_bootstrap.py`, `sandboxctl.py`, transactional installer, strict runtime policy, snapshot lifecycle, deterministic builder, SBOM and regression tests. Its README is unusually clear about its limits: it is a single-user/session runner inside a trusted outer container, with no independent VM boundary, no per-task writable cgroups on the measured host, no hard disk/inode quota, no egress proxy, no remote identity/secret broker and no independent penetration test. The seccomp policy is default-allow with a deny-list. Its licence status is a distribution blocker until clarified.

### v3.4.0

v3.4 is a cleaner modular Python package with a fail-closed bwrap backend, strict policy, verified snapshot ZIPs, optional cgroup-v2 manager, audit hash chain, receipts, SPDX inventory, local provenance and 76 locally reproducible tests. It was reconstructed, not source-diffed against v3.3.0; the v3.4 upgrade-validation checklist correctly says so. The host did not have bwrap or writable delegated cgroups, so strict and aggregate cgroup paths were not end-to-end validated. Code review identified two policy/privacy gaps: the runtime policy accepted arbitrarily high positive values, and `runner.py` put raw `argv` into receipts and audit events despite its documentation promising otherwise. The cgroup path was checked for symlinks then accessed again using path strings, leaving a TOCTOU window.

### v3.5.0

v3.5 addresses the identified gaps within the portable Python/bwrap architecture: policy maxima and safe policy file loading, no raw argv persistence, sampled live workspace limits, pinned cgroup directory descriptors and exception-safe supervisor cleanup. It keeps strict bwrap fail-closed, does not invent a microVM boundary and does not copy unlicensed v3.3 code. The release is stronger than v3.4 for these concrete controls, but still does not deliver v3.3's custom installer/CLI/backend, a VM backend, a hard live filesystem quota, independent security assessment or production multi-tenant control plane.

## Release decision

**Status: controlled-workload hardening candidate; not enterprise hostile-code production approved.** The remaining gates are: strict bwrap end-to-end on a compatible host; live delegated cgroup integration tests; stress/overshoot measurements for workspace sampling; independent review/penetration testing; trusted CI signing and immutable provenance; and, for multi-tenant hostile workloads, one gVisor/Firecracker/KVM worker per task or trust domain with default-deny egress, identity/secret brokerage, external audit and operational response controls.
