# AI Sandbox Kit v3.5.0

A portable Linux task-sandbox toolkit with **fail-closed strict execution**, bounded workspace snapshots, sampled live-workspace quotas, privacy-preserving execution receipts, descriptor-pinned cgroup scopes and reproducible release metadata.

## Release posture

v3.5.0 is a **security-hardening candidate for controlled Linux workloads**, not a certified multi-tenant execution service. Strict execution requires Linux, `bubblewrap` (`bwrap`) and working unprivileged user namespaces. The current build host did not have `bwrap`, so strict execution could not be end-to-end demonstrated here. The process-only mode is deliberately unsafe and must not be used for untrusted code.

This release is based on the independently licensed v3.4.0 MIT codebase. The v3.3.0 repository archive was separately inspected, but its `LICENSE_STATUS.md` explicitly grants no project-level redistribution rights. No v3.3.0 source was copied into this release. The capability and security comparison is documented in `docs/VERSION-COMPARISON.md`.

## What changed in v3.5.0

- Execution receipts and audit events no longer persist raw command arguments. They retain executable basename, argument count and a SHA-256 digest of the canonical argv vector. This avoids persisting tokens or secrets accidentally passed in arguments.
- Runtime policy loading rejects duplicate JSON keys, symlinked/non-regular policy files, oversized policies, invalid environment variable names and values above compiled resource ceilings.
- Live workspace usage is measured before execution and sampled every 250 ms while a task is active. Byte and entry ceilings terminate the task when exceeded. This is a bounded, sampled monitor—not a hard filesystem/block/inode quota; a small overshoot is possible between checks.
- cgroup-v2 task scopes pin the delegated directory through `O_NOFOLLOW` directory descriptors. Worker attachment and cleanup use the pinned directory descriptor rather than re-resolving path strings.
- Task supervision now has an exception-safe teardown path, bounded pipe draining and a final workspace-accounting pass.
- Release scripts derive the version from `VERSION`, so the package, manifest, SPDX SBOM, provenance filenames and verifier stay aligned.

## Quick start

Requires Python 3.10+ for CLI/archive tools. Strict execution requires Linux and `bubblewrap` installed and configured for unprivileged user namespaces. The core runtime uses only the Python standard library.

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e .
python -m sandboxkit.cli doctor
python -m sandboxkit.cli policy-check --policy policies/default.json
```

Run a task in strict mode (no network by default):

```bash
mkdir -p /tmp/demo-workspace
printf 'hello\n' > /tmp/demo-workspace/input.txt
sandboxkit run --workspace /tmp/demo-workspace --policy policies/default.json -- python3 -c 'print(open("input.txt").read())'
```

If `bwrap` is absent or user namespaces are blocked, strict mode **fails closed**. Do not change the default policy to process mode for untrusted code.

## Workspace lifecycle

```bash
sandboxkit snapshot /path/to/workspace /path/to/workspace.snapshot.zip
sandboxkit verify /path/to/workspace.snapshot.zip
sandboxkit restore /path/to/workspace.snapshot.zip /path/to/restored-workspace
sandboxkit audit-verify /path/to/audit.jsonl
```

Snapshots reject symlinks, special files, traversal names, duplicate names, oversized expansion and CRC/hash mismatches. Restore always targets a new directory.

## Resource enforcement model

- **Per-process:** CPU time, address space, file size, open file descriptors and no-new-privileges.
- **Aggregate (optional):** cgroup-v2 CPU, memory/swap and PID limits, but only beneath a host-admin-predelegated parent with `cpu`, `memory` and `pids` enabled. v3.5 pins the path via directory FDs. It never enables controllers or writes outside the delegated subtree.
- **Workspace bytes:** sampled every 250 ms; not a hard quota. An adversarial task can overshoot between samples.
- **Workspace entries:** bounded during each sample using the configured archive entry ceiling.
- **Output:** stdout/stderr are read through bounded pipes and the process group is terminated on overflow.
- **Network:** disabled in strict bwrap mode. Host networking is not supported by this strict profile; use an external egress broker in a separate runtime.

If `cgroup_v2.required=true`, task startup fails unless the configured delegated subtree can be created and controlled. With cgroups disabled, the `processes` field is not an aggregate PID cap. Do not infer more enforcement than the receipt explicitly reports.

## Isolation tiers

- **Tier 1 — strict bwrap:** user/mount/PID/network namespaces, isolated network, read-only system view, writable workspace, tmpfs `/tmp`, seccomp deny-list and per-process limits.
- **Tier 2 — gVisor:** external deployment pattern; not bundled.
- **Tier 3 — Firecracker microVM:** external deployment pattern; not bundled.

A shared kernel remains shared. The included seccomp filter is **default-allow with a deny-list**, not a syscall allow-list. This package is not an independent VM boundary and is not approved for hostile multi-tenant workloads, customer secrets, or unrestricted adversarial code without a separate microVM/gVisor deployment and independent assessment.

## Privacy, receipts and audit

Raw command arguments are not written to receipts or audit events. The receipt includes executable basename, argument count, argv SHA-256, return code, duration, stop reason, isolation label and observed resource usage. The hash is not reversible protection for low-entropy arguments; do not place secrets in command arguments in the first place. stdout/stderr may still contain secrets printed by the workload and should be treated as sensitive.

The local audit log is hash-chained and detects accidental edits/reordering; an administrator with write access can rewrite the whole chain. For high-assurance audit use external append-only storage or signed checkpoints.

## Supply-chain integrity

- `release-manifest.json`: per-file SHA-256 inventory.
- `sbom.spdx.json`: SPDX 2.3 source-file inventory.
- `provenance.intoto.json`: unsigned local provenance sidecar; **not** an authenticated SLSA attestation.
- `*.sig.json`: optional local Ed25519 signature; trust key IDs out-of-band.
- Production publication should use a protected CI identity, keyless Cosign/Sigstore signing, SBOM vulnerability scanning and independent artifact verification.

## Tests

```bash
python -m pip install -e '.[test,signing]'
pytest -q
```

A successful strict bwrap end-to-end test requires a host with bwrap and working namespaces. The build host did not provide bwrap, so the strict backend remains unverified on this host. See `docs/HOST-VALIDATION.md`, `docs/THREAT_MODEL.md` and `docs/VERSION-COMPARISON.md`.

## License

MIT for this package's original v3.4/v3.5 implementation. No v3.3.0 code was copied because its archive contains an explicit no-license status. Upstream projects referenced as optional integrations retain their own licenses.
