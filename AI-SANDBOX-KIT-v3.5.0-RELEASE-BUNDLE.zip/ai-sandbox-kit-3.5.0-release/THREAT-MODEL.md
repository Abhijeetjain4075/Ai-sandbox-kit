# Threat model — v3.5.0

## Protected assets

Host filesystem and credentials, sibling workspaces, task resource availability, snapshot integrity, execution receipts, audit history and release artifacts.

## Adversaries

Untrusted task code, malicious workspace contents, crafted archives and policy files, concurrent filesystem mutation, accidental operator misconfiguration and compromised build dependencies.

## Security controls

- No shell-string invocation; argv-only execution and exact executable allow-list.
- Environment allow-list; no inherited ambient environment.
- Strict bwrap required; no fallback to plain subprocess execution.
- Network namespace disabled in strict mode.
- Read-only system mounts, selected writable workspace and tmpfs `/tmp`.
- Seccomp default-allow deny-list; unknown architectures fail closed.
- Per-process RLIMITs, parent wall-time supervisor and bounded output capture.
- Optional pre-delegated cgroup-v2 CPU/memory/swap/PID control, with directory-FD pinning and no-follow traversal.
- Live workspace byte/entry accounting before execution and every 250 ms while running.
- Strict bounded policy parser with duplicate-key rejection, `O_NOFOLLOW`, size cap and compiled maxima.
- Snapshot ZIP path, type, CRC, size, compression-ratio and SHA-256 inventory validation.
- Receipts/audit events exclude raw argv; local audit hash chain detects edits but is not immutable.

## Known residual risks

1. A shared kernel remains shared. Namespace, seccomp, bubblewrap or kernel vulnerabilities may permit escape.
2. Seccomp is default-allow with a syscall deny-list. New/unlisted syscalls remain permitted.
3. bwrap was absent from the measured build host; strict bwrap execution was not demonstrated.
4. cgroup-v2 is opt-in; without a pre-delegated subtree, aggregate CPU/memory/PID quotas are not enforced. `RLIMIT_NPROC` is not used as a per-task substitute.
5. Live workspace scanning is sampled every 250 ms. An active process can exceed the byte ceiling between samples. No hard block or inode quota is available from this portable layer.
6. Without cgroup-v2, process-group teardown is not a kernel-enforced descendant boundary. Do not treat timeout handling as equivalent to a per-task cgroup or microVM.
7. Local audit storage can be rewritten by an administrator; no trusted remote append-only service is bundled.
8. Receipt argv hashes can be guessed for low-entropy arguments; stdout/stderr may contain secrets.
9. Local provenance is unsigned; there is no trusted CI attestation, signed container/image, or SLSA level claim.
10. No independent penetration test, formal verification, security certification, gVisor/Firecracker runtime or multi-tenant identity service is included.

## Operating requirements

Do not expose host credentials, Docker sockets, browser profiles or production secrets to task code. For hostile multi-tenant code use independently provisioned Firecracker/KVM microVMs or gVisor workers, pre-delegated cgroups, default-deny egress, ephemeral per-task identities, secret brokerage, external immutable audit, artifact scanning, signed releases and independent penetration testing.
