"""Small CPU/NumPy smoke benchmark. Not a hardware ranking benchmark."""
from __future__ import annotations
import json, os, time
import numpy as np

rng = np.random.default_rng(20261118)
n = 900
A = rng.standard_normal((n, n), dtype=np.float64)
B = rng.standard_normal((n, n), dtype=np.float64)
start = time.perf_counter()
C = A @ B
elapsed = time.perf_counter() - start
result = {
    "benchmark": "numpy_float64_matmul_smoke",
    "shape": [n, n],
    "elapsed_seconds": round(elapsed, 4),
    "gflops_estimate": round((2 * n**3 / elapsed) / 1e9, 3),
    "finite_output": bool(np.isfinite(C).all()),
    "checksum": float(C[0, 0]),
    "thread_budget": {k: os.environ.get(k) for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")},
}
print(json.dumps(result, indent=2))
