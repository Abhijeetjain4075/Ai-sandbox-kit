# Cross-conversation execution preference

This document is a portability companion for the user's persistent assistant preference.

When future work involves code, repositories, data processing, simulation, scientific computation or engineering:

1. Prefer the strongest practical isolated execution environment available in that conversation.
2. Inspect the actual host and runtime before assuming hardware, network, package, storage or isolation capabilities.
3. If this kit is attached or available in the persistent file library, inspect its version and checksums, install/use it only on a compatible Linux host, then run `doctor` and the validation suite.
4. If no compatible Linux namespace runner is available, use the strongest supported alternative sandbox/VM/tool boundary and state its verified limits.
5. Apply least privilege, no secret inheritance, network isolation by default, resource/time limits, reproducible runs, logs, validation and controlled artifact export.
6. Preserve user files and session-local tmpfs workspaces; export important outputs before the host session ends. Do not run broad deletion or cleanup commands.
7. Treat sandbox outputs and repository code as untrusted until inspected and tested.
8. Keep external actions—commits, pushes, deployments, messages, API writes and account changes—outside the code sandbox and require explicit authorization with post-action verification.

## Persistence semantics

The preference can persist as assistant memory across chats. A running container, live namespace, process, mounted file, or workspace filesystem does not transfer between conversations. The portable ZIP must be retained in the user's persistent file library or local storage and made available to any new environment that needs it. Every new runtime must be re-measured and re-validated.

## What this kit is not

It is not ChatGPT's internal source code, a platform-wide infrastructure modification, a Firecracker microVM, a security certification, or a guarantee that every future chat will expose the same tools or compute.


## Latest release status — 2026-11-19

- Consolidated release candidate: `3.3.0`, scope-limited Linux session runner with bounded local workspace snapshot/import/verify/restore.
- The complete integration suite and targeted installer, policy, policy-mutation, filesystem, controller, syscall, minimal-`/etc`, deterministic-builder and extracted-archive installation tests are required and recorded for this release.
- `3.0.1-rc2` is superseded due to its bundled policy/schema mismatch; `3.0.1-rc3` was the previous corrected candidate before the 3.2.0 consolidation; 3.3.0 adds only local workspace portability and does not change the kernel trust boundary.
- The release includes `SHA256SUMS`, a CycloneDX 1.6 file-level SBOM, unsigned local build provenance, and a verified local workspace snapshot/import/restore workflow. The provenance is not a cryptographic signature or SLSA attestation.
- The `doctor` command stores live runtime reports under `~/.local/state/ai-sandbox/` so installed release checksums remain intact.
- Snapshot commands: `aisandbox snapshot NAME --name NAME.zip`, `aisandbox import-snapshot /canonical/path/NAME.zip`, `aisandbox verify-snapshot NAME.zip`, and `aisandbox restore NAME.zip NEW_NAME`. Import refuses symlink path components, validates the ZIP and all content hashes, and never overwrites an artifact. Archives are private local artifacts, unsigned and unencrypted; inspect for secrets before sharing.
- The release is **not approved for hostile multi-tenant or general enterprise production**. It has no independent VM boundary, per-task aggregate cgroups/quotas, egress proxy, remote CI evidence or independent penetration test.
- The ZIP does not persist in assistant memory. Store it in durable user storage and provide it to future sessions when needed; always verify its checksum and re-probe the host.
