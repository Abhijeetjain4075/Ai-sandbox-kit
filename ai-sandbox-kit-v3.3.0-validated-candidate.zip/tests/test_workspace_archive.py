"""Workspace snapshot, verification and restore safety regressions."""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import stat
import sys
import tempfile
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import workspace_archive as wa


def open_dir(path: pathlib.Path) -> int:
    return os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0))


def make_workspace(root: pathlib.Path, name: str) -> pathlib.Path:
    ws = root / name
    ws.mkdir(mode=0o700)
    for part in (".home", ".tmp", ".cache", ".deps", "inputs", "outputs"):
        (ws / part).mkdir(mode=0o700)
    return ws


def write_file(path: pathlib.Path, data: bytes, executable: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    path.chmod(0o700 if executable else 0o600)


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-") as td:
        base = pathlib.Path(td)
        workspaces = base / "workspaces"
        artifacts = base / "artifacts"
        workspaces.mkdir(mode=0o700)
        artifacts.mkdir(mode=0o700)
        src = make_workspace(workspaces, "source-workspace")
        write_file(src / "inputs" / "dataset.txt", b"alpha\nbeta\n" * 100)
        write_file(src / "outputs" / "run.py", b"#!/usr/bin/env python3\nprint('ok')\n", executable=True)
        write_file(src / ".cache" / "deep" / "nested.bin", bytes(range(256)) * 64)
        wfd, afd = open_dir(workspaces), open_dir(artifacts)
        try:
            result = wa.create_snapshot(wfd, "source-workspace", afd, "source.snapshot.zip")
            assert result["files"] == 3 and result["directories"] >= 7
            assert (artifacts / "source.snapshot.zip").stat().st_mode & 0o077 == 0
            verification = wa.verify_snapshot(afd, "source.snapshot.zip")
            assert verification["valid"] and verification["sha256"] == result["sha256"]
            restored = wa.restore_snapshot(afd, "source.snapshot.zip", wfd,
                                           "restored-workspace", os.getuid(), os.getgid())
            assert restored["restored"] and restored["files"] == 3
            assert (workspaces / "restored-workspace" / "inputs" / "dataset.txt").read_bytes() == (src / "inputs" / "dataset.txt").read_bytes()
            assert (workspaces / "restored-workspace" / ".cache" / "deep" / "nested.bin").read_bytes() == (src / ".cache" / "deep" / "nested.bin").read_bytes()
            assert (workspaces / "restored-workspace" / "outputs" / "run.py").stat().st_mode & stat.S_IXUSR
            try:
                wa.restore_snapshot(afd, "source.snapshot.zip", wfd,
                                    "restored-workspace", os.getuid(), os.getgid())
                raise AssertionError("restore replaced an existing workspace")
            except wa.ArchiveError as exc:
                assert "existing workspace" in str(exc)
        finally:
            os.close(wfd); os.close(afd)

    # Symlinks and special files in a source workspace are refused, and no
    # partially published archive is left behind.
    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-link-") as td:
        base = pathlib.Path(td); workspaces = base / "workspaces"; artifacts = base / "artifacts"
        workspaces.mkdir(); artifacts.mkdir(); ws = make_workspace(workspaces, "linked")
        (ws / "outputs" / "escape").symlink_to("/etc/passwd")
        wfd, afd = open_dir(workspaces), open_dir(artifacts)
        try:
            try:
                wa.create_snapshot(wfd, "linked", afd, "bad.zip")
                raise AssertionError("symlink was accepted into a snapshot")
            except wa.ArchiveError as exc:
                assert "symlink" in str(exc)
            assert not (artifacts / "bad.zip").exists()
            assert not list(artifacts.iterdir())
        finally:
            os.close(wfd); os.close(afd)

    # A syntactically valid archive with a tampered payload must fail both
    # verification and restore; the incomplete staging workspace is removed.
    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-tamper-") as td:
        base = pathlib.Path(td); workspaces = base / "workspaces"; artifacts = base / "artifacts"
        workspaces.mkdir(); artifacts.mkdir(); ws = make_workspace(workspaces, "tamper-source")
        write_file(ws / "outputs" / "value.txt", b"trusted-original")
        wfd, afd = open_dir(workspaces), open_dir(artifacts)
        try:
            wa.create_snapshot(wfd, "tamper-source", afd, "good.zip")
            with zipfile.ZipFile(artifacts / "good.zip", "r") as original:
                manifest = json.loads(original.read(wa.MANIFEST_PATH))
                entries = {info.filename: original.read(info) for info in original.infolist()}
            entries["workspace/outputs/value.txt"] = b"tampered-change!"
            with zipfile.ZipFile(artifacts / "tampered.zip", "w", compression=zipfile.ZIP_DEFLATED) as changed:
                for name, content in entries.items():
                    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                    info.create_system = 3
                    info.external_attr = ((stat.S_IFDIR | 0o700) if name.endswith("/") else (stat.S_IFREG | 0o600)) << 16
                    changed.writestr(info, content)
            try:
                wa.verify_snapshot(afd, "tampered.zip")
                raise AssertionError("tampered file digest was accepted")
            except wa.ArchiveError as exc:
                assert "digest or size mismatch" in str(exc)
            try:
                wa.restore_snapshot(afd, "tampered.zip", wfd,
                                    "must-not-exist", os.getuid(), os.getgid())
                raise AssertionError("tampered snapshot was restored")
            except wa.ArchiveError as exc:
                assert "digest or size mismatch" in str(exc)
            assert not (workspaces / "must-not-exist").exists()
            assert not [p for p in workspaces.iterdir() if p.name.startswith(".restore-")]
        finally:
            os.close(wfd); os.close(afd)

    # Reject traversal names and Unix symlink mode bits before trusting the manifest.
    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-malformed-") as td:
        base = pathlib.Path(td); artifacts = base / "artifacts"; artifacts.mkdir()
        manifest = {
            "format": wa.FORMAT, "schema_version": wa.SCHEMA_VERSION,
            "source_workspace": "source", "created_at_utc": "2026-11-19T00:00:00Z",
            "entries": [{"path": "../escape", "type": "file", "mode": 0o600,
                         "size": 0, "sha256": hashlib.sha256(b"").hexdigest()}],
            "totals": {"files": 1, "directories": 0, "bytes": 0},
        }
        with zipfile.ZipFile(artifacts / "unsafe.zip", "w") as zf:
            zf.writestr("workspace/../escape", b"")
            zf.writestr(wa.MANIFEST_PATH, json.dumps(manifest))
        afd = open_dir(artifacts)
        try:
            try:
                wa.verify_snapshot(afd, "unsafe.zip")
                raise AssertionError("path traversal archive was accepted")
            except wa.ArchiveError:
                pass
        finally:
            os.close(afd)

    # Mutate a workspace immediately after its initial inventory. The second
    # inventory must detect the change and prevent publication of a mixed snapshot.
    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-race-") as td:
        base = pathlib.Path(td); workspaces = base / "workspaces"; artifacts = base / "artifacts"
        workspaces.mkdir(); artifacts.mkdir(); ws = make_workspace(workspaces, "changing")
        write_file(ws / "outputs" / "before.txt", b"before")
        wfd, afd = open_dir(workspaces), open_dir(artifacts)
        original_scan = wa._scan_workspace
        calls = 0
        def mutate_after_first_scan(fd: int, uid: int):
            nonlocal calls
            result = original_scan(fd, uid)
            calls += 1
            if calls == 1:
                write_file(ws / "outputs" / "during-snapshot.txt", b"concurrent-change")
            return result
        wa._scan_workspace = mutate_after_first_scan
        try:
            try:
                wa.create_snapshot(wfd, "changing", afd, "must-not-publish.zip")
                raise AssertionError("snapshot published after a concurrent workspace change")
            except wa.ArchiveError as exc:
                assert "changed" in str(exc).lower()
            assert not (artifacts / "must-not-publish.zip").exists()
            assert not list(artifacts.iterdir())
        finally:
            wa._scan_workspace = original_scan
            os.close(wfd); os.close(afd)

    # Import is the portability ingress: it copies an external ZIP into the
    # private artifact store only after full verification, never mutating source.
    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-import-") as td:
        base = pathlib.Path(td)
        workspaces = base / "workspaces"; artifacts = base / "artifacts"; incoming = base / "incoming"
        workspaces.mkdir(mode=0o700); artifacts.mkdir(mode=0o700); incoming.mkdir(mode=0o700)
        ws = make_workspace(workspaces, "import-source")
        write_file(ws / "outputs" / "payload.txt", b"portable-import-payload" * 500)
        wfd, afd = open_dir(workspaces), open_dir(artifacts)
        try:
            wa.create_snapshot(wfd, "import-source", afd, "original.zip")
            source = incoming / "received.zip"
            source.write_bytes((artifacts / "original.zip").read_bytes())
            imported = wa.import_snapshot(str(source), afd, "received.zip")
            assert imported["imported"] and imported["sha256"] == wa.verify_snapshot(afd, "original.zip")["sha256"]
            assert imported["sha256"] == wa.verify_snapshot(afd, "received.zip")["sha256"]
            assert source.is_file(), "import must not modify or remove its source"
            assert (artifacts / "received.zip").stat().st_mode & 0o077 == 0
            restored = wa.restore_snapshot(afd, "received.zip", wfd, "import-restored", os.getuid(), os.getgid())
            assert restored["restored"]
            assert (workspaces / "import-restored" / "outputs" / "payload.txt").read_bytes() == (ws / "outputs" / "payload.txt").read_bytes()
            try:
                wa.import_snapshot(str(source), afd, "received.zip")
                raise AssertionError("import replaced an existing archive")
            except wa.ArchiveError as exc:
                assert "overwrite" in str(exc)
            link = incoming / "linked.zip"
            link.symlink_to(source)
            try:
                wa.import_snapshot(str(link), afd, "linked-import.zip")
                raise AssertionError("symlinked import source was accepted")
            except wa.ArchiveError as exc:
                assert "safely open" in str(exc) or "symlink" in str(exc)
            try:
                wa.import_snapshot("../received.zip", afd, "traversal.zip")
                raise AssertionError("traversal import path was accepted")
            except wa.ArchiveError as exc:
                assert "canonical" in str(exc)
            assert not (artifacts / "linked-import.zip").exists()
            assert not list(artifacts.glob("import-*.zip")), "failed imports must clean staging archives"
        finally:
            os.close(wfd); os.close(afd)

    # An arbitrary ZIP and a source path that crosses a symlink directory are
    # refused before any final artifact becomes visible.
    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-import-invalid-") as td:
        base = pathlib.Path(td); artifacts = base / "artifacts"; real = base / "real"
        artifacts.mkdir(); real.mkdir()
        bogus = real / "bogus.zip"; bogus.write_bytes(b"not-a-zip")
        link_dir = base / "linked-dir"; link_dir.symlink_to(real, target_is_directory=True)
        afd = open_dir(artifacts)
        try:
            for path, name in ((str(bogus), "bogus.zip"), (str(link_dir / "bogus.zip"), "through-link.zip")):
                try:
                    wa.import_snapshot(path, afd, name)
                    raise AssertionError("invalid archive or symlinked path was accepted")
                except wa.ArchiveError:
                    pass
            assert not list(artifacts.iterdir())
        finally:
            os.close(afd)

    # Hard-linked files, FIFOs and NFKC/case-fold-colliding names are refused.
    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-hardlink-") as td:
        base = pathlib.Path(td); workspaces = base / "workspaces"; artifacts = base / "artifacts"
        workspaces.mkdir(); artifacts.mkdir(); ws = make_workspace(workspaces, "hardlinked")
        write_file(ws / "outputs" / "one", b"same inode")
        os.link(ws / "outputs" / "one", ws / "outputs" / "two")
        wfd, afd = open_dir(workspaces), open_dir(artifacts)
        try:
            try:
                wa.create_snapshot(wfd, "hardlinked", afd, "hardlinked.zip")
                raise AssertionError("hard-linked file was accepted")
            except wa.ArchiveError as exc:
                assert "Hard-linked" in str(exc)
            assert not list(artifacts.iterdir())
        finally:
            os.close(wfd); os.close(afd)

    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-fifo-") as td:
        base = pathlib.Path(td); workspaces = base / "workspaces"; artifacts = base / "artifacts"
        workspaces.mkdir(); artifacts.mkdir(); ws = make_workspace(workspaces, "fifo")
        os.mkfifo(ws / "outputs" / "pipe", 0o600)
        wfd, afd = open_dir(workspaces), open_dir(artifacts)
        try:
            try:
                wa.create_snapshot(wfd, "fifo", afd, "fifo.zip")
                raise AssertionError("FIFO was accepted")
            except wa.ArchiveError as exc:
                assert "special file" in str(exc)
        finally:
            os.close(wfd); os.close(afd)

    with tempfile.TemporaryDirectory(prefix="aisandbox-snapshot-collision-") as td:
        base = pathlib.Path(td); workspaces = base / "workspaces"; artifacts = base / "artifacts"
        workspaces.mkdir(); artifacts.mkdir(); ws = make_workspace(workspaces, "collision")
        (ws / ".cache" / "A").mkdir(); (ws / ".cache" / "Ａ").mkdir()
        wfd, afd = open_dir(workspaces), open_dir(artifacts)
        try:
            try:
                wa.create_snapshot(wfd, "collision", afd, "collision.zip")
                raise AssertionError("NFKC path collision was accepted")
            except wa.ArchiveError as exc:
                assert "collision" in str(exc).lower()
        finally:
            os.close(wfd); os.close(afd)

    print("WORKSPACE_SNAPSHOT_CREATE_VERIFY_RESTORE=PASS")
    print("WORKSPACE_SNAPSHOT_CONCURRENT_CHANGE_GUARD=PASS")
    print("WORKSPACE_SNAPSHOT_IMPORT_VERIFY_NOFOLLOW_NO_OVERWRITE=PASS")
    print("WORKSPACE_SNAPSHOT_SYMLINK_HARDLINK_SPECIAL_FILE_REJECTION=PASS")
    print("WORKSPACE_SNAPSHOT_TAMPER_AND_ROLLBACK=PASS")
    print("WORKSPACE_SNAPSHOT_ARCHIVE_PATH_VALIDATION=PASS")


if __name__ == "__main__":
    main()
