"""Targeted controller tests for parallelism, bounded output and receipt privacy."""
from __future__ import annotations
import json
import os
import pathlib
import subprocess
import sys
import time
import uuid

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import sandboxctl as sandbox_controller
CTL = ROOT / "sandboxctl.py"
WORKSPACES = sandbox_controller.WORKSPACES


def run(*args, timeout=45):
    p = subprocess.run([sys.executable, str(CTL), *args], text=True,
                       capture_output=True, timeout=timeout, env=os.environ.copy())
    if p.returncode != 0:
        raise AssertionError(f"{args!r}: exit={p.returncode}\nstdout={p.stdout}\nstderr={p.stderr}")
    return p.stdout + p.stderr


def main() -> None:
    qa = "feature-" + uuid.uuid4().hex[:8]
    run("create", qa)
    assert str(WORKSPACES).startswith("/dev/shm/"), WORKSPACES
    assert os.statvfs(WORKSPACES).f_bavail > 0

    # Two independent workspaces should execute concurrently under per-workspace locks.
    a, b = "feature-a-" + uuid.uuid4().hex[:6], "feature-b-" + uuid.uuid4().hex[:6]
    run("create", a); run("create", b)
    base = [sys.executable, str(CTL), "run", "--timeout", "20"]
    start = time.monotonic()
    pa = subprocess.Popen(base + [a, "--", "python", "-c", "import time; time.sleep(2)"],
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    pb = subprocess.Popen(base + [b, "--", "python", "-c", "import time; time.sleep(2)"],
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ao, ae = pa.communicate(timeout=30); bo, be = pb.communicate(timeout=30)
    elapsed = time.monotonic() - start
    assert pa.returncode == 0, (ao, ae)
    assert pb.returncode == 0, (bo, be)
    assert elapsed < 8.0, elapsed  # leave margin for namespace startup jitter on shared CI hosts

    # Common secret patterns are redacted before display; raw outputs/argv are not persisted.
    token = "ghp_" + "A" * 36
    stdout_files_before = set((ROOT / "logs").glob("*.stdout.log"))
    out = run("run", "--timeout", "30", qa, "--", "python", "-c",
              f"print('Authorization: Bearer {token}')")
    assert "[REDACTED]" in out and token not in out
    assert set((ROOT / "logs").glob("*.stdout.log")) == stdout_files_before
    receipts = sorted((ROOT / "logs").glob("*.json"), key=lambda p: p.stat().st_mtime_ns)
    receipt_path = receipts[-1]
    receipt = json.loads(receipt_path.read_text())
    assert receipt["command"]["raw_arguments_persisted"] is False
    assert receipt["output_handling"]["raw_output_persisted"] is False
    assert token not in json.dumps(receipt)
    assert receipt_path.stat().st_mode & 0o077 == 0

    # Oversized output is drained, bounded and reported as truncated.
    out = run("run", "--timeout", "30", qa, "--", "python", "-c", "print('x' * 400000)")
    assert len(out) < 30000, len(out)
    assert "Output capture limit reached" in out
    receipts = sorted((ROOT / "logs").glob("*.json"), key=lambda p: p.stat().st_mtime_ns)
    receipt = json.loads(receipts[-1].read_text())
    assert receipt["output_handling"]["stdout_truncated"] is True


    # Kill the controller abruptly after a child workload starts. Kernel
    # parent-death signalling plus unshare --kill-child should stop the tree.
    orphan_ws = "orphan-" + uuid.uuid4().hex[:8]
    run("create", orphan_ws)
    marker = WORKSPACES / orphan_ws / "outputs" / "child.started"
    comm = "aisb" + uuid.uuid4().hex[:8]
    child_code = (
        "import ctypes,time; "
        f"ctypes.CDLL(None).prctl(15, b'{comm}', 0, 0, 0); "
        "time.sleep(25)"
    )
    task_code = (
        "import pathlib,subprocess,sys,time; "
        f"subprocess.Popen([sys.executable,'-c',{child_code!r}]); "
        "pathlib.Path('outputs/child.started').write_text('yes'); "
        "time.sleep(40)"
    )
    controller = subprocess.Popen(
        [sys.executable, str(CTL), "run", "--timeout", "60", orphan_ws,
         "--", "python", "-c", task_code],
        text=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        start_new_session=True, env=os.environ.copy())
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline and not marker.exists():
        if controller.poll() is not None:
            raise AssertionError("controller exited before orphan probe started")
        time.sleep(0.05)
    assert marker.exists(), "orphan probe did not start"
    controller.kill()
    controller.wait(timeout=10)
    def comm_exists():
        for proc_dir in pathlib.Path("/proc").iterdir():
            if not proc_dir.name.isdigit():
                continue
            try:
                if (proc_dir / "comm").read_text().strip() == comm:
                    return True
            except (FileNotFoundError, PermissionError, ProcessLookupError):
                continue
        return False
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline and comm_exists():
        time.sleep(0.05)
    assert not comm_exists(), f"orphan workload process {comm} survived controller SIGKILL"

    print("CONTROLLER_PARALLEL_WORKSPACES=PASS")
    print("CONTROLLER_SECRET_REDACTION_AND_NONPERSISTENCE=PASS")
    print("CONTROLLER_OUTPUT_BOUNDS=PASS")
    print("CONTROLLER_CRASH_ORPHAN_CLEANUP=PASS")


if __name__ == "__main__":
    main()
