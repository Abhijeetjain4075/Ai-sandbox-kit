"""Install and execute the CLI from an already-built release archive."""
from __future__ import annotations
import argparse
import os
import pathlib
import pwd
import shutil
import subprocess
import sys
import tempfile
import zipfile


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", required=True, type=pathlib.Path)
    parser.add_argument("--rootless", action="store_true",
                        help="install and execute as the unprivileged nobody account (test harness must run as root)")
    args = parser.parse_args()
    archive = args.archive.resolve(strict=True)
    target = pwd.getpwnam("nobody") if args.rootless and os.geteuid() == 0 else None
    if args.rootless and os.geteuid() == 0 and target.pw_uid == 0:
        raise SystemExit("rootless test requires a non-root account")

    setpriv_path = shutil.which("setpriv") if target is not None else None
    if target is not None and not setpriv_path:
        raise SystemExit("rootless archive-install test requires util-linux setpriv")

    _subprocess_run = subprocess.run
    def run_as_target(command, **kwargs):
        # Use an explicit identity wrapper instead of preexec_fn. Python warns
        # that preexec_fn can deadlock in threaded hosts; it also makes timeout
        # diagnostics unreliable when launching a CLI that itself spawns a new
        # session for the sandbox supervisor.
        kwargs.pop("preexec_fn", None)
        if target is not None:
            command = [setpriv_path, f"--reuid={target.pw_uid}",
                       f"--regid={target.pw_gid}", "--clear-groups", *command]
        return _subprocess_run(command, **kwargs)

    def chown_tree(path: pathlib.Path) -> None:
        if target is None:
            return
        for current, dirs, files in os.walk(path, topdown=True, followlinks=False):
            current_path = pathlib.Path(current)
            os.chown(current_path, target.pw_uid, target.pw_gid, follow_symlinks=False)
            for name in dirs + files:
                entry = current_path / name
                os.chown(entry, target.pw_uid, target.pw_gid, follow_symlinks=False)
        os.chown(path, target.pw_uid, target.pw_gid, follow_symlinks=False)
    with tempfile.TemporaryDirectory(prefix="aisandbox-archive-install-") as td:
        base = pathlib.Path(td)
        extracted = base / "source"
        home = base / "home"
        extracted.mkdir(); home.mkdir()
        with zipfile.ZipFile(archive) as zf:
            bad = zf.testzip()
            assert bad is None, bad
            for name in zf.namelist():
                p = pathlib.PurePosixPath(name)
                assert not p.is_absolute() and ".." not in p.parts
            zf.extractall(extracted)
        env = os.environ.copy()
        env["HOME"] = str(home)
        env["AI_SANDBOX_HOME"] = str(home / ".local/share/ai-sandbox")
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        if target is not None:
            # The test harness itself extracts as root, then hands the complete
            # temporary tree to an isolated unprivileged identity.
            chown_tree(base)
            os.chmod(base, 0o755)
            os.chmod(extracted, 0o755)
            os.chmod(home, 0o700)
        print("ARCHIVE_TEST_STAGE=install", flush=True)
        install = run_as_target(["sh", str(extracted / "install.sh")], env=env,
                                 text=True, capture_output=True, timeout=60)
        assert install.returncode == 0, (install.stdout, install.stderr)
        cli = home / ".local/bin/aisandbox"
        assert cli.is_file() and not cli.is_symlink() and os.access(cli, os.X_OK)
        print("ARCHIVE_TEST_STAGE=doctor", flush=True)
        doctor = run_as_target([str(cli), "doctor"], env=env, text=True,
                                capture_output=True, timeout=30)
        assert doctor.returncode == 0, (doctor.stdout, doctor.stderr)
        # Runtime diagnostics must live outside the immutable installed release
        # tree; running doctor must not invalidate its own source manifest.
        print("ARCHIVE_TEST_STAGE=manifest", flush=True)
        manifest_check = run_as_target(["sha256sum", "-c", "SHA256SUMS"], cwd=home / ".local/share/ai-sandbox",
                                        env=env, text=True, capture_output=True, timeout=30)
        assert manifest_check.returncode == 0, (manifest_check.stdout, manifest_check.stderr)
        state_report = home / ".local/state/ai-sandbox/capability_report.json"
        assert state_report.is_file(), state_report
        assert "Saved runtime diagnostics outside the immutable install tree" in doctor.stdout
        print("ARCHIVE_TEST_STAGE=create", flush=True)
        create = run_as_target([str(cli), "create", "archive-smoke"], env=env,
                                text=True, capture_output=True, timeout=30)
        assert create.returncode == 0, (create.stdout, create.stderr)
        # Workspaces must be placed on tmpfs so the user-namespace bind mount
        # succeeds even when the installed kit lives below a private HOME.
        import json
        doctor_report = json.loads(doctor.stdout.split("\n\nSaved runtime diagnostics", 1)[0])
        workspace_root = pathlib.Path(doctor_report["workspace_storage"]["path"])
        assert str(workspace_root).startswith("/dev/shm/")
        assert (workspace_root / "archive-smoke").is_dir()
        print("ARCHIVE_TEST_STAGE=run", flush=True)
        run = run_as_target([str(cli), "run", "--timeout", "30", "archive-smoke",
                              "--", "python3", "-c",
                              "from pathlib import Path; Path('outputs/persisted.txt').write_text('archive-install-execution-ok'); print('archive-install-execution-ok')"],
                             env=env, text=True, capture_output=True, timeout=45)
        assert run.returncode == 0, (run.stdout, run.stderr)
        assert "archive-install-execution-ok" in run.stdout
        print("ARCHIVE_TEST_STAGE=snapshot", flush=True)
        snapshot = run_as_target([str(cli), "snapshot", "archive-smoke",
                                   "--name", "archive-smoke-ci.zip"], env=env,
                                  text=True, capture_output=True, timeout=45)
        assert snapshot.returncode == 0, (snapshot.stdout, snapshot.stderr)
        print("ARCHIVE_TEST_STAGE=verify", flush=True)
        verify = run_as_target([str(cli), "verify-snapshot", "archive-smoke-ci.zip"],
                                env=env, text=True, capture_output=True, timeout=45)
        assert verify.returncode == 0 and '"valid": true' in verify.stdout, (verify.stdout, verify.stderr)
        print("ARCHIVE_TEST_STAGE=restore", flush=True)
        restore = run_as_target([str(cli), "restore", "archive-smoke-ci.zip", "archive-restored"],
                                 env=env, text=True, capture_output=True, timeout=45)
        assert restore.returncode == 0, (restore.stdout, restore.stderr)
        installed_kit = home / ".local/share/ai-sandbox"
        print("ARCHIVE_TEST_STAGE=import", flush=True)
        imported_archive = run_as_target([str(cli), "import-snapshot",
                                           str(installed_kit / "artifacts" / "archive-smoke-ci.zip"),
                                           "--name", "archive-smoke-imported.zip"],
                                          env=env, text=True, capture_output=True, timeout=45)
        assert imported_archive.returncode == 0 and '"imported": true' in imported_archive.stdout, (imported_archive.stdout, imported_archive.stderr)
        print("ARCHIVE_TEST_STAGE=verify-import", flush=True)
        imported_verify = run_as_target([str(cli), "verify-snapshot", "archive-smoke-imported.zip"],
                                         env=env, text=True, capture_output=True, timeout=45)
        assert imported_verify.returncode == 0 and '"valid": true' in imported_verify.stdout, (imported_verify.stdout, imported_verify.stderr)
        print("ARCHIVE_TEST_STAGE=import-overwrite", flush=True)
        import_overwrite = run_as_target([str(cli), "import-snapshot",
                                           str(installed_kit / "artifacts" / "archive-smoke-ci.zip"),
                                           "--name", "archive-smoke-imported.zip"],
                                          env=env, text=True, capture_output=True, timeout=45)
        assert import_overwrite.returncode != 0 and "overwrite" in import_overwrite.stderr.lower(), (import_overwrite.stdout, import_overwrite.stderr)
        print("ARCHIVE_TEST_STAGE=restore-import", flush=True)
        imported_restore = run_as_target([str(cli), "restore", "archive-smoke-imported.zip", "archive-imported"],
                                          env=env, text=True, capture_output=True, timeout=45)
        assert imported_restore.returncode == 0, (imported_restore.stdout, imported_restore.stderr)
        print("ARCHIVE_TEST_STAGE=run-import", flush=True)
        imported_run = run_as_target([str(cli), "run", "--timeout", "30", "archive-imported",
                                       "--", "python3", "-c",
                                       "from pathlib import Path; print(Path('outputs/persisted.txt').read_text())"],
                                      env=env, text=True, capture_output=True, timeout=45)
        assert imported_run.returncode == 0 and "archive-install-execution-ok" in imported_run.stdout, (imported_run.stdout, imported_run.stderr)
        print("ARCHIVE_TEST_STAGE=run-restored", flush=True)
        restored_run = run_as_target([str(cli), "run", "--timeout", "30", "archive-restored",
                                       "--", "python3", "-c",
                                       "from pathlib import Path; print(Path('outputs/persisted.txt').read_text())"],
                                      env=env, text=True, capture_output=True, timeout=45)
        assert restored_run.returncode == 0, (restored_run.stdout, restored_run.stderr)
        assert "archive-install-execution-ok" in restored_run.stdout
    if target is not None:
        mode = "ROOTLESS_NOBODY"
    elif args.rootless:
        mode = "ROOTLESS_CURRENT_USER"
    else:
        mode = "ROOT_MANAGED" if os.geteuid() == 0 else "CURRENT_USER"
    print(f"ARCHIVE_INSTALL_FROM_EXTRACTED_ZIP_{mode}=PASS")
    print(f"ARCHIVE_INSTALLED_DOCTOR_{mode}=PASS")
    print(f"ARCHIVE_INSTALLED_SANDBOX_EXECUTION_{mode}=PASS")


if __name__ == "__main__":
    main()
