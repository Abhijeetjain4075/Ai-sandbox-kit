"""Regression tests for safe, transactional installation. Uses temporary HOME only."""
from __future__ import annotations
import importlib.util
import os
import pathlib
import subprocess
import sys
import tempfile
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "install.sh"
HELPER = ROOT / "install_transaction.py"


def run_install(home: pathlib.Path, install_dir: pathlib.Path | None = None) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["HOME"] = str(home)
    env["AI_SANDBOX_HOME"] = str(install_dir or (home / ".local/share/ai-sandbox"))
    return subprocess.run(["sh", str(INSTALLER)], env=env, text=True,
                          capture_output=True, timeout=45)


def import_installer():
    spec = importlib.util.spec_from_file_location("install_transaction", HELPER)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> None:
    # Existing symlink: its target must remain byte-for-byte unchanged.
    with tempfile.TemporaryDirectory(prefix="aisandbox-installer-link-") as td:
        home = pathlib.Path(td)
        (home / ".local/bin").mkdir(parents=True)
        sentinel = home / "sentinel.txt"
        sentinel.write_text("preserve-me\n")
        cli = home / ".local/bin/aisandbox"
        cli.symlink_to(sentinel)
        result = run_install(home)
        assert result.returncode != 0, (result.stdout, result.stderr)
        assert cli.is_symlink()
        assert sentinel.read_text() == "preserve-me\n"
        assert not (home / ".local/share/ai-sandbox").exists()

    # Existing regular file: do not overwrite it either.
    with tempfile.TemporaryDirectory(prefix="aisandbox-installer-file-") as td:
        home = pathlib.Path(td)
        (home / ".local/bin").mkdir(parents=True)
        cli = home / ".local/bin/aisandbox"
        cli.write_text("user-owned-file\n")
        result = run_install(home)
        assert result.returncode != 0, (result.stdout, result.stderr)
        assert cli.read_text() == "user-owned-file\n"
        assert not (home / ".local/share/ai-sandbox").exists()

    # Symlinked ~/.local must be rejected without touching the target.
    with tempfile.TemporaryDirectory(prefix="aisandbox-installer-local-link-") as td:
        base = pathlib.Path(td)
        home, external = base / "home", base / "external"
        home.mkdir(); external.mkdir()
        (home / ".local").symlink_to(external, target_is_directory=True)
        result = run_install(home)
        assert result.returncode != 0, (result.stdout, result.stderr)
        assert (home / ".local").is_symlink() and list(external.iterdir()) == []

    # Symlinked ~/.local/bin is rejected without touching the target.
    with tempfile.TemporaryDirectory(prefix="aisandbox-installer-bin-link-") as td:
        base = pathlib.Path(td)
        home, external = base / "home", base / "external"
        home.mkdir(); external.mkdir(); (home / ".local").mkdir()
        (home / ".local/bin").symlink_to(external, target_is_directory=True)
        result = run_install(home)
        assert result.returncode != 0, (result.stdout, result.stderr)
        assert (home / ".local/bin").is_symlink() and list(external.iterdir()) == []

    # Existing installation root is preserved byte-for-byte.
    with tempfile.TemporaryDirectory(prefix="aisandbox-installer-dest-") as td:
        home = pathlib.Path(td)
        dest = home / ".local/share/ai-sandbox"
        dest.mkdir(parents=True)
        sentinel = dest / "owned.txt"
        sentinel.write_text("keep-existing-install\n")
        result = run_install(home)
        assert result.returncode != 0, (result.stdout, result.stderr)
        assert sentinel.read_text() == "keep-existing-install\n"
        assert not (home / ".local/bin/aisandbox").exists()

    # Clean installation succeeds; wrapper points at the requested custom path.
    with tempfile.TemporaryDirectory(prefix="aisandbox-installer-clean-") as td:
        home = pathlib.Path(td)
        custom = home / "opt/ai sandbox kit"
        result = run_install(home, custom)
        assert result.returncode == 0, (result.stdout, result.stderr)
        cli = home / ".local/bin/aisandbox"
        assert cli.is_file() and not cli.is_symlink() and os.access(cli, os.X_OK)
        assert (custom / "sandboxctl.py").is_file()
        assert (custom / "SHA256SUMS").is_file()
        wrapper = cli.read_text()
        assert str(custom) in wrapper
        run = subprocess.run([str(cli), "list"], env={**os.environ, "HOME": str(home)},
                             text=True, capture_output=True, timeout=30)
        assert run.returncode == 0, (run.stdout, run.stderr)
        assert "No workspaces" in (run.stdout + run.stderr)

    # Inject wrapper publication failure after kit publication; installer must roll back.
    with tempfile.TemporaryDirectory(prefix="aisandbox-installer-rollback-") as td:
        home = pathlib.Path(td)
        helper = import_installer()
        real_rename = helper.rename_noreplace
        def fail_wrapper(libc, old_fd, old_name, new_fd, new_name):
            if new_name == "aisandbox":
                raise OSError(5, "injected wrapper publication failure")
            return real_rename(libc, old_fd, old_name, new_fd, new_name)
        old_home = os.environ.get("HOME")
        old_ai = os.environ.get("AI_SANDBOX_HOME")
        old_argv = sys.argv[:]
        try:
            os.environ["HOME"] = str(home)
            dest = home / ".local/share/ai-sandbox"
            os.environ["AI_SANDBOX_HOME"] = str(dest)
            sys.argv = [str(HELPER), str(ROOT), str(dest)]
            with mock.patch.object(helper, "rename_noreplace", side_effect=fail_wrapper):
                try:
                    helper.main()
                    raise AssertionError("injected failure did not fail installation")
                except OSError as exc:
                    assert "injected" in str(exc)
            assert not dest.exists()
            assert not (home / ".local/bin/aisandbox").exists()
            share = home / ".local/share"
            assert not any(p.name.startswith(".aisandbox-stage-") for p in share.iterdir())
            assert not any(p.name.startswith(".aisandbox-wrapper-") for p in (home / ".local/bin").iterdir())
        finally:
            sys.argv = old_argv
            if old_home is None: os.environ.pop("HOME", None)
            else: os.environ["HOME"] = old_home
            if old_ai is None: os.environ.pop("AI_SANDBOX_HOME", None)
            else: os.environ["AI_SANDBOX_HOME"] = old_ai


    # A symlinked source subdirectory must not redirect package reads outside the release tree.
    with tempfile.TemporaryDirectory(prefix="aisandbox-source-link-") as td:
        base = pathlib.Path(td)
        home, source, external = base / "home", base / "source", base / "external"
        home.mkdir(); source.mkdir(); external.mkdir()
        (external / "secret.txt").write_text("external-source-must-not-be-read")
        (source / "policy").symlink_to(external, target_is_directory=True)
        import hashlib
        digest = hashlib.sha256((external / "secret.txt").read_bytes()).hexdigest()
        (source / "SHA256SUMS").write_text(f"{digest}  policy/secret.txt\n")
        old_home = os.environ.get("HOME")
        old_ai = os.environ.get("AI_SANDBOX_HOME")
        old_argv = sys.argv[:]
        helper = import_installer()
        try:
            os.environ["HOME"] = str(home)
            dest = home / ".local/share/ai-sandbox"
            os.environ["AI_SANDBOX_HOME"] = str(dest)
            sys.argv = [str(HELPER), str(source), str(dest)]
            try:
                helper.main()
                raise AssertionError("installer followed a symlinked source directory")
            except OSError:
                pass
            assert not dest.exists()
            assert not (home / ".local/bin/aisandbox").exists()
        finally:
            sys.argv = old_argv
            if old_home is None: os.environ.pop("HOME", None)
            else: os.environ["HOME"] = old_home
            if old_ai is None: os.environ.pop("AI_SANDBOX_HOME", None)
            else: os.environ["AI_SANDBOX_HOME"] = old_ai

    # A symlink used as the source-tree root must be rejected, not resolved away.
    with tempfile.TemporaryDirectory(prefix="aisandbox-source-root-link-") as td:
        base = pathlib.Path(td)
        home, actual = base / "home", base / "actual-source"
        home.mkdir(); actual.mkdir()
        (actual / "SHA256SUMS").write_text("0" * 64 + "  placeholder\n")
        alias = base / "source-alias"
        alias.symlink_to(actual, target_is_directory=True)
        helper = import_installer()
        old_home = os.environ.get("HOME")
        old_ai = os.environ.get("AI_SANDBOX_HOME")
        old_argv = sys.argv[:]
        try:
            os.environ["HOME"] = str(home)
            dest = home / ".local/share/ai-sandbox"
            os.environ["AI_SANDBOX_HOME"] = str(dest)
            sys.argv = [str(HELPER), str(alias), str(dest)]
            try:
                helper.main()
                raise AssertionError("installer resolved a symlinked source root")
            except OSError:
                pass
            assert not dest.exists()
            assert not (home / ".local/bin/aisandbox").exists()
        finally:
            sys.argv = old_argv
            if old_home is None: os.environ.pop("HOME", None)
            else: os.environ["HOME"] = old_home
            if old_ai is None: os.environ.pop("AI_SANDBOX_HOME", None)
            else: os.environ["AI_SANDBOX_HOME"] = old_ai

    # A failure after wrapper rename must remove our wrapper and roll back the kit.
    with tempfile.TemporaryDirectory(prefix="aisandbox-installer-fsync-rollback-") as td:
        home = pathlib.Path(td)
        helper = import_installer()
        real_fsync = helper.os.fsync
        calls = {"bin": 0}
        def fail_post_publish_bin_fsync(fd):
            try:
                target = os.fstat(fd)
                bin_path = home / ".local/bin"
                if bin_path.exists() and target.st_ino == bin_path.stat().st_ino:
                    calls["bin"] += 1
                    if calls["bin"] == 2:
                        raise OSError(5, "injected post-publication fsync failure")
            except FileNotFoundError:
                pass
            return real_fsync(fd)
        old_home = os.environ.get("HOME")
        old_ai = os.environ.get("AI_SANDBOX_HOME")
        old_argv = sys.argv[:]
        try:
            os.environ["HOME"] = str(home)
            dest = home / ".local/share/ai-sandbox"
            os.environ["AI_SANDBOX_HOME"] = str(dest)
            sys.argv = [str(HELPER), str(ROOT), str(dest)]
            with mock.patch.object(helper.os, "fsync", side_effect=fail_post_publish_bin_fsync):
                try:
                    helper.main()
                    raise AssertionError("injected post-publication fsync failure did not fail")
                except OSError as exc:
                    assert "injected" in str(exc)
            assert not dest.exists()
            assert not (home / ".local/bin/aisandbox").exists()
            assert not any(p.name.startswith(".aisandbox-stage-") for p in (home / ".local/share").iterdir())
        finally:
            sys.argv = old_argv
            if old_home is None: os.environ.pop("HOME", None)
            else: os.environ["HOME"] = old_home
            if old_ai is None: os.environ.pop("AI_SANDBOX_HOME", None)
            else: os.environ["AI_SANDBOX_HOME"] = old_ai

    print("INSTALLER_SYMLINK_PROTECTION=PASS")
    print("INSTALLER_EXISTING_FILE_PROTECTION=PASS")
    print("INSTALLER_LOCAL_DIR_SYMLINK_PROTECTION=PASS")
    print("INSTALLER_BIN_DIR_SYMLINK_PROTECTION=PASS")
    print("INSTALLER_EXISTING_DESTINATION_PROTECTION=PASS")
    print("INSTALLER_CUSTOM_PATH_WRAPPER=PASS")
    print("INSTALLER_CLEAN_INSTALL=PASS")
    print("INSTALLER_ROLLBACK_AFTER_PUBLISH_FAILURE=PASS")
    print("INSTALLER_SOURCE_SYMLINK_CONFINEMENT=PASS")
    print("INSTALLER_SOURCE_ROOT_SYMLINK_REJECTION=PASS")
    print("INSTALLER_POST_PUBLICATION_FSYNC_ROLLBACK=PASS")


if __name__ == "__main__":
    main()
