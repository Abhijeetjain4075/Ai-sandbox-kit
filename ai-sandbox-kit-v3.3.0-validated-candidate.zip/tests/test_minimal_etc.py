"""Tests for the generated minimal /etc and no-follow runtime-file copier."""
from __future__ import annotations
import os
import pathlib
import tempfile
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import sandbox_bootstrap as bootstrap


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="aisandbox-minetc-") as td:
        root = pathlib.Path(td)
        etc = root / "etc"
        report = bootstrap.build_minimal_etc(etc)

        expected_generated = {"passwd", "group", "nsswitch.conf", "hosts"}
        assert set(report["generated"]) == expected_generated
        entries = {p.name for p in etc.iterdir()}
        assert expected_generated.issubset(entries)
        allowed_files = expected_generated | {"ld.so.cache", "services", "protocols", "ssl"}
        assert entries <= allowed_files, entries
        assert "shadow" not in entries and "gshadow" not in entries
        assert "sudoers" not in entries and "machine-id" not in entries
        assert "resolv.conf" not in entries and "ld.so.preload" not in entries

        passwd = (etc / "passwd").read_text()
        group = (etc / "group").read_text()
        nss = (etc / "nsswitch.conf").read_text()
        hosts = (etc / "hosts").read_text()
        assert "root:x:0:0:" in passwd
        assert "nobody:x:65534:65534:" in passwd
        assert "root:x:0:" in group
        assert "hosts: files" in nss
        assert "127.0.0.1 localhost" in hosts
        assert "::1 localhost" in hosts

        # The copier must reject a symlink source and preserve an existing
        # destination rather than deleting it in an exception cleanup path.
        src = root / "source.txt"
        src.write_text("safe")
        link = root / "source-link"
        link.symlink_to(src)
        existing_target = root / "existing-target"
        existing_target.write_text("preserve-existing")
        try:
            bootstrap.copy_regular_file_nofollow(str(link), existing_target, 64)
            raise AssertionError("symlink source unexpectedly accepted")
        except OSError:
            pass
        assert existing_target.read_text() == "preserve-existing"

        # A size-limit failure after destination creation must remove only the
        # partial file created by this invocation.
        too_large = root / "too-large"
        too_large.write_bytes(b"x" * 1024)
        partial = root / "partial-copy"
        try:
            bootstrap.copy_regular_file_nofollow(str(too_large), partial, 32)
            raise AssertionError("oversized source unexpectedly copied")
        except ValueError:
            pass
        assert not partial.exists()

        # Optional host-derived files are copied only from the explicit list.
        copied_names = {str(pathlib.PurePosixPath(k).name) for k in report["copied"]}
        assert copied_names <= {"ld.so.cache", "services", "protocols", "ca-certificates.crt"}
        for path in etc.rglob("*"):
            if path.is_file():
                assert path.stat().st_mode & 0o222 == 0, path

    print("MINIMAL_ETC_GENERATION=PASS")
    print("MINIMAL_ETC_ALLOWLIST=PASS")
    print("MINIMAL_ETC_SYMLINK_SOURCE_REJECTION=PASS")
    print("MINIMAL_ETC_EXISTING_DESTINATION_PRESERVED=PASS")
    print("MINIMAL_ETC_SIZE_LIMIT_CLEANUP=PASS")


if __name__ == "__main__":
    main()
