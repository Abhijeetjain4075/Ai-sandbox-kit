"""Strict runtime-policy schema and fail-closed loading tests."""
from __future__ import annotations
import json
import os
import pathlib
import tempfile
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import sandboxctl

BASE = {
    "runtime_policy": {
        "schema_version": 1,
        "defaults": {"wall_timeout_seconds": 300, "memory_mib": 3072, "disk_mib": 1024, "file_mib": 256},
        "maxima": {"wall_timeout_seconds": 1800, "memory_mib": 3072, "disk_mib": 2048, "file_mib": 512},
        "network_mode": "isolated",
    }
}


def rejected(doc):
    try:
        sandboxctl.validate_runtime_policy(doc)
    except (ValueError, SystemExit):
        return True
    return False


def main():
    valid = sandboxctl.validate_runtime_policy(BASE)
    assert valid["defaults"]["wall_timeout_seconds"] == 300
    assert valid["network_mode"] == "isolated"

    # Regression: the exact bundled policy must load, not only synthetic fixtures.
    bundled = sandboxctl.load_runtime_policy(sandboxctl.POLICY_FILE)
    assert bundled["schema_version"] == 1
    assert bundled["network_mode"] == "isolated"

    cases = []
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["unexpected"] = True; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["schema_version"] = True; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["defaults"]["memory_mib"] = True; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["maxima"]["memory_mib"] = 4096; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["defaults"]["disk_mib"] = 2049; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["defaults"]["file_mib"] = 513; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["defaults"]["wall_timeout_seconds"] = 1801; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["maxima"]["disk_mib"] = 32; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["network_mode"] = "unrestricted"; cases.append(doc)
    doc = json.loads(json.dumps(BASE)); doc["runtime_policy"]["defaults"]["memory_mib"] = 3072; doc["runtime_policy"]["maxima"]["memory_mib"] = 1024; cases.append(doc)
    assert all(rejected(doc) for doc in cases), "one or more malformed policies were accepted"

    with tempfile.TemporaryDirectory(prefix="aisandbox-policy-") as td:
        target = pathlib.Path(td) / "policy.json"
        target.write_text(json.dumps(BASE))
        os.chmod(target, 0o666)
        try:
            sandboxctl.load_runtime_policy(target)
            raise AssertionError("group/world-writable policy accepted")
        except SystemExit as exc:
            assert "group- or world-writable" in str(exc)
        os.chmod(target, 0o600)
        assert sandboxctl.load_runtime_policy(target)["schema_version"] == 1
        link = pathlib.Path(td) / "policy-link.json"
        link.symlink_to(target)
        try:
            sandboxctl.load_runtime_policy(link)
            raise AssertionError("symlinked policy accepted")
        except SystemExit as exc:
            assert "safely open" in str(exc)

    duplicate = '{"runtime_policy":{},"runtime_policy":{}}'
    with tempfile.TemporaryDirectory(prefix="aisandbox-policy-duplicate-") as td:
        duplicate_path = pathlib.Path(td) / "duplicate.json"
        duplicate_path.write_text(duplicate)
        os.chmod(duplicate_path, 0o600)
        try:
            sandboxctl.load_runtime_policy(duplicate_path)
            raise AssertionError("duplicate JSON keys accepted")
        except SystemExit as exc:
            assert "duplicate JSON key" in str(exc)

    print("RUNTIME_POLICY_VALID_SCHEMA=PASS")
    print(f"RUNTIME_POLICY_INVALID_CASES={len(cases)}_REJECTED")
    print("RUNTIME_POLICY_FILE_PERMISSION=PASS")
    print("RUNTIME_POLICY_SYMLINK=PASS")
    print("RUNTIME_POLICY_DUPLICATE_KEYS=PASS")


if __name__ == "__main__":
    main()
