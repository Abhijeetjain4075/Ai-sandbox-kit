"""Integration checks for the current hosted session sandbox. Run via controller host."""
from __future__ import annotations
import os
import pathlib
import subprocess
import sys
import uuid

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import sandboxctl as sandbox_controller
import sandbox_bootstrap
CTL = ROOT / "sandboxctl.py"
WORKSPACES = sandbox_controller.WORKSPACES
OPT_ALLOWED_TOP = sorted({root.relative_to("/opt").parts[0] for root in sandbox_bootstrap.runtime_opt_roots()})


def run(*args, expect=0, timeout=120, extra_env=None):
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    proc = subprocess.Popen([sys.executable, str(CTL), *args], text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=env, start_new_session=True)
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(proc.pid, 9)
        except ProcessLookupError:
            pass
        stdout, stderr = proc.communicate()
        raise AssertionError(f"{args!r}: controller timed out after {timeout}s\nstdout={stdout}\nstderr={stderr}")
    if proc.returncode != expect:
        raise AssertionError(f"{args!r}: exit={proc.returncode}\nstdout={stdout}\nstderr={stderr}")
    return stdout + stderr


qa_name = "qa-" + uuid.uuid4().hex[:8]
path_qa_name = "path-qa-" + uuid.uuid4().hex[:8]
run("create", qa_name)
probe = r'''
import os, socket, pathlib, ctypes, subprocess, resource
assert os.getcwd() == "/workspace"
assert os.getpid() == 1, ("task is not PID namespace init", os.getpid())
assert os.getgroups() == [], os.getgroups()
assert resource.getrlimit(resource.RLIMIT_AS) == (2048 * 1024 * 1024, 2048 * 1024 * 1024)
assert resource.getrlimit(resource.RLIMIT_CPU) == (45, 47)
assert resource.getrlimit(resource.RLIMIT_FSIZE) == (256 * 1024 * 1024, 256 * 1024 * 1024)
assert resource.getrlimit(resource.RLIMIT_NPROC) == (64, 64)
assert resource.getrlimit(resource.RLIMIT_NOFILE) == (256, 256)
assert resource.getrlimit(resource.RLIMIT_CORE) == (0, 0)
assert resource.getrlimit(resource.RLIMIT_STACK) == (64 * 1024 * 1024, 64 * 1024 * 1024)
libc_prctl = ctypes.CDLL(None, use_errno=True).prctl
libc_prctl.restype = ctypes.c_int
assert libc_prctl(39, 0, 0, 0, 0) == 1  # PR_GET_NO_NEW_PRIVS
for secret_key in ("OPENAI_API_KEY", "AWS_SECRET_ACCESS_KEY", "GITHUB_TOKEN", "HTTP_PROXY", "HTTPS_PROXY"):
    assert secret_key not in os.environ, "secret/proxy leaked: " + secret_key
assert not pathlib.Path("/mnt").exists()
assert not pathlib.Path("/home/oai").exists()
assert not pathlib.Path("/proc/self").exists()
assert not pathlib.Path("/sys/fs/cgroup/cgroup.controllers").exists()
# The task receives a generated minimal /etc, not the host's /etc tree.
etc_entries = {p.name for p in pathlib.Path("/etc").iterdir()}
assert {"passwd", "group", "nsswitch.conf", "hosts"}.issubset(etc_entries), etc_entries
opt_entries = {p.name for p in pathlib.Path("/opt").iterdir()}
allowed_opt_entries = set(__ALLOWED_OPT_TOP__)
assert opt_entries <= allowed_opt_entries, (opt_entries, allowed_opt_entries)
assert etc_entries <= {"passwd", "group", "nsswitch.conf", "hosts", "ld.so.cache", "services", "protocols", "ssl"}, etc_entries
for forbidden in ("shadow", "gshadow", "sudoers", "machine-id", "resolv.conf", "ld.so.preload"):
    assert not pathlib.Path("/etc", forbidden).exists(), forbidden
assert pathlib.Path("/etc/hosts").read_text().strip().startswith("127.0.0.1 localhost")
assert "hosts: files" in pathlib.Path("/etc/nsswitch.conf").read_text()
import pwd, grp
assert pwd.getpwuid(0).pw_name == "root"
assert grp.getgrgid(0).gr_name == "root"
assert socket.socket().connect_ex(("1.1.1.1", 443)) != 0
pathlib.Path("outputs/qa.txt").write_text("sandbox-ok")
pathlib.Path("/tmp/qa-tmp.txt").write_text("tmpfs-ok")
for p in ("/etc/.sandbox-test", "/usr/.sandbox-test", "/.sandbox-test"):
    try:
        pathlib.Path(p).write_text("x")
        raise AssertionError("read-only mount unexpectedly writable: " + p)
    except OSError:
        pass
p = pathlib.Path("/tmp/noexec.sh")
p.write_text("#!/bin/sh\necho nope\n")
p.chmod(0o700)
try:
    subprocess.run([str(p)], check=False, capture_output=True)
    raise AssertionError("/tmp unexpectedly executable")
except PermissionError:
    pass
libcap = ctypes.CDLL("libcap.so.2")
libcap.cap_get_proc.restype = ctypes.c_void_p
libcap.cap_to_text.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ssize_t)]
libcap.cap_to_text.restype = ctypes.c_void_p
libcap.cap_free.argtypes = [ctypes.c_void_p]
cap = libcap.cap_get_proc()
assert cap
length = ctypes.c_ssize_t()
cap_text = libcap.cap_to_text(cap, ctypes.byref(length))
assert cap_text and ctypes.string_at(cap_text).decode() == "="
libcap.cap_free(cap_text)
libcap.cap_free(cap)
r = subprocess.run(["/usr/bin/unshare", "--user", "--map-root-user", "true"], capture_output=True)
assert r.returncode != 0
print("chroot, read-only/noexec mounts, workspace/tmp writes, network isolation, capabilities and seccomp: PASS")
'''
probe = probe.replace("__ALLOWED_OPT_TOP__", repr(OPT_ALLOWED_TOP))
out = run("run", "--timeout", "45", "--memory-mib", "2048", qa_name, "--", "python", "-c", probe,
          extra_env={"OPENAI_API_KEY": "sandbox-test-secret", "AWS_SECRET_ACCESS_KEY": "sandbox-test-secret", "GITHUB_TOKEN": "sandbox-test-secret", "HTTPS_PROXY": "http://127.0.0.1:9999"})
assert "PASS" in out
print("STAGE isolation=PASS", flush=True)

science_probe = """
import importlib.util
core = ("numpy", "scipy", "pandas", "sklearn", "matplotlib", "PIL")
missing = [name for name in core if importlib.util.find_spec(name) is None]
assert not missing, ("core scientific stack missing", missing)
import numpy, scipy, pandas, sklearn, matplotlib, PIL
optional = []
for name in ("torch", "jax"):
    if importlib.util.find_spec(name) is not None:
        __import__(name)
        optional.append(name)
print("scientific imports: PASS; optional=" + ",".join(optional))
"""
out = run("run", "--timeout", "90", "--memory-mib", "3072", qa_name, "--", "python", "-c", science_probe)
assert "scientific imports: PASS" in out
print("STAGE scientific=PASS", flush=True)

out = run("run", "--timeout", "60", qa_name, "--", "node", "--version")
assert "v22.16.0" in out
print("STAGE node=PASS", flush=True)

out = run("run", "--timeout", "60", qa_name, "--", "python", "inputs/numerical_smoke.py")
assert '"finite_output": true' in out
print("STAGE numerical-smoke=PASS", flush=True)

# Verify clone3 compatibility, io_uring denial, namespace clone denial, and
# ordinary pthread compatibility with the installed seccomp filter.
probe_bin = WORKSPACES / qa_name / "inputs" / "syscall_probe"
subprocess.run(["gcc", "-O2", "-pthread", str(ROOT / "tests" / "syscall_probe.c"), "-o", str(probe_bin)], check=True)
out = run("run", "--timeout", "60", qa_name, "--", "inputs/syscall_probe")
assert "pthread=PASS" in out and "clone_namespace=DENIED" in out
print("STAGE syscall-probe=PASS", flush=True)

c_test = r'''
from pathlib import Path
import subprocess
Path("outputs/hello.c").write_text('#include <stdio.h>\nint main(void){puts("C toolchain: PASS");return 0;}\n')
subprocess.run(["gcc", "-O2", "outputs/hello.c", "-o", "outputs/hello"], check=True)
subprocess.run(["outputs/hello"], check=True)
'''
out = run("run", "--timeout", "60", qa_name, "--", "python", "-c", c_test)
assert "C toolchain: PASS" in out
print("STAGE compiler=PASS", flush=True)

print("STAGE timeout-start", flush=True)
out = run("run", "--timeout", "2", "--memory-mib", "1024", qa_name, "--", "python", "-c", "import time; time.sleep(10)", expect=124, timeout=15)
print("STAGE timeout-run-returned", flush=True)
assert "wall-time limit exceeded" in out
print("STAGE timeout=PASS", flush=True)

# RLIMIT_FSIZE regression: a task cannot grow a single file past its configured limit.
print("STAGE file-size-start", flush=True)
out = run("run", "--timeout", "30", "--file-mib", "1", qa_name, "--", "python", "-c",
          "from pathlib import Path; p=Path('outputs/fsize.bin'); f=p.open('wb');\ntry: f.write(b'x'*(2*1024*1024)); f.flush()\nexcept OSError as e: print(type(e).__name__, e.errno)\nf.close()")
print("STAGE file-size-run-returned", flush=True)
fsize_path = WORKSPACES / qa_name / "outputs" / "fsize.bin"
fsize_size = fsize_path.stat().st_size
print(f"STAGE file-size-measured={fsize_size}", flush=True)
assert fsize_size <= 1024 * 1024
print("STAGE file-size-limit=PASS", flush=True)

# Symlink-poisoning regression: an untrusted task may leave a nested symlink,
# but the privileged controller must refuse to follow it on the next invocation.
print("STAGE path-poison-start", flush=True)
# `run` creates the workspace when it does not yet exist.
run("run", "--timeout", "30", path_qa_name, "--", "python", "-c",
    "import pathlib; p=pathlib.Path('.cache/matplotlib'); p.rmdir(); p.symlink_to('/etc')", timeout=45)
print("STAGE path-poison-run-returned", flush=True)
p = subprocess.run([sys.executable, str(CTL), "create", path_qa_name], text=True, capture_output=True, timeout=15)
assert p.returncode != 0 and "symlink" in (p.stdout + p.stderr).lower()
assert os.stat("/etc").st_uid == 0 and os.stat("/etc").st_gid == 0
print("STAGE path-symlink-poisoning=PASS", flush=True)

export_name = f"qa-validation-{uuid.uuid4().hex[:8]}.txt"
print("STAGE successful-export-start", flush=True)
out = run("export", qa_name, "outputs/qa.txt", "--name", export_name, timeout=30)
assert "Exported artifact" in out
print("STAGE successful-export-returned", flush=True)
artifact_path = ROOT / "artifacts" / export_name
assert artifact_path.read_text() == "sandbox-ok"
assert artifact_path.stat().st_mode & 0o077 == 0
assert f"sha256=" in out
# Sparse oversized files must be rejected before creating an artifact.
large_name = "export-limit-probe.bin"
large_path = WORKSPACES / qa_name / "outputs" / large_name
with large_path.open("wb") as f:
    f.truncate(512 * 1024 * 1024 + 1)
print("STAGE export-limit-start", flush=True)
large = subprocess.run([sys.executable, str(CTL), "export", qa_name, f"outputs/{large_name}",
                        "--name", f"too-large-{uuid.uuid4().hex[:8]}.bin"],
                       text=True, capture_output=True, timeout=15)
assert large.returncode != 0 and "hard export limit" in (large.stdout + large.stderr)
large_path.unlink()
print("STAGE export-limit=PASS", flush=True)
print("STAGE artifact-export=PASS", flush=True)
# The earlier path-poisoning test proves an untrusted task can leave a symlink
# inside its workspace. Create an equivalent export-source symlink directly in
# this disposable workspace to test the controller's O_NOFOLLOW export path
# without adding another namespace startup to the already extensive suite.
evil_source = WORKSPACES / qa_name / "outputs" / "export-evil"
evil_source.symlink_to("/etc/passwd")
print("STAGE malicious-symlink-export-start", flush=True)
blocked = subprocess.run([sys.executable, str(CTL), "export", qa_name, "outputs/export-evil", "--name", f"evil-{uuid.uuid4().hex[:8]}.txt"], text=True, capture_output=True, timeout=15)
assert blocked.returncode != 0 and "Safe artifact export failed" in (blocked.stdout + blocked.stderr)
print("STAGE malicious-symlink-export=PASS", flush=True)
print("ALL_SANDBOX_TESTS_PASSED", flush=True)
