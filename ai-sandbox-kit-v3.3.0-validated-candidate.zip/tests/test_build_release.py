"""Release builder path-safety and metadata tests."""
from __future__ import annotations
import importlib.util
import pathlib
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("build_release", ROOT / "scripts/build_release.py")
assert SPEC and SPEC.loader
module = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(module)


def main() -> None:
    accepted = ["README.md", "tests/test_build_release.py", ".github/workflows/ci.yml"]
    for path in accepted:
        assert str(module.safe_relative_path(path)) == path
    rejected = ["", "/etc/passwd", "../escape", "a/../b", "a//b", "a\\b", "a/./b", "a/" + "x" * 256]
    for path in rejected:
        try:
            module.safe_relative_path(path)
            raise AssertionError(f"unsafe path accepted: {path!r}")
        except ValueError:
            pass
    with tempfile.TemporaryDirectory(prefix="aisandbox-builder-symlink-") as td:
        root = pathlib.Path(td)
        (root / "release_files.txt").write_text("a.txt\nrelease_files.txt\nrelease.json\nsbom.cdx.json\nprovenance.json\n")
        (root / "release.json").write_text("{}\n")
        (root / "sbom.cdx.json").write_text("{}\n")
        (root / "provenance.json").write_text("{}\n")
        outside = root.parent / (root.name + "-outside")
        outside.write_text("do-not-read")
        (root / "a.txt").symlink_to(outside)
        try:
            module.inventory(root, module.load_release_paths(root))
            raise AssertionError("symlinked release input accepted")
        except ValueError as exc:
            assert "symlink" in str(exc) or "Too many levels" in str(exc)
        outside.unlink()
    print("RELEASE_PATH_VALIDATION=PASS")
    print("RELEASE_SYMLINK_REJECTION=PASS")


if __name__ == "__main__":
    main()
