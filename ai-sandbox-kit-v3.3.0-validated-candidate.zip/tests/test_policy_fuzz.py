"""Deterministic mutation tests for the strict runtime-policy validator."""
from __future__ import annotations
import copy
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import sandboxctl

BASE = {
    "runtime_policy": {
        "schema_version": 1,
        "defaults": {"wall_timeout_seconds": 300, "memory_mib": 3072,
                     "disk_mib": 1024, "file_mib": 256},
        "maxima": {"wall_timeout_seconds": 1800, "memory_mib": 3072,
                   "disk_mib": 2048, "file_mib": 512},
        "network_mode": "isolated",
    }
}


def rejected(value) -> bool:
    try:
        sandboxctl.validate_runtime_policy(value)
    except (TypeError, ValueError, SystemExit):
        return True
    return False


def main() -> None:
    rng = random.Random(0xA15A_B0A5)
    assert sandboxctl.validate_runtime_policy(BASE)["schema_version"] == 1
    invalid_values = [None, True, False, 0, -1, 1.5, "1", [], {}, [1],
                      10**20, "isolated ", "unrestricted", "host", "bridge"]
    fields = ("wall_timeout_seconds", "memory_mib", "disk_mib", "file_mib")
    attempts = 0
    for _ in range(1200):
        doc = copy.deepcopy(BASE)
        mutation = rng.randrange(5)
        if mutation == 0:
            doc["runtime_policy"][rng.choice(("extra", "unknown", "network", "schema"))] = object()
        elif mutation == 1:
            doc["runtime_policy"]["schema_version"] = rng.choice(invalid_values)
        elif mutation == 2:
            doc["runtime_policy"]["network_mode"] = rng.choice(invalid_values)
        else:
            group = rng.choice(("defaults", "maxima"))
            field = rng.choice(fields)
            doc["runtime_policy"][group][field] = rng.choice(invalid_values)
        assert rejected(doc), f"mutation unexpectedly accepted: {doc!r}"
        attempts += 1

    # Shape corruption and required-field deletion.
    for field in ("runtime_policy",):
        for value in invalid_values:
            assert rejected({field: value})
            attempts += 1
    for group in ("defaults", "maxima"):
        for value in invalid_values:
            doc = copy.deepcopy(BASE)
            doc["runtime_policy"][group] = value
            assert rejected(doc)
            attempts += 1
    for field in ("schema_version", "defaults", "maxima", "network_mode"):
        doc = copy.deepcopy(BASE)
        del doc["runtime_policy"][field]
        assert rejected(doc)
        attempts += 1
    print(f"POLICY_MUTATION_TESTS={attempts}_REJECTED")


if __name__ == "__main__":
    main()
