#define _GNU_SOURCE
#include <errno.h>
#include <linux/sched.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <unistd.h>

static void *thread_fn(void *arg) { return arg; }
static int child_fn(void *arg) { (void)arg; _exit(0); }

int main(void) {
    pthread_t thread;
    int trc = pthread_create(&thread, NULL, thread_fn, NULL);
    if (trc != 0) {
        fprintf(stderr, "pthread_create failed: %s\n", strerror(trc));
        return 10;
    }
    pthread_join(thread, NULL);

#ifdef SYS_clone3
    errno = 0;
    long c3 = syscall(SYS_clone3, NULL, 88);
    int c3e = errno;
    printf("clone3_errno=%d\n", c3e);
    if (c3 != -1 || c3e != ENOSYS) return 11;
#endif
#ifdef SYS_io_uring_setup
    errno = 0;
    long ur = syscall(SYS_io_uring_setup, 0, NULL);
    int ure = errno;
    printf("io_uring_errno=%d\n", ure);
    if (ur != -1 || ure != EPERM) return 12;
#endif

    size_t size = 1024 * 1024;
    void *stack = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (stack == MAP_FAILED) return 13;
    errno = 0;
    int pid = clone(child_fn, (char *)stack + size, CLONE_NEWUSER | SIGCHLD, NULL);
    int ce = errno;
    printf("clone_newuser_errno=%d\n", ce);
    if (pid != -1 || ce != EPERM) return 14;
    errno = 0;
    pid = clone(child_fn, (char *)stack + size, CLONE_NEWTIME | SIGCHLD, NULL);
    int te = errno;
    printf("clone_newtime_errno=%d\n", te);
    if (pid != -1 || te != EPERM) return 15;
    munmap(stack, size);
    puts("pthread=PASS; clone3=DENIED_ENOSYS; io_uring=DENIED; clone_namespace=DENIED; clone_newtime=DENIED");
    return 0;
}
