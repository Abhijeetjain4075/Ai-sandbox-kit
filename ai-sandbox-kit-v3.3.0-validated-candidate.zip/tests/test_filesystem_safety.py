"""Descriptor-based filesystem traversal regression tests."""
from __future__ import annotations
import pathlib
import os
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import sandboxctl


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="aisandbox-fs-root-") as td:
        base = pathlib.Path(td)
        tree = base / "tree"
        outside = base / "outside"
        tree.mkdir(); outside.mkdir()
        (tree / "owned.txt").write_bytes(b"owned-data")
        (outside / "large.bin").write_bytes(b"x" * (2 * 1024 * 1024))
        (tree / "escape").symlink_to(outside, target_is_directory=True)
        counted = sandboxctl.total_tree_bytes(tree)
        assert counted < 1024, counted
        assert counted >= len(b"owned-data")

        # Broken and dangling links are counted as link metadata, not followed.
        (tree / "dangling").symlink_to(base / "missing")
        counted_again = sandboxctl.total_tree_bytes(tree)
        assert counted_again < 1024, counted_again


    # If a source file grows after the initial fstat size check, abort and
    # remove the partially-created artifact rather than exposing it as complete.
    import argparse
    from unittest import mock
    import uuid
    with tempfile.TemporaryDirectory(prefix="aisandbox-export-growth-") as td:
        workspace_name = "export-growth-" + uuid.uuid4().hex[:8]
        workspace = sandboxctl.ensure_workspace(workspace_name)
        source = workspace / "outputs" / "growth.txt"
        source.write_bytes(b"1234")
        artifact_name = "growth-" + uuid.uuid4().hex[:8] + ".txt"
        real_read = sandboxctl.os.read
        source_inode = source.stat().st_ino
        original_limit = sandboxctl.MAX_EXPORT_BYTES
        read_state = {"count": 0}
        def grow_source_read(fd, count):
            st = os.fstat(fd)
            if st.st_ino == source_inode:
                read_state["count"] += 1
                return b"123" if read_state["count"] == 1 else b"456"
            return real_read(fd, count)
        sandboxctl.MAX_EXPORT_BYTES = 5
        try:
            with mock.patch.object(sandboxctl.os, "read", side_effect=grow_source_read):
                try:
                    sandboxctl.cmd_export(argparse.Namespace(
                        workspace=workspace_name, path="outputs/growth.txt", name=artifact_name))
                    raise AssertionError("growing export source exceeded limit without rejection")
                except SystemExit as exc:
                    assert "grew beyond" in str(exc)
            assert not (sandboxctl.ARTIFACTS / artifact_name).exists()
        finally:
            sandboxctl.MAX_EXPORT_BYTES = original_limit

    print("FILESYSTEM_SYMLINK_NOFOLLOW=PASS")
    print("EXPORT_PARTIAL_ARTIFACT_CLEANUP=PASS")


if __name__ == "__main__":
    main()
