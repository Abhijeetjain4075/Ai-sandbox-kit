#!/usr/bin/env python3
"""Build a minimal per-task chroot in a private mount namespace, then exec."""
from __future__ import annotations
import ctypes
import errno
import os
import shutil
import stat
import sys
from pathlib import Path

# Linux mount flags
MS_RDONLY = 1
MS_NOSUID = 2
MS_NODEV = 4
MS_NOEXEC = 8
MS_REMOUNT = 32
MS_BIND = 4096
MS_REC = 16384
MS_PRIVATE = 1 << 18

libc = ctypes.CDLL(None, use_errno=True)
libc.mount.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_ulong, ctypes.c_char_p]
libc.mount.restype = ctypes.c_int
libc.prctl.restype = ctypes.c_int
libc.syscall.restype = ctypes.c_long


def cpath(p: str | Path) -> bytes:
    return os.fsencode(str(p))


def do_mount(source, target, fstype=None, flags=0, data=None):
    src_b = None if source is None else cpath(source)
    fs_b = None if fstype is None else cpath(fstype)
    data_b = None if data is None else cpath(data)
    rc = libc.mount(src_b, cpath(target), fs_b, ctypes.c_ulong(flags), data_b)
    if rc != 0:
        e = ctypes.get_errno()
        raise OSError(e, os.strerror(e), f"source={source!r}, target={target!r}, flags={flags:#x}")


def ensure_dir(path: Path, mode=0o755):
    path.mkdir(parents=True, exist_ok=True, mode=mode)


def bind_ro(source: str, target: Path):
    do_mount(source, target, flags=MS_BIND)
    do_mount(None, target, flags=MS_BIND | MS_REMOUNT | MS_RDONLY | MS_NOSUID | MS_NODEV)


def _open_absolute_regular_nofollow(path: str) -> int:
    """Open an absolute path while refusing symlinks in every component."""
    candidate = Path(path)
    if not candidate.is_absolute() or any(part in ("", ".", "..") for part in candidate.parts[1:]):
        raise ValueError(f"expected canonical absolute path: {path!r}")
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    directory_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | nofollow
    current = os.open("/", directory_flags)
    try:
        for component in candidate.parts[1:-1]:
            next_fd = os.open(component, directory_flags, dir_fd=current)
            os.close(current)
            current = next_fd
        return os.open(candidate.parts[-1], os.O_RDONLY | os.O_CLOEXEC | nofollow, dir_fd=current)
    finally:
        os.close(current)


def copy_regular_file_nofollow(source: str, target: Path, max_bytes: int) -> int:
    """Copy one allowlisted host file into the private rootfs without following links."""
    src_fd = _open_absolute_regular_nofollow(source)
    dst_fd = -1
    destination_created = False
    try:
        src_stat = os.fstat(src_fd)
        if not stat.S_ISREG(src_stat.st_mode):
            raise ValueError(f"allowlisted runtime file is not regular: {source}")
        if src_stat.st_size < 0 or src_stat.st_size > max_bytes:
            raise ValueError(f"allowlisted runtime file exceeds size limit: {source}")
        ensure_dir(target.parent, 0o755)
        dst_fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0), 0o444)
        destination_created = True
        copied = 0
        while True:
            chunk = os.read(src_fd, min(64 * 1024, max_bytes - copied + 1))
            if not chunk:
                break
            copied += len(chunk)
            if copied > max_bytes:
                raise ValueError(f"allowlisted runtime file grew beyond size limit: {source}")
            view = memoryview(chunk)
            while view:
                n = os.write(dst_fd, view)
                if n <= 0:
                    raise OSError("short write copying runtime file")
                view = view[n:]
        if copied != src_stat.st_size:
            raise ValueError(f"allowlisted runtime file changed size during copy: {source}")
        if os.fstat(src_fd).st_ino != src_stat.st_ino or os.fstat(src_fd).st_dev != src_stat.st_dev:
            raise ValueError(f"allowlisted runtime file identity changed: {source}")
        os.fchmod(dst_fd, 0o444)
        os.fsync(dst_fd)
        return copied
    except Exception:
        if destination_created:
            try:
                target.unlink()
            except FileNotFoundError:
                pass
        raise
    finally:
        if dst_fd >= 0:
            os.close(dst_fd)
        os.close(src_fd)


def build_minimal_etc(etc_root: Path) -> dict:
    """Generate a minimal task /etc without exposing the host /etc tree.

    Host-derived files are limited to the dynamic-linker cache, public service
    and protocol databases, and the system CA bundle. Account/NSS/hosts files
    are synthetic and DNS resolver configuration, shadow data, preload files,
    machine identifiers and host-specific credentials are intentionally absent.
    """
    ensure_dir(etc_root, 0o755)
    generated = {
        "passwd": ("root:x:0:0:Sandbox Root:/root:/usr/sbin/nologin\n"
                   "nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin\n"),
        "group": "root:x:0:\nnogroup:x:65534:\n",
        "nsswitch.conf": ("passwd: files\n" "group: files\n" "shadow: files\n"
                          "hosts: files\n" "networks: files\n" "protocols: files\n"
                          "services: files\n"),
        "hosts": "127.0.0.1 localhost\n::1 localhost ip6-localhost ip6-loopback\n",
    }
    for name, content in generated.items():
        target = etc_root / name
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0), 0o444)
        try:
            raw = content.encode("utf-8")
            view = memoryview(raw)
            while view:
                n = os.write(fd, view)
                if n <= 0:
                    raise OSError("short write creating synthetic runtime configuration")
                view = view[n:]
            os.fsync(fd)
        finally:
            os.close(fd)

    copied = {}
    optional_files = {
        "/etc/ld.so.cache": (etc_root / "ld.so.cache", 2 * 1024 * 1024),
        "/etc/services": (etc_root / "services", 256 * 1024),
        "/etc/protocols": (etc_root / "protocols", 64 * 1024),
        "/etc/ssl/certs/ca-certificates.crt": (etc_root / "ssl" / "certs" / "ca-certificates.crt", 2 * 1024 * 1024),
    }
    for source, (target, limit) in optional_files.items():
        try:
            copied[source] = copy_regular_file_nofollow(source, target, limit)
        except FileNotFoundError:
            # A minimal host image may not ship a particular optional database.
            continue
    return {"generated": sorted(generated), "copied": copied}


def bind_rw_private(source: str, target: Path):
    do_mount(source, target, flags=MS_BIND)
    do_mount(None, target, flags=MS_BIND | MS_REMOUNT | MS_NOSUID | MS_NODEV)


def mount_tmpfs(target: Path, options: str):
    # Scratch filesystems must not be executable; use /workspace for binaries.
    do_mount("tmpfs", target, "tmpfs", MS_NOSUID | MS_NODEV | MS_NOEXEC, options)


def runtime_opt_roots() -> list[Path]:
    """Return only the trusted Python/toolchain roots required from host /opt.

    The entire host /opt tree may contain unrelated services, repositories,
    browser assets or credentials. Mount only the active Python prefix and
    discovered executables' version roots, preserving their absolute paths.
    """
    roots: set[Path] = set()
    for prefix in (sys.prefix, sys.base_prefix):
        candidate = Path(prefix).resolve()
        try:
            candidate.relative_to("/opt")
        except ValueError:
            continue
        if candidate != Path("/opt") and candidate.is_dir():
            roots.add(candidate)

    for tool in ("node", "npm", "git", "gcc", "g++", "clang", "go", "java", "ffmpeg", "pandoc"):
        found = shutil.which(tool)
        if not found:
            continue
        candidate = Path(found).resolve()
        try:
            relative = candidate.relative_to("/opt")
        except ValueError:
            continue
        if not relative.parts:
            continue
        # Toolchains conventionally keep executables in <runtime-root>/bin.
        root = candidate.parent.parent if candidate.parent.name == "bin" else candidate.parent
        if root != Path("/opt") and root.is_dir():
            roots.add(root)

    # Keep the shallowest roots; a parent mount already contains its children.
    result: list[Path] = []
    for root in sorted(roots, key=lambda item: (len(item.parts), str(item))):
        if not any(parent == root or parent in root.parents for parent in result):
            result.append(root)
    return result


def bind_runtime_opt(rootfs: Path) -> list[str]:
    """Mount only selected runtime roots beneath /opt, never the complete host tree."""
    mounted = []
    for source in runtime_opt_roots():
        relative = source.relative_to("/")
        target = rootfs / relative
        ensure_dir(target.parent, 0o755)
        ensure_dir(target, 0o755)
        bind_ro(str(source), target)
        mounted.append(str(source))
    return mounted


def drop_all_capabilities_and_lock_privilege():
    # The process is root only inside a user namespace mapped to host UID 65534.
    # Drop the namespace's capability bounding set, secure root semantics,
    # permitted/effective/inheritable capabilities, then set no_new_privs.
    PR_SET_SECUREBITS = 28
    PR_SET_NO_NEW_PRIVS = 38
    PR_CAPBSET_DROP = 24
    securebits = (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 6) | (1 << 7)
    if libc.prctl(PR_SET_SECUREBITS, ctypes.c_ulong(securebits), 0, 0, 0) != 0:
        e = ctypes.get_errno(); raise OSError(e, "PR_SET_SECUREBITS failed")
    for cap in range(0, 64):
        if libc.prctl(PR_CAPBSET_DROP, ctypes.c_ulong(cap), 0, 0, 0) != 0:
            e = ctypes.get_errno()
            if e not in (errno.EINVAL, errno.EOPNOTSUPP):
                raise OSError(e, f"PR_CAPBSET_DROP({cap}) failed")
    # Use libcap rather than a hard-coded architecture-specific capset syscall.
    libcap = ctypes.CDLL("libcap.so.2", use_errno=True)
    libcap.cap_init.restype = ctypes.c_void_p
    libcap.cap_clear.argtypes = [ctypes.c_void_p]
    libcap.cap_clear.restype = ctypes.c_int
    libcap.cap_set_proc.argtypes = [ctypes.c_void_p]
    libcap.cap_set_proc.restype = ctypes.c_int
    libcap.cap_free.argtypes = [ctypes.c_void_p]
    libcap.cap_free.restype = ctypes.c_int
    caps = libcap.cap_init()
    if not caps:
        raise RuntimeError("cap_init failed")
    try:
        if libcap.cap_clear(caps) != 0 or libcap.cap_set_proc(caps) != 0:
            e = ctypes.get_errno(); raise OSError(e, "libcap could not clear process capabilities")
    finally:
        libcap.cap_free(caps)
    if libc.prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0:
        e = ctypes.get_errno(); raise OSError(e, "PR_SET_NO_NEW_PRIVS failed")


def install_seccomp():
    # Default allow keeps normal language runtimes usable; block operations
    # that could alter namespaces/mount topology, escape chroot, inspect other
    # processes, or load kernel facilities. Network is separately isolated.
    lib = ctypes.CDLL("libseccomp.so.2")
    lib.seccomp_init.argtypes = [ctypes.c_uint32]
    lib.seccomp_init.restype = ctypes.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    lib.seccomp_syscall_resolve_name.restype = ctypes.c_int
    lib.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    lib.seccomp_rule_add.restype = ctypes.c_int
    class ScmpArgCmp(ctypes.Structure):
        _fields_ = [("arg", ctypes.c_uint), ("op", ctypes.c_int),
                    ("datum_a", ctypes.c_uint64), ("datum_b", ctypes.c_uint64)]
    lib.seccomp_rule_add_array.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int,
                                           ctypes.c_uint, ctypes.POINTER(ScmpArgCmp)]
    lib.seccomp_rule_add_array.restype = ctypes.c_int
    lib.seccomp_load.argtypes = [ctypes.c_void_p]
    lib.seccomp_load.restype = ctypes.c_int
    lib.seccomp_release.argtypes = [ctypes.c_void_p]
    lib.seccomp_release.restype = None
    SCMP_ACT_ALLOW = 0x7FFF0000
    SCMP_ACT_ERRNO = 0x00050000 | errno.EPERM
    ctx = lib.seccomp_init(SCMP_ACT_ALLOW)
    if not ctx:
        raise RuntimeError("seccomp_init failed")
    blocked = [
        "mount", "umount2", "pivot_root", "chroot", "unshare", "setns",
        "io_uring_setup", "io_uring_enter", "io_uring_register",
        "pidfd_open", "pidfd_send_signal", "kcmp",
        "mount_setattr", "move_mount", "open_tree", "fsopen", "fsmount", "fspick",
        "ptrace", "process_vm_readv", "process_vm_writev", "process_madvise",
        "pidfd_getfd", "open_by_handle_at", "name_to_handle_at",
        "bpf", "perf_event_open", "userfaultfd", "memfd_secret",
        "keyctl", "add_key", "request_key",
        "init_module", "finit_module", "delete_module", "kexec_load", "kexec_file_load",
        "reboot", "swapon", "swapoff", "iopl", "ioperm", "syslog", "acct",
        "settimeofday", "adjtimex", "clock_settime", "lookup_dcookie", "quotactl",
    ]
    try:
        for name in blocked:
            nr = lib.seccomp_syscall_resolve_name(name.encode())
            if nr < 0:
                continue
            rc = lib.seccomp_rule_add(ctx, SCMP_ACT_ERRNO, nr, 0)
            if rc != 0:
                raise RuntimeError(f"seccomp_rule_add({name}) failed: {rc}")
        # glibc may probe clone3 for pthread creation and only fall back to
        # legacy clone when the kernel reports ENOSYS. Return ENOSYS, not EPERM.
        clone3_nr = lib.seccomp_syscall_resolve_name(b"clone3")
        if clone3_nr >= 0:
            rc = lib.seccomp_rule_add(ctx, 0x00050000 | errno.ENOSYS, clone3_nr, 0)
            if rc != 0:
                raise RuntimeError(f"seccomp_rule_add(clone3) failed: {rc}")
        # Block clone(2) only when it requests a new namespace. Ordinary
        # pthread flags remain permitted. SCMP_CMP_MASKED_EQ is enum value 7.
        class ScmpArgCmp(ctypes.Structure):
            _fields_ = [("arg", ctypes.c_uint), ("op", ctypes.c_int),
                        ("datum_a", ctypes.c_uint64), ("datum_b", ctypes.c_uint64)]
        lib.seccomp_rule_add_array.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int,
                                               ctypes.c_uint, ctypes.POINTER(ScmpArgCmp)]
        lib.seccomp_rule_add_array.restype = ctypes.c_int
        clone_nr = lib.seccomp_syscall_resolve_name(b"clone")
        # Include CLONE_NEWTIME (0x00000080) as well as the other namespace
        # flags. This is checked as a masked comparison against clone(2) arg0.
        namespace_flags = (0x00000080, 0x00020000, 0x02000000, 0x04000000,
                           0x08000000, 0x10000000, 0x20000000, 0x40000000)
        if clone_nr >= 0:
            for flag in namespace_flags:
                cmp = ScmpArgCmp(0, 7, flag, flag)
                rc = lib.seccomp_rule_add_array(ctx, SCMP_ACT_ERRNO, clone_nr, 1,
                                                ctypes.byref(cmp))
                if rc != 0:
                    raise RuntimeError(f"seccomp clone namespace rule failed: {rc}")
        rc = lib.seccomp_load(ctx)
        if rc != 0:
            raise RuntimeError(f"seccomp_load failed: {rc}")
    finally:
        lib.seccomp_release(ctx)


def main():
    if len(sys.argv) < 5 or sys.argv[3] != "--":
        raise SystemExit("bootstrap usage: sandbox_bootstrap.py ROOTFS WORKSPACE_PATH -- COMMAND [ARGS...]")
    rootfs = Path(sys.argv[1]).resolve()
    workspace_path = sys.argv[2]
    command = sys.argv[4:]
    if not rootfs.is_dir() or not os.path.isdir(workspace_path) or not command:
        raise SystemExit("Invalid rootfs/workspace path/command")
    if os.getuid() != 0 or os.getgid() != 0:
        raise SystemExit("Bootstrap must run as namespace root after host UID drop")

    # The workspace resides on /dev/shm (tmpfs), whose parent path is
    # searchable by the mapped task identity. Using a canonical path rather
    # than an fchdir-only anonymous dentry is required on some kernels: bind
    # mounting an fchdir-only source can fail with EINVAL.
    os.chdir(workspace_path)
    workspace_stat = os.stat(".")

    # Do not propagate mount changes back to the host namespace.
    do_mount(None, "/", flags=MS_REC | MS_PRIVATE)

    # Build an ephemeral minimal root filesystem in this task's private mount namespace.
    mount_tmpfs(rootfs, "size=64m,mode=755")
    for name in ("usr", "opt", "etc", "dev", "tmp", "var", "run", "proc", "sys", "workspace"):
        ensure_dir(rootfs / name)
    os.symlink("usr/bin", rootfs / "bin")
    os.symlink("usr/sbin", rootfs / "sbin")
    os.symlink("usr/lib", rootfs / "lib")
    os.symlink("usr/lib64", rootfs / "lib64")

    bind_ro("/usr", rootfs / "usr")
    # Do not bind the complete host /opt tree; it can contain unrelated services,
    # repositories and tooling. Expose only the active Python/toolchain roots.
    bind_runtime_opt(rootfs)
    # Do not expose the host's complete /etc. Build a curated runtime config
    # with synthetic identity/NSS/hosts files and a small no-follow allowlist.
    build_minimal_etc(rootfs / "etc")
    bind_rw_private(workspace_path, rootfs / "workspace")

    mount_tmpfs(rootfs / "tmp", "size=512m,mode=1777")
    mount_tmpfs(rootfs / "var", "size=128m,mode=755")
    ensure_dir(rootfs / "var" / "tmp", 0o1777)
    os.chmod(rootfs / "var" / "tmp", 0o1777)
    mount_tmpfs(rootfs / "run", "size=32m,mode=755")

    # Minimal device surface; no host device directory is exposed.
    mount_tmpfs(rootfs / "dev", "size=16m,mode=755")
    for dev in ("null", "zero", "random", "urandom"):
        target = rootfs / "dev" / dev
        target.touch(mode=0o666, exist_ok=True)
        do_mount(f"/dev/{dev}", target, flags=MS_BIND)
    ensure_dir(rootfs / "dev" / "shm", 0o1777)
    os.chmod(rootfs / "dev" / "shm", 0o1777)
    mount_tmpfs(rootfs / "dev" / "shm", "size=64m,mode=1777")

    # Keep the root tree itself read-only; only the named mounts above are writable.
    do_mount(None, rootfs, flags=MS_REMOUNT | MS_RDONLY | MS_NOSUID | MS_NODEV)

    os.chdir(rootfs)
    os.chroot(".")
    os.chdir("/workspace")
    os.umask(0o077)
    os.closerange(3, 1 << 20)

    drop_all_capabilities_and_lock_privilege()
    install_seccomp()
    os.execvpe(command[0], command, os.environ.copy())


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"sandbox bootstrap failed: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        raise
