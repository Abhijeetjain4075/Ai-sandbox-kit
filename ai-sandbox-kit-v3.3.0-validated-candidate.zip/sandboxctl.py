#!/usr/bin/env python3
"""Best-effort, unprivileged execution harness for this ChatGPT session.

Security boundary: the outer hosted Kata container remains the primary boundary.
This inner runner adds user/mount/network/PID/IPC/UTS/cgroup namespaces, a per-run
chroot, read-only runtime mounts, a private writable workspace, seccomp deny rules,
capability dropping, UID/GID mapping, resource limits and wall-clock/disk monitoring.
Landlock is unavailable and this is not an independently audited microVM.
"""
from __future__ import annotations

import argparse
import ctypes
import ctypes.util
import fcntl
import json
import os
import platform
import pwd
import re
import resource
import shutil
import signal
import socket
import selectors
import hashlib
import stat
import subprocess
import sys
import time
import uuid
import tempfile
from pathlib import Path

import workspace_archive

ROOT = Path(__file__).resolve().parent
# Workspaces live on tmpfs because the hosted overlayfs mount cannot be bind-
# mounted from a user namespace on some supported hosts. This storage is session-
# local; durable results must be exported through the artifact API.
_WORKSPACE_SCOPE = hashlib.sha256(os.fsencode(str(ROOT))).hexdigest()[:12]
WORKSPACE_AREA_NAME = f"ai-sandbox-{os.getuid()}-{_WORKSPACE_SCOPE}"
WORKSPACE_AREA = Path("/dev/shm") / WORKSPACE_AREA_NAME
WORKSPACES = WORKSPACE_AREA / "workspaces"
LOGS = ROOT / "logs"
ARTIFACTS = ROOT / "artifacts"
NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,47}$")
DEFAULT_TIMEOUT = 300
MAX_TIMEOUT = 1800
DEFAULT_MEMORY_MIB = 3072
MAX_MEMORY_MIB = 3072
DEFAULT_DISK_MIB = 1024
MAX_DISK_MIB = 2048
DEFAULT_FILE_MIB = 256
MAX_FILE_MIB = 512
MAX_LOG_TAIL = 24000
MAX_CAPTURE_BYTES = 256 * 1024
MAX_EXPORT_BYTES = 512 * 1024 * 1024
POLICY_FILE = ROOT / "policy" / "default.json"
COMPILED_MINIMUMS = {"wall_timeout_seconds": 1, "memory_mib": 256,
                     "disk_mib": 64, "file_mib": 1}
COMPILED_MAXIMUMS = {"wall_timeout_seconds": MAX_TIMEOUT, "memory_mib": MAX_MEMORY_MIB,
                     "disk_mib": MAX_DISK_MIB, "file_mib": MAX_FILE_MIB}


def _reject_duplicate_json_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def validate_runtime_policy(document: dict) -> dict:
    """Validate the executable policy subset; metadata is not authority."""
    if not isinstance(document, dict):
        raise ValueError("policy document must be an object")
    policy = document.get("runtime_policy")
    if not isinstance(policy, dict):
        raise ValueError("runtime_policy object is required")
    expected = {"schema_version", "defaults", "maxima", "network_mode"}
    if set(policy) != expected:
        unknown = sorted(set(policy) - expected)
        missing = sorted(expected - set(policy))
        raise ValueError(f"runtime_policy keys mismatch; unknown={unknown}, missing={missing}")
    if type(policy["schema_version"]) is not int or policy["schema_version"] != 1:
        raise ValueError("runtime_policy.schema_version must be integer 1")
    if policy["network_mode"] != "isolated":
        raise ValueError("this runner only supports network_mode='isolated'")
    validated = {"schema_version": 1, "network_mode": "isolated", "defaults": {}, "maxima": {}}
    for group in ("defaults", "maxima"):
        values = policy[group]
        if not isinstance(values, dict) or set(values) != set(COMPILED_MINIMUMS):
            raise ValueError(f"runtime_policy.{group} must contain exactly {sorted(COMPILED_MINIMUMS)}")
        for key, value in values.items():
            if type(value) is not int:
                raise ValueError(f"runtime_policy.{group}.{key} must be an integer, not {type(value).__name__}")
            if group == "maxima":
                if value < COMPILED_MINIMUMS[key] or value > COMPILED_MAXIMUMS[key]:
                    raise ValueError(f"runtime_policy.maxima.{key} must be {COMPILED_MINIMUMS[key]}-{COMPILED_MAXIMUMS[key]}")
            else:
                if value < COMPILED_MINIMUMS[key] or value > COMPILED_MAXIMUMS[key]:
                    raise ValueError(f"runtime_policy.defaults.{key} must be {COMPILED_MINIMUMS[key]}-{COMPILED_MAXIMUMS[key]}")
            validated[group][key] = value
    for key, default in validated["defaults"].items():
        if default > validated["maxima"][key]:
            raise ValueError(f"runtime_policy default {key} exceeds configured maximum")
    return validated


def load_runtime_policy(path: Path = POLICY_FILE) -> dict:
    """Load a bounded, non-symlink policy file owned by root or the operator."""
    flags = os.O_RDONLY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags)
    except OSError as exc:
        raise SystemExit(f"Unable to safely open runtime policy {path}: {exc}") from exc
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            raise SystemExit("Runtime policy must be a regular file")
        if st.st_uid not in {0, os.getuid()}:
            raise SystemExit("Runtime policy must be owned by root or the invoking user")
        if st.st_mode & 0o022:
            raise SystemExit("Runtime policy must not be group- or world-writable")
        if st.st_size > 1024 * 1024:
            raise SystemExit("Runtime policy exceeds 1 MiB")
        with os.fdopen(fd, "r", encoding="utf-8", closefd=False) as stream:
            document = json.load(stream, object_pairs_hook=_reject_duplicate_json_keys)
        try:
            return validate_runtime_policy(document)
        except ValueError as exc:
            raise SystemExit(f"Invalid runtime policy: {exc}") from exc
    except (json.JSONDecodeError, ValueError) as exc:
        raise SystemExit(f"Invalid runtime policy JSON: {exc}") from exc
    finally:
        os.close(fd)


def require_name(name: str) -> str:
    if not NAME_RE.fullmatch(name):
        raise SystemExit("Invalid workspace name: use 1-48 letters, numbers, '_' or '-'.")
    return name


def get_sandbox_user():
    """Select a host identity that maps to namespace root without host-root access."""
    try:
        if os.geteuid() == 0:
            return pwd.getpwnam("nobody")
        return pwd.getpwuid(os.getuid())
    except KeyError as exc:
        raise SystemExit(f"Required unprivileged account is unavailable: {exc}")


DIR_OPEN_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)


def ensure_child_directory(parent_fd: int, name: str, user, mode: int = 0o700, label: str = "directory") -> int:
    """Create/open a child directory relative to a pinned parent FD.

    O_NOFOLLOW + dir_fd + fchown/fchmod avoid path traversal and symlink-swap
    races between validation and ownership/mode changes. Caller owns returned FD.
    """
    if not name or name in (".", "..") or "/" in name:
        raise SystemExit(f"Invalid {label} name: {name!r}")
    try:
        os.mkdir(name, mode=mode, dir_fd=parent_fd)
    except FileExistsError:
        pass
    try:
        fd = os.open(name, DIR_OPEN_FLAGS, dir_fd=parent_fd)
    except OSError as exc:
        raise SystemExit(f"Refusing non-directory or symlink path component {label}: {name}: {exc}") from exc
    try:
        st = os.fstat(fd)
        if not stat.S_ISDIR(st.st_mode):
            raise SystemExit(f"Refusing non-directory path component {label}: {name}")
        os.fchown(fd, user.pw_uid, user.pw_gid)
        os.fchmod(fd, mode)
        return fd
    except Exception:
        os.close(fd)
        raise


def open_workspaces_root() -> int:
    """Open a controller-owned tmpfs workspace root without following links.

    The outer host may use overlayfs, which is not bind-mountable from the
    unprivileged user namespace on some kernels/runtime combinations. /dev/shm
    is tmpfs and supports the private bind mount used by the inner chroot.
    Workspace state is therefore session-local; durable outputs use artifacts.
    """
    shm_fd = os.open("/dev/shm", DIR_OPEN_FLAGS)
    area_fd = None
    try:
        try:
            os.mkdir(WORKSPACE_AREA_NAME, mode=0o711, dir_fd=shm_fd)
        except FileExistsError:
            pass
        area_fd = os.open(WORKSPACE_AREA_NAME, DIR_OPEN_FLAGS, dir_fd=shm_fd)
        area_st = os.fstat(area_fd)
        if not stat.S_ISDIR(area_st.st_mode) or area_st.st_uid != os.getuid():
            raise SystemExit("Refusing an unsafe or foreign-owned tmpfs workspace area")
        if area_st.st_mode & 0o022:
            raise SystemExit("Workspace area must not be group/world writable")
        os.fchmod(area_fd, 0o711)
        try:
            os.mkdir("workspaces", mode=0o711, dir_fd=area_fd)
        except FileExistsError:
            pass
        workspaces_fd = os.open("workspaces", DIR_OPEN_FLAGS, dir_fd=area_fd)
        ws_st = os.fstat(workspaces_fd)
        if not stat.S_ISDIR(ws_st.st_mode) or ws_st.st_uid != os.getuid():
            os.close(workspaces_fd)
            raise SystemExit("Refusing an unsafe or foreign-owned workspaces directory")
        if ws_st.st_mode & 0o022:
            os.close(workspaces_fd)
            raise SystemExit("Workspaces directory must not be group/world writable")
        os.fchmod(workspaces_fd, 0o711)
        return workspaces_fd
    finally:
        if area_fd is not None:
            os.close(area_fd)
        os.close(shm_fd)


def ensure_workspace(name: str, create: bool = True) -> Path:
    name = require_name(name)
    user = get_sandbox_user()
    workspaces_fd = open_workspaces_root()
    workspace_fd = None
    try:
        if create:
            try:
                os.mkdir(name, mode=0o700, dir_fd=workspaces_fd)
            except FileExistsError:
                pass
            except OSError as exc:
                raise SystemExit(f"Unable to create workspace {name}: {exc}") from exc
        try:
            workspace_fd = os.open(name, DIR_OPEN_FLAGS, dir_fd=workspaces_fd)
        except FileNotFoundError:
            raise SystemExit(f"Workspace does not exist: {name}")
        except OSError as exc:
            raise SystemExit(f"Refusing symlink or non-directory workspace path: {name}: {exc}") from exc
        workspace_stat = os.fstat(workspace_fd)
        if not stat.S_ISDIR(workspace_stat.st_mode):
            raise SystemExit(f"Workspace is not a directory: {name}")
        os.fchown(workspace_fd, user.pw_uid, user.pw_gid)
        os.fchmod(workspace_fd, 0o700)
        child_fds = {}
        try:
            for child in (".home", ".tmp", ".cache", ".deps", "inputs", "outputs"):
                child_fds[child] = ensure_child_directory(workspace_fd, child, user, 0o700, "workspace")
            cache_fd = child_fds[".cache"]
            for child in ("matplotlib", "jupyter", "npm", "huggingface", "torch"):
                fd = ensure_child_directory(cache_fd, child, user, 0o700, "cache")
                os.close(fd)
            benchmark_src = ROOT / "benchmarks" / "numerical_smoke.py"
            if benchmark_src.is_file():
                try:
                    dst_fd = os.open("numerical_smoke.py", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0), 0o600, dir_fd=child_fds["inputs"])
                except FileExistsError:
                    dst_fd = None
                if dst_fd is not None:
                    try:
                        with benchmark_src.open("rb") as src, os.fdopen(dst_fd, "wb", closefd=False) as dst:
                            shutil.copyfileobj(src, dst)
                        os.fchown(dst_fd, user.pw_uid, user.pw_gid)
                        os.fchmod(dst_fd, 0o600)
                    finally:
                        os.close(dst_fd)
        finally:
            for fd in child_fds.values():
                os.close(fd)
        return WORKSPACES / name
    finally:
        if workspace_fd is not None:
            os.close(workspace_fd)
        os.close(workspaces_fd)


def read_int(path: str):
    try:
        raw = Path(path).read_text().strip()
        if raw == "max":
            return None
        return int(raw)
    except Exception:
        return None


def mount_readonly(mountpoint: str) -> bool | None:
    """Return the read-only state from mountinfo for an exact mountpoint."""
    try:
        for line in Path("/proc/self/mountinfo").read_text().splitlines():
            fields = line.split()
            if len(fields) > 6 and fields[4].replace("\\040", " ") == mountpoint:
                return "ro" in fields[5].split(",")
    except Exception:
        return None
    return None


def _landlock_probe() -> str:
    # Linux __NR_landlock_create_ruleset is 444 on supported x86_64/aarch64.
    if platform.machine().lower() not in ("x86_64", "amd64", "aarch64", "arm64"):
        return "not probed: syscall number not mapped for this architecture"
    libc = ctypes.CDLL(None, use_errno=True)
    try:
        rc = libc.syscall(ctypes.c_long(444), ctypes.c_void_p(), ctypes.c_size_t(0), ctypes.c_uint(1))
        if rc >= 0:
            return f"available: ABI version {rc}"
        err = ctypes.get_errno()
        if err == 38:
            return "unavailable: ENOSYS"
        if err == 95:
            return "unavailable: EOPNOTSUPP"
        if err == 22:
            return "present: probe rejected arguments with EINVAL"
        return f"probe returned errno {err}: {os.strerror(err)}"
    except Exception as exc:
        return f"probe failed: {type(exc).__name__}: {exc}"


def _network_probe() -> dict:
    result = {"dns": False, "tcp_1_1_1_1_443": False, "details": []}
    # Run resolver work in a bounded child: libc getaddrinfo has no portable
    # per-call timeout and must not hang the doctor command indefinitely.
    code = "import socket; socket.getaddrinfo('example.com', 443, type=socket.SOCK_STREAM)"
    try:
        probe = subprocess.run(
            [sys.executable, "-c", code], capture_output=True, text=True,
            timeout=2, env={"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LANG": "C"})
        result["dns"] = probe.returncode == 0
        if probe.returncode != 0:
            detail = (probe.stderr or probe.stdout).strip()[-300:]
            result["details"].append(f"DNS: resolver exited {probe.returncode}: {detail}")
    except subprocess.TimeoutExpired:
        result["details"].append("DNS: resolver probe exceeded 2-second timeout")
    except Exception as exc:
        result["details"].append(f"DNS: {type(exc).__name__}: {exc}")
    try:
        with socket.create_connection(("1.1.1.1", 443), timeout=1.0):
            result["tcp_1_1_1_1_443"] = True
    except Exception as exc:
        result["details"].append(f"TCP: {type(exc).__name__}: {exc}")
    return result


def host_report() -> dict:
    cpu_max = None
    try:
        raw = Path("/sys/fs/cgroup/cpu.max").read_text().strip().split()
        if len(raw) == 2 and raw[0] != "max":
            cpu_max = int(raw[0]) / int(raw[1])
    except Exception:
        pass
    mem_limit = read_int("/sys/fs/cgroup/memory.max")
    mem_total = None
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal:"):
                mem_total = int(line.split()[1]) * 1024
                break
    except Exception:
        pass
    workspace_mount = "/dev/shm"
    disk = shutil.disk_usage(workspace_mount if Path(workspace_mount).exists() else (ROOT if ROOT.exists() else "/mnt/data"))
    try:
        cgroup_controllers = Path("/sys/fs/cgroup/cgroup.controllers").read_text().split()
    except Exception:
        cgroup_controllers = []
    cgroup_ro = mount_readonly("/sys/fs/cgroup")
    modules = {}
    for mod in ("numpy", "scipy", "pandas", "polars", "matplotlib", "PIL",
                "sympy", "sklearn", "torch", "tensorflow", "jax", "numba",
                "pytest", "ipykernel", "duckdb", "pyarrow", "cv2", "networkx",
                "statsmodels", "xgboost", "lightgbm", "transformers", "datasets",
                "fastapi", "pydantic", "sqlalchemy", "h5py", "astropy", "Bio"):
        try:
            import importlib.util
            modules[mod] = importlib.util.find_spec(mod) is not None
        except Exception:
            modules[mod] = False
    torch_cuda = False
    jax_devices = []
    try:
        import torch
        torch_cuda = bool(torch.cuda.is_available())
    except Exception:
        pass
    try:
        import jax
        jax_devices = [str(d) for d in jax.devices()]
    except Exception:
        pass
    tools = ("git", "gcc", "g++", "clang", "make", "cmake", "ninja", "rustc",
             "cargo", "go", "java", "node", "npm", "ffmpeg", "pandoc",
             "docker", "podman", "firecracker", "qemu-system-x86_64", "kubectl",
             "terraform", "unshare")
    executable_inventory = {name: shutil.which(name) for name in tools}
    try:
        namespaces = sorted(os.listdir("/proc/self/ns"))
    except Exception:
        namespaces = []
    try:
        os_release = platform.freedesktop_os_release()
        distro = f"{os_release.get('PRETTY_NAME', platform.system())}"
    except Exception:
        distro = platform.platform()
    try:
        virt = subprocess.run(["systemd-detect-virt"], capture_output=True, text=True, timeout=2).stdout.strip() or "unknown"
    except Exception:
        virt = "unknown"
    network_probe = _network_probe()
    libseccomp = ctypes.util.find_library("seccomp")
    libcap = ctypes.util.find_library("cap")
    device_nodes = {p: Path(p).exists() for p in ("/dev/kvm", "/dev/dri", "/dev/nvidia0", "/dev/nvidiactl") }
    try:
        cpu_model = next((line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines() if line.lower().startswith("model name")), None)
    except Exception:
        cpu_model = None
    return {
        "observed_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "os": distro,
        "kernel": os.uname().release,
        "architecture": platform.machine(),
        "cpu_model": cpu_model,
        "python": sys.version.split()[0],
        "python_executable": sys.executable,
        "node": subprocess.run(["node", "--version"], capture_output=True, text=True).stdout.strip() if shutil.which("node") else None,
        "git": subprocess.run(["git", "--version"], capture_output=True, text=True).stdout.strip() if shutil.which("git") else None,
        "visible_cpu_count": os.cpu_count(),
        "cgroup_cpu_quota_cores": cpu_max,
        "cgroup_memory_limit_bytes": mem_limit,
        "cgroup_v2": {
            "controllers_visible": cgroup_controllers,
            "mount_read_only": cgroup_ro,
            "per_task_cgroup_delegation_writable": False if cgroup_ro is True else None,
            "note": "A writable mount is not proof of delegation. Positive delegation is not claimed without an active, reversible cgroup-controller probe."
        },
        "outer_container_type": virt,
        "host_meminfo_total_bytes": mem_total,
        "workspace_filesystem_total_bytes": disk.total,
        "workspace_filesystem_free_bytes": disk.free,
        "workspace_storage": {
            "path": str(WORKSPACES),
            "mount": workspace_mount,
            "filesystem_role": "session-local tmpfs workspaces for user-namespace bind-mount compatibility",
            "durability": "ephemeral; export important artifacts before host session ends",
            "quota_enforcement": "sampled per-workspace byte accounting; no hard per-workspace block or inode quota",
        },
        "gpu": {"torch_cuda_available": torch_cuda, "jax_devices": jax_devices, "device_nodes": device_nodes},
        "python_modules_available": modules,
        "executable_inventory": executable_inventory,
        "visible_namespace_handles": namespaces,
        "unshare_available": bool(shutil.which("unshare")),
        "landlock_probe": _landlock_probe(),
        "seccomp_library": libseccomp or "not found",
        "libcap_library": libcap or "not found",
        "execution_mode": "host root maps to nobody; rootless invocation maps the invoking UID into namespace root",
        "outbound_network_from_host": network_probe,
    }


def total_tree_bytes(root: Path) -> int:
    """Count regular-file bytes without following task-controlled symlinks.

    Directory traversal is descriptor-relative: each child directory is opened
    with O_NOFOLLOW before it is added to the walk stack. This avoids the
    stat-then-scandir path race in a workspace writable by the task.
    """
    total = 0
    stack: list[int] = []
    try:
        stack.append(os.open(root, DIR_OPEN_FLAGS))
        while stack:
            current_fd = stack.pop()
            try:
                with os.scandir(current_fd) as entries:
                    snapshot = [(entry.name, entry.stat(follow_symlinks=False)) for entry in entries]
                for name, st in snapshot:
                    if stat.S_ISDIR(st.st_mode):
                        try:
                            child_fd = os.open(name, DIR_OPEN_FLAGS, dir_fd=current_fd)
                        except (FileNotFoundError, NotADirectoryError, PermissionError, OSError):
                            continue
                        stack.append(child_fd)
                    elif stat.S_ISREG(st.st_mode):
                        total += st.st_size
                    elif stat.S_ISLNK(st.st_mode):
                        # Count link metadata only; never follow the target.
                        total += len(os.fsencode(name))
            except (FileNotFoundError, PermissionError, NotADirectoryError):
                continue
            finally:
                os.close(current_fd)
    except (FileNotFoundError, PermissionError, NotADirectoryError):
        return 0
    finally:
        for fd in stack:
            try:
                os.close(fd)
            except OSError:
                pass
    return total


def redact_output(data: bytes) -> str:
    """Best-effort redaction for common credential formats before display.

    The runner does not persist raw stdout/stderr. Pattern redaction is defense
    in depth only; it cannot identify every application-specific secret.
    """
    text = data.decode("utf-8", errors="replace")
    patterns = [
        (r"(?i)(authorization\s*:\s*bearer\s+)[A-Za-z0-9._~+/=-]+", r"\1[REDACTED]"),
        (r"\bsk-[A-Za-z0-9_-]{16,}\b", "[REDACTED_OPENAI_KEY]"),
        (r"\bgh[pousr]_[A-Za-z0-9]{20,}\b", "[REDACTED_GITHUB_TOKEN]"),
        (r"\bAKIA[0-9A-Z]{16}\b", "[REDACTED_AWS_ACCESS_KEY]"),
        (r"(?i)((?:api[_-]?key|access[_-]?token|secret|password)\s*[:=]\s*[\"']?)[^\s,\"']+", r"\1[REDACTED]"),
    ]
    for pattern, replacement in patterns:
        text = re.sub(pattern, replacement, text)
    return text[-MAX_LOG_TAIL:]


def capture_process_output(proc: subprocess.Popen, started: float, args,
                           workspace: Path) -> tuple[bytes, bytes, bool, bool, str]:
    """Drain stdout/stderr without persistent raw log files or unbounded RAM."""
    selector = selectors.DefaultSelector()
    streams = {"stdout": bytearray(), "stderr": bytearray()}
    truncated = {"stdout": False, "stderr": False}
    for name, pipe in (("stdout", proc.stdout), ("stderr", proc.stderr)):
        if pipe is not None:
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe, selectors.EVENT_READ, name)
    status = "completed"
    next_disk_check = 0.0
    try:
        while proc.poll() is None or selector.get_map():
            now = time.monotonic()
            elapsed = now - started
            if status == "completed" and elapsed > args.timeout:
                status = "wall-time limit exceeded"
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            if status == "completed" and now >= next_disk_check:
                if total_tree_bytes(workspace) > args.disk_mib * 1024 * 1024:
                    status = "workspace disk budget exceeded"
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                next_disk_check = now + 0.25
            for key, _ in selector.select(timeout=0.05):
                pipe = key.fileobj
                name = key.data
                try:
                    chunk = os.read(pipe.fileno(), 65536)
                except BlockingIOError:
                    continue
                if not chunk:
                    selector.unregister(pipe)
                    pipe.close()
                    continue
                remaining = MAX_CAPTURE_BYTES - len(streams[name])
                if remaining > 0:
                    streams[name].extend(chunk[:remaining])
                if len(chunk) > max(remaining, 0):
                    truncated[name] = True
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            proc.wait()
    finally:
        selector.close()
        for pipe in (proc.stdout, proc.stderr):
            if pipe is not None and not pipe.closed:
                pipe.close()
    return bytes(streams["stdout"]), bytes(streams["stderr"]), truncated["stdout"], truncated["stderr"], status


def child_setup(uid: int, gid: int, memory_mib: int, timeout_s: int, file_mib: int,
                expected_parent_pid: int):
    # Runs after fork, before exec. Set the parent-death signal only after the
    # final UID/GID transition: Linux clears PR_SET_PDEATHSIG when effective or
    # filesystem credentials change. unshare's --kill-child then terminates
    # its namespace init, which causes the kernel to terminate remaining tasks.
    libc = ctypes.CDLL(None, use_errno=True)
    PR_SET_PDEATHSIG = 1
    os.umask(0o077)
    limits = [
        (resource.RLIMIT_CORE, (0, 0)),
        (resource.RLIMIT_AS, (memory_mib * 1024 * 1024, memory_mib * 1024 * 1024)),
        (resource.RLIMIT_CPU, (timeout_s, timeout_s + 2)),
        (resource.RLIMIT_FSIZE, (file_mib * 1024 * 1024, file_mib * 1024 * 1024)),
        (resource.RLIMIT_NOFILE, (256, 256)),
        (resource.RLIMIT_NPROC, (64, 64)),
        (resource.RLIMIT_STACK, (64 * 1024 * 1024, 64 * 1024 * 1024)),
    ]
    if hasattr(resource, "RLIMIT_MEMLOCK"):
        limits.append((resource.RLIMIT_MEMLOCK, (0, 0)))
    for kind, value in limits:
        resource.setrlimit(kind, value)
    if os.geteuid() == 0:
        os.setgroups([])
        os.setgid(gid)
        os.setuid(uid)
    elif os.getuid() != uid or os.getgid() != gid:
        raise PermissionError("Controller cannot assume the requested unprivileged identity")

    # Close both races. If the parent died before registration, getppid differs.
    # If it dies after registration, the kernel sends SIGKILL. The second check
    # closes the race between the first check and prctl().
    if os.getppid() != expected_parent_pid:
        os.kill(os.getpid(), signal.SIGKILL)
    if libc.prctl(PR_SET_PDEATHSIG, signal.SIGKILL, 0, 0, 0) != 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err), "prctl(PR_SET_PDEATHSIG)")
    if os.getppid() != expected_parent_pid:
        os.kill(os.getpid(), signal.SIGKILL)


def open_control_dir(name: str) -> int:
    """Open/create a controller-owned private directory without following links."""
    if not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", name):
        raise SystemExit("Invalid controller directory name")
    root_fd = os.open(ROOT, DIR_OPEN_FLAGS)
    try:
        try:
            os.mkdir(name, 0o700, dir_fd=root_fd)
        except FileExistsError:
            pass
        fd = os.open(name, DIR_OPEN_FLAGS, dir_fd=root_fd)
        st = os.fstat(fd)
        if not stat.S_ISDIR(st.st_mode) or st.st_uid != os.getuid():
            os.close(fd)
            raise SystemExit(f"Refusing unsafe controller directory: {name}")
        os.fchmod(fd, 0o700)
        return fd
    finally:
        os.close(root_fd)


def write_receipt_at(directory_fd: int, name: str, document: dict) -> None:
    """Create a private, non-overwriting JSON receipt relative to a pinned FD."""
    payload = (json.dumps(document, indent=2, sort_keys=True) + "\n").encode("utf-8")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(name, flags, 0o600, dir_fd=directory_fd)
    try:
        view = memoryview(payload)
        while view:
            n = os.write(fd, view)
            if n <= 0:
                raise OSError("short write creating execution receipt")
            view = view[n:]
        os.fsync(fd)
    finally:
        os.close(fd)


def write_file_atomic_at(directory_fd: int, name: str, payload: bytes, mode: int = 0o600) -> None:
    """Atomically replace a report relative to a pinned, trusted directory FD."""
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,120}", name):
        raise SystemExit("Invalid report filename")
    tmp_name = f".{name}.{uuid.uuid4().hex}.tmp"
    try:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(tmp_name, flags, mode, dir_fd=directory_fd)
        try:
            view = memoryview(payload)
            while view:
                n = os.write(fd, view)
                if n <= 0:
                    raise OSError("short write creating report")
                view = view[n:]
            os.fchmod(fd, mode)
            os.fsync(fd)
        finally:
            os.close(fd)
        # rename replaces a symlink itself, never follows its target.
        os.replace(tmp_name, name, src_dir_fd=directory_fd, dst_dir_fd=directory_fd)
        os.fsync(directory_fd)
    except Exception:
        try:
            os.unlink(tmp_name, dir_fd=directory_fd)
        except OSError:
            pass
        raise


def open_user_state_directory() -> tuple[int, Path]:
    """Create/open ~/.local/state/ai-sandbox with descriptor-relative no-follow checks."""
    uid = os.getuid()
    home = Path.home()
    try:
        configured_home_owner = os.stat(home, follow_symlinks=False).st_uid
    except OSError:
        configured_home_owner = -1
    # Some container launchers leave HOME pointing at the original non-root
    # account while executing the controller as root. Never write into that
    # other account's home; use the invoking UID's passwd home instead.
    if configured_home_owner != uid and uid == 0:
        home = Path(pwd.getpwuid(uid).pw_dir)
    if not home.is_absolute() or any(part in (".", "..") for part in home.parts[1:]):
        raise SystemExit("Refusing a non-canonical home directory for runtime state")
    current = os.open("/", DIR_OPEN_FLAGS)
    try:
        for component in home.parts[1:]:
            next_fd = os.open(component, DIR_OPEN_FLAGS, dir_fd=current)
            st = os.fstat(next_fd)
            writable_unsafe = bool(st.st_mode & 0o022) and not bool(st.st_mode & stat.S_ISVTX)
            if not stat.S_ISDIR(st.st_mode) or writable_unsafe:
                os.close(next_fd)
                raise SystemExit("Refusing an unsafe home-directory path component")
            os.close(current)
            current = next_fd
        home_stat = os.fstat(current)
        if home_stat.st_uid != uid:
            raise SystemExit("Home directory is not owned by the invoking user")
        for component in (".local", "state", "ai-sandbox"):
            try:
                os.mkdir(component, 0o700, dir_fd=current)
                os.fsync(current)
            except FileExistsError:
                pass
            next_fd = os.open(component, DIR_OPEN_FLAGS, dir_fd=current)
            st = os.fstat(next_fd)
            if not stat.S_ISDIR(st.st_mode) or st.st_uid != uid or st.st_mode & 0o022:
                os.close(next_fd)
                raise SystemExit(f"Refusing unsafe runtime-state directory: {component}")
            if component != ".local":
                os.fchmod(next_fd, 0o700)
            os.close(current)
            current = next_fd
        return current, home / ".local" / "state" / "ai-sandbox"
    except Exception:
        os.close(current)
        raise


def cmd_create(args):
    p = ensure_workspace(args.name)
    print(f"Created/verified workspace: {p}")
    print(f"Sandbox host UID/GID: {get_sandbox_user().pw_uid}/{get_sandbox_user().pw_gid}")


def cmd_list(_args):
    workspaces_fd = open_workspaces_root()
    try:
        with os.scandir(workspaces_fd) as scan:
            entries = sorted(entry.name for entry in scan
                             if entry.is_dir(follow_symlinks=False))
    finally:
        os.close(workspaces_fd)
    if not entries:
        print("No workspaces yet. Use: sandboxctl.py create default")
    else:
        for name in entries:
            print(f"{name}\t{total_tree_bytes(WORKSPACES / name)} bytes")


def cmd_doctor(_args):
    report = host_report()
    print(json.dumps(report, indent=2))
    state_fd, state_path = open_user_state_directory()
    try:
        json_payload = (json.dumps(report, indent=2, sort_keys=True) + "\n").encode()
        text_payload = ("AI Sandbox host capability report\n\n" + json.dumps(report, indent=2, sort_keys=True) + "\n").encode()
        write_file_atomic_at(state_fd, "capability_report.json", json_payload)
        write_file_atomic_at(state_fd, "capability_report.txt", text_payload)
    finally:
        os.close(state_fd)
    print(f"\nSaved runtime diagnostics outside the immutable install tree: {state_path / 'capability_report.json'}")


def sandbox_path() -> str:
    """Construct a small PATH from the active Python and trusted system prefixes."""
    candidates = [str(Path(sys.executable).resolve().parent),
                  "/usr/local/sbin", "/usr/local/bin", "/usr/sbin", "/usr/bin", "/sbin", "/bin"]
    # Include discovered tool directories only when they resolve beneath /usr or /opt.
    # This preserves installed Node/Go toolchains without inheriting arbitrary PATH entries.
    for tool in ("node", "npm", "git", "gcc", "g++", "clang", "go", "java", "ffmpeg", "pandoc"):
        found = shutil.which(tool)
        if found:
            parent = str(Path(found).resolve().parent)
            if parent.startswith(("/usr/", "/opt/")):
                candidates.append(parent)
    unique = []
    for item in candidates:
        if item not in unique and Path(item).is_dir():
            unique.append(item)
    return os.pathsep.join(unique)


def cmd_run(args):
    if not args.command:
        raise SystemExit("Provide a command after '--', for example: run default -- python -c 'print(1+1)'")
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        raise SystemExit("Empty command.")
    if not shutil.which("unshare"):
        raise SystemExit("unshare is unavailable; refusing to run without network namespace isolation.")
    maxima = args.runtime_policy["maxima"]
    minima = COMPILED_MINIMUMS
    for argument, key in ((args.timeout, "wall_timeout_seconds"),
                          (args.memory_mib, "memory_mib"),
                          (args.disk_mib, "disk_mib"),
                          (args.file_mib, "file_mib")):
        if argument < minima[key] or argument > maxima[key]:
            raise SystemExit(f"{key} must be {minima[key]}-{maxima[key]} under the active runtime policy")

    ws = ensure_workspace(args.name)
    user = get_sandbox_user()
    logs_fd = open_control_dir("logs")
    run_id = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
    env = {
        "PATH": sandbox_path(),
        "HOME": "/workspace/.home",
        "TMPDIR": "/tmp",
        "TMP": "/tmp",
        "TEMP": "/tmp",
        "XDG_CACHE_HOME": "/workspace/.cache",
        "VIRTUAL_ENV": sys.prefix,
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONUNBUFFERED": "1",
        "PIP_NO_INDEX": "1",
        "PIP_DISABLE_PIP_VERSION_CHECK": "1",
        "PYTHONNOUSERSITE": "1",
        "PYTHONPATH": "/workspace/.deps",
        "NODE_PATH": "/workspace/.deps/node_modules",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_TERMINAL_PROMPT": "0",
        "NPM_CONFIG_CACHE": "/workspace/.cache/npm",
        "NPM_CONFIG_OFFLINE": "true",
        "CUDA_VISIBLE_DEVICES": "",
        "MPLCONFIGDIR": "/workspace/.cache/matplotlib",
        "JUPYTER_RUNTIME_DIR": "/workspace/.cache/jupyter",
        "OMP_NUM_THREADS": "2",
        "OPENBLAS_NUM_THREADS": "2",
        "MKL_NUM_THREADS": "2",
        "NUMEXPR_NUM_THREADS": "2",
        "VECLIB_MAXIMUM_THREADS": "2",
        "BLIS_NUM_THREADS": "2",
        "TOKENIZERS_PARALLELISM": "false",
        "HF_HOME": "/workspace/.cache/huggingface",
        "TORCH_HOME": "/workspace/.cache/torch",
        "NO_PROXY": "*",
        "no_proxy": "*",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
    }

    rootfs = Path(tempfile.mkdtemp(prefix="ai-sandbox-root-", dir="/tmp"))
    os.chown(rootfs, user.pw_uid, user.pw_gid, follow_symlinks=False)
    os.chmod(rootfs, 0o700, follow_symlinks=False)
    # Pin the bootstrap and workspace before dropping the launcher identity.
    # This supports root-managed installs beneath private HOME paths such as
    # /root, without making those parent directories searchable by nobody.
    bootstrap_fd = os.open(ROOT / "sandbox_bootstrap.py",
                           os.O_RDONLY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0))
    bootstrap_stat = os.fstat(bootstrap_fd)
    if not stat.S_ISREG(bootstrap_stat.st_mode) or bootstrap_stat.st_size > 2 * 1024 * 1024:
        os.close(bootstrap_fd)
        shutil.rmtree(rootfs, ignore_errors=True)
        os.close(logs_fd)
        raise SystemExit("Refusing an invalid sandbox bootstrap file")
    loader = (
        "import os; _f=os.fdopen(" + str(bootstrap_fd) + ", 'rb'); _src=_f.read(); _f.close(); "
        "exec(compile(_src, 'sandbox_bootstrap.py', 'exec'), "
        "{'__name__':'__main__','__file__':'sandbox_bootstrap.py'})"
    )
    argv = [
        shutil.which("unshare"),
        "--kill-child=KILL",
        "--user", "--map-root-user", "--mount", "--net", "--pid", "--ipc", "--uts", "--cgroup", "--fork", "--",
        sys.executable, "-c", loader, str(rootfs), str(ws), "--", *command,
    ]
    started = time.monotonic()
    controller_pid = os.getpid()
    status = "completed"
    proc = None
    stdout_raw = stderr_raw = b""
    stdout_truncated = stderr_truncated = False
    try:
        proc = subprocess.Popen(
            argv,
            cwd=str(ws),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,
            preexec_fn=lambda: child_setup(user.pw_uid, user.pw_gid, args.memory_mib, args.timeout, args.file_mib, controller_pid),
            close_fds=True,
            pass_fds=(bootstrap_fd,),
        )
        stdout_raw, stderr_raw, stdout_truncated, stderr_truncated, status = capture_process_output(
            proc, started, args, ws
        )
        return_code = proc.returncode if proc.returncode is not None else 125
    except BaseException:
        # If the controller is interrupted or capture fails, terminate the
        # entire launched process group so descendants cannot outlive the task.
        if proc is not None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
        os.close(logs_fd)
        raise
    finally:
        # Parent copy is no longer needed after Popen has duplicated it.
        try:
            os.close(bootstrap_fd)
        except OSError:
            pass
        # Mount namespace disappears with launcher; remove its empty host path.
        shutil.rmtree(rootfs, ignore_errors=True)

    elapsed = time.monotonic() - started
    used = total_tree_bytes(ws)
    command_bytes = b"\0".join(os.fsencode(part) for part in command)
    meta = {
        "run_id": run_id,
        "workspace": args.name,
        "command": {
            "executable_basename": Path(command[0]).name,
            "argument_count": max(0, len(command) - 1),
            "argv_sha256": hashlib.sha256(command_bytes).hexdigest(),
            "raw_arguments_persisted": False,
        },
        "status": status,
        "return_code": return_code,
        "elapsed_seconds": round(elapsed, 3),
        "workspace_bytes_after_run": used,
        "limits": {
            "wall_timeout_seconds": args.timeout,
            "address_space_mib_per_process": args.memory_mib,
            "workspace_budget_mib": args.disk_mib,
            "max_file_size_mib": args.file_mib,
            "nproc_per_real_uid": 64,
            "open_files": 256,
            "namespaces": ["user", "mount", "network", "pid", "ipc", "uts", "cgroup"],
            "network_namespace": "isolated; no external route",
            "filesystem_view": "chroot; /usr and selected Python/toolchain roots under /opt read-only; generated minimal /etc read-only; task workspace writable; /tmp,/var,/run,/dev/shm tmpfs; /proc and /sys omitted",
            "seccomp": "default-allow deny-list; selected mount/namespace/process-inspection/kernel-management syscalls denied",
            "capabilities": "dropped after rootfs setup; no_new_privs enabled",
            "uid_gid": f"{user.pw_uid}:{user.pw_gid} on host (mapped to namespace root)",
        },
        "output_handling": {
            "raw_output_persisted": False,
            "capture_limit_bytes_per_stream": MAX_CAPTURE_BYTES,
            "stdout_truncated": stdout_truncated,
            "stderr_truncated": stderr_truncated,
            "redaction": "best-effort common-token patterns before display; not a guarantee against unknown secrets",
        },
    }
    receipt_name = f"{run_id}.json"
    try:
        write_receipt_at(logs_fd, receipt_name, meta)
    finally:
        os.close(logs_fd)
    meta["receipt"] = str(LOGS / receipt_name)
    print(json.dumps(meta, indent=2, sort_keys=True))
    stdout = redact_output(stdout_raw)
    stderr = redact_output(stderr_raw)
    if stdout:
        print("\n--- STDOUT (bounded, non-persistent capture) ---\n" + stdout)
    if stderr:
        print("\n--- STDERR (bounded, non-persistent capture) ---\n" + stderr)
    if stdout_truncated or stderr_truncated:
        print("\n[Output capture limit reached; remaining output was drained and discarded.]", file=sys.stderr)
    if status != "completed":
        raise SystemExit(124 if "time" in status else 125)
    raise SystemExit(return_code if return_code >= 0 else 128 + abs(return_code))



def cmd_snapshot(args):
    """Create a bounded, content-addressed workspace archive."""
    archive_name = args.name or (
        f"workspace-{args.workspace}-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}.zip"
    )
    workspaces_fd = open_workspaces_root()
    artifacts_fd = open_control_dir("artifacts")
    try:
        result = workspace_archive.create_snapshot(
            workspaces_fd, args.workspace, artifacts_fd, archive_name
        )
    except workspace_archive.ArchiveError as exc:
        raise SystemExit(f"Workspace snapshot failed: {exc}") from exc
    finally:
        os.close(artifacts_fd)
        os.close(workspaces_fd)
    print(json.dumps(result, indent=2, sort_keys=True))
    print("Snapshot archives may contain credentials or private data; inspect before sharing.")


def cmd_import_snapshot(args):
    """Safely copy and verify an external snapshot into the private artifacts directory."""
    artifacts_fd = open_control_dir("artifacts")
    try:
        result = workspace_archive.import_snapshot(args.source, artifacts_fd, args.name)
    except workspace_archive.ArchiveError as exc:
        raise SystemExit(f"Workspace snapshot import failed: {exc}") from exc
    finally:
        os.close(artifacts_fd)
    print(json.dumps(result, indent=2, sort_keys=True))
    print("Imported content is untrusted; verify provenance and review before restoring or executing it.")


def cmd_verify_snapshot(args):
    """Verify ZIP structure, bounds, CRCs and every file SHA-256 digest."""
    artifacts_fd = open_control_dir("artifacts")
    try:
        result = workspace_archive.verify_snapshot(artifacts_fd, args.archive)
    except workspace_archive.ArchiveError as exc:
        raise SystemExit(f"Snapshot verification failed: {exc}") from exc
    finally:
        os.close(artifacts_fd)
    print(json.dumps(result, indent=2, sort_keys=True))


def cmd_restore(args):
    """Restore a validated archive into a new workspace, never over an existing one."""
    artifacts_fd = open_control_dir("artifacts")
    workspaces_fd = open_workspaces_root()
    user = get_sandbox_user()
    try:
        result = workspace_archive.restore_snapshot(
            artifacts_fd, args.archive, workspaces_fd, args.workspace,
            user.pw_uid, user.pw_gid
        )
    except workspace_archive.ArchiveError as exc:
        raise SystemExit(f"Workspace restore failed: {exc}") from exc
    finally:
        os.close(workspaces_fd)
        os.close(artifacts_fd)
    print(json.dumps(result, indent=2, sort_keys=True))
    print("Restored content is untrusted input; review it before executing any files.")

def cmd_export(args):
    ws = ensure_workspace(args.workspace, create=False)
    rel = Path(args.path)
    if rel.is_absolute() or ".." in rel.parts or not rel.parts or any(part in ("", ".") for part in rel.parts):
        raise SystemExit("Export path must be a non-empty relative file path without traversal components.")
    name = args.name or rel.name
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]{0,119}", name):
        raise SystemExit("Invalid export filename.")

    # Pin every directory component with O_NOFOLLOW and open the final file
    # without following symlinks. This makes export resistant to path swaps.
    ws_fd = os.open(ws, DIR_OPEN_FLAGS)
    parent_fd = ws_fd
    owned_parent_fd = False
    artifacts_fd = None
    root_fd = None
    src_fd = None
    dst_fd = None
    destination_created = False
    try:
        for component in rel.parts[:-1]:
            next_fd = os.open(component, DIR_OPEN_FLAGS, dir_fd=parent_fd)
            if owned_parent_fd:
                os.close(parent_fd)
            parent_fd = next_fd
            owned_parent_fd = True
        src_fd = os.open(rel.parts[-1], os.O_RDONLY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0), dir_fd=parent_fd)
        src_stat = os.fstat(src_fd)
        if not stat.S_ISREG(src_stat.st_mode):
            raise SystemExit("Export source must be a regular file inside the workspace.")
        if src_stat.st_size > MAX_EXPORT_BYTES:
            raise SystemExit(f"Export source exceeds the {MAX_EXPORT_BYTES}-byte hard export limit.")

        root_fd = os.open(ROOT, DIR_OPEN_FLAGS)
        try:
            os.mkdir(ARTIFACTS.name, mode=0o700, dir_fd=root_fd)
        except FileExistsError:
            pass
        artifacts_fd = os.open(ARTIFACTS.name, DIR_OPEN_FLAGS, dir_fd=root_fd)
        os.fchmod(artifacts_fd, 0o700)
        dst_fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0), 0o600, dir_fd=artifacts_fd)
        destination_created = True
        digest = hashlib.sha256()
        copied = 0
        while True:
            chunk = os.read(src_fd, 1024 * 1024)
            if not chunk:
                break
            copied += len(chunk)
            if copied > MAX_EXPORT_BYTES:
                raise SystemExit(f"Export source grew beyond the {MAX_EXPORT_BYTES}-byte hard export limit.")
            digest.update(chunk)
            view = memoryview(chunk)
            while view:
                written = os.write(dst_fd, view)
                if written <= 0:
                    raise OSError("short write exporting artifact")
                view = view[written:]
        os.fsync(dst_fd)
        os.fchmod(dst_fd, 0o600)
        os.fsync(artifacts_fd)
        size = os.fstat(dst_fd).st_size
        print(f"Exported artifact: {ARTIFACTS / name} ({size} bytes, sha256={digest.hexdigest()})")
    except FileExistsError:
        raise SystemExit("Refusing to overwrite an existing artifact.")
    except OSError as exc:
        if destination_created and artifacts_fd is not None:
            try:
                os.unlink(name, dir_fd=artifacts_fd)
                os.fsync(artifacts_fd)
            except OSError:
                pass
        raise SystemExit(f"Safe artifact export failed: {exc}") from exc
    except BaseException:
        # Includes a source-growth limit violation raised as SystemExit: never
        # leave a partial artifact that looks like a completed export.
        if destination_created and artifacts_fd is not None:
            try:
                os.unlink(name, dir_fd=artifacts_fd)
                os.fsync(artifacts_fd)
            except OSError:
                pass
        raise
    finally:
        for fd in (dst_fd, src_fd, artifacts_fd, root_fd):
            if fd is not None:
                try: os.close(fd)
                except OSError: pass
        if owned_parent_fd:
            os.close(parent_fd)
        os.close(ws_fd)


def build_parser(runtime_policy=None):
    if runtime_policy is None:
        runtime_policy = load_runtime_policy()
    defaults = runtime_policy["defaults"]
    p = argparse.ArgumentParser(prog="sandboxctl.py", description="Controlled task runner for the current hosted execution environment")
    sub = p.add_subparsers(dest="action", required=True)
    s = sub.add_parser("create", help="Create a private task workspace")
    s.add_argument("name")
    s.set_defaults(func=cmd_create)
    s = sub.add_parser("list", help="List workspaces")
    s.set_defaults(func=cmd_list)
    s = sub.add_parser("doctor", help="Report measured environment capabilities")
    s.set_defaults(func=cmd_doctor)
    s = sub.add_parser("run", help="Run a command in isolated network/user/IPC/UTS namespaces with resource limits")
    s.add_argument("name", help="Workspace name")
    s.add_argument("--timeout", type=int, default=defaults["wall_timeout_seconds"])
    s.add_argument("--memory-mib", type=int, default=defaults["memory_mib"])
    s.add_argument("--disk-mib", type=int, default=defaults["disk_mib"])
    s.add_argument("--file-mib", type=int, default=defaults["file_mib"])
    s.add_argument("command", nargs=argparse.REMAINDER)
    s.set_defaults(func=cmd_run)
    s = sub.add_parser("snapshot", help="Create a verified ZIP snapshot of a workspace in the private artifacts directory")
    s.add_argument("workspace", help="Workspace to snapshot")
    s.add_argument("--name", help="Archive filename (simple .zip name); refuses overwrite")
    s.set_defaults(func=cmd_snapshot)
    s = sub.add_parser("import-snapshot", help="Copy and fully verify an external snapshot ZIP into the private artifacts directory")
    s.add_argument("source", help="Canonical local path to an existing snapshot ZIP; symlinks and traversal are refused")
    s.add_argument("--name", help="Private artifact filename; defaults to the source basename; refuses overwrite")
    s.set_defaults(func=cmd_import_snapshot)
    s = sub.add_parser("verify-snapshot", help="Verify snapshot structure, CRCs, sizes and SHA-256 content digests")
    s.add_argument("archive", help="Archive filename already present in the private artifacts directory")
    s.set_defaults(func=cmd_verify_snapshot)
    s = sub.add_parser("restore", help="Restore a verified snapshot as a new workspace; never overwrites")
    s.add_argument("archive", help="Archive filename already present in the private artifacts directory")
    s.add_argument("workspace", help="New workspace name")
    s.set_defaults(func=cmd_restore)
    s = sub.add_parser("export", help="Copy a result from a workspace to the downloadable artifacts directory")
    s.add_argument("workspace")
    s.add_argument("path")
    s.add_argument("--name")
    s.set_defaults(func=cmd_export)
    return p


def main():
    runtime_policy = load_runtime_policy()
    args = build_parser(runtime_policy).parse_args()
    args.runtime_policy = runtime_policy

    # Read-only inventory/diagnostics need no execution lock. Mutating operations
    # serialize only on their workspace, so independent workspaces can run in parallel.
    workspace_name = None
    if args.action in {"create", "run"}:
        workspace_name = require_name(args.name)
    elif args.action in {"export", "snapshot", "restore"}:
        workspace_name = require_name(args.workspace)
    if workspace_name is None:
        args.func(args)
        return

    locks_fd = open_control_dir("locks")
    lock_name = f"workspace-{workspace_name}.lock"
    flags = os.O_CREAT | os.O_RDWR | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(lock_name, flags, 0o600, dir_fd=locks_fd)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_uid != os.getuid():
            raise SystemExit("Refusing unsafe workspace lock file")
        os.fchmod(fd, 0o600)
        fcntl.flock(fd, fcntl.LOCK_EX)
        args.func(args)
    finally:
        os.close(fd)
        os.close(locks_fd)


if __name__ == "__main__":
    main()
