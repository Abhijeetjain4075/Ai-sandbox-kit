# Security policy and threat model

## Scope

The runner executes user-approved code in a per-task Linux namespace/chroot environment inside an existing hosted container. It is designed for safer engineering workflows, not certified hostile-code containment.

## Assets to protect

- Host filesystem paths outside the selected task workspace.
- Other task workspaces and session artifacts.
- Parent-process credentials, environment variables and open file descriptors.
- Controller logs, lock files and export destination paths.
- Host network and kernel configuration.
- Availability of the shared execution container.

## Adversary model

Assume task code, repository content, packages, downloaded archives, datasets and AI-generated scripts may be malicious or intentionally attempt escape, privilege escalation, data disclosure, persistence or resource exhaustion. Assume tasks may create symlinks, malformed paths, subprocesses, threads and unusual file layouts.

The outer hosted container, kernel and runtime are trusted as the primary security boundary. A kernel compromise, host root compromise, or exploitable hypervisor/container-runtime bug is outside this kit's containment guarantee.

## Enforced controls

- New user, mount, network, PID, IPC, UTS and cgroup namespaces per invocation.
- Minimal chroot filesystem; host runtime mounts read-only; one task workspace writable.
- Private bounded tmpfs scratch mounts with `nosuid,nodev,noexec`.
- Network namespace without external connectivity.
- Host-root invocation maps tasks to `nobody:nogroup`; rootless mode maps the invoking UID and therefore relies more heavily on the outer boundary.
- Capabilities cleared; `no_new_privs`; seccomp deny-list.
- Explicit environment allowlist; no inherited secrets/proxies; inherited descriptors closed.
- Per-process address-space, CPU-time, file-size, descriptor, process-count, stack and core-dump limits.
- Wall timeout and sampled workspace disk monitoring.
- Controller lock, descriptor-relative `O_NOFOLLOW` workspace setup, and no-follow exclusive artifact export.
- Snapshot archives reject symlinks, hard links, special files and ambiguous paths; content is bounded and hashed; restore is staged and atomically published without replacing existing workspaces.
- Tests for isolation, file permissions, network denial, environment scrubbing, process namespace, capabilities, seccomp, resource limits, timeouts, symlink poisoning, exports, Python/Node/native toolchains.

## Residual risks and limitations

1. The outer hosted container remains the real primary boundary; the inner chroot and namespace runner is defence in depth.
2. This runtime does not expose KVM, Firecracker, GPU devices or a separate VM per task.
3. Cgroup v2 is mounted read-only, so there are no enforceable per-task aggregate CPU/memory/pids cgroups.
4. `RLIMIT_AS` and `RLIMIT_CPU` are per process. They do not provide an aggregate per-task memory/CPU budget.
5. The workspace disk budget is sampled at 250 ms intervals; it is not a filesystem quota.
6. Seccomp is default-allow with a deny-list, not a complete allowlist.
7. Landlock is unavailable on the measured host.
8. No `/proc` or `/sys` is mounted in the task rootfs; this may limit profiling/debugging tools.
9. Rootless operation uses the invoking host UID and has no separate unprivileged host account boundary.
10. Network is intentionally disabled in task sandboxes; downloads must be staged from a separate trusted mechanism.
11. Kernel vulnerabilities and denial of service against the shared outer container remain possible.
12. Workspace snapshots are unsigned, unencrypted local ZIP files; they can contain secrets and provide integrity detection, not authenticity or confidentiality. Restore must treat the archive contents as untrusted.

## Operational rules

- Never put API keys, tokens, SSH keys, browser profiles or other secrets in task workspaces.
- Never run generated repository scripts directly on the host if sandboxed execution is available.
- Never automatically delete task workspaces or source files.
- Never silently downgrade to unsandboxed execution when namespace setup fails.
- Do not treat a successful sandbox test as a security certification.
- External side effects require separate authorization, idempotency and post-action verification.

## Production gate

Before hosting untrusted multi-tenant or customer code, require an independent security review, VM-level isolation, per-VM cgroups, default-deny network egress, immutable images, signed build provenance, artifact scanning, audit logging, fuzzing and penetration testing.
