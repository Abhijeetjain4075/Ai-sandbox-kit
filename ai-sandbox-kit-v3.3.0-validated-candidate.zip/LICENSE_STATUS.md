# Project license status

No project-level open-source license has been selected for this kit. This release does not assert an SPDX license identifier or grant redistribution rights for the kit as a whole.

Before public distribution, publishing to a package registry, embedding into a commercial product, or accepting outside contributions, the project owner must choose and document a license and confirm rights to all included material. Until then, treat this as a privately used engineering artifact and do not represent it as an openly licensed project.

This status is an engineering release gate, not legal advice.
