#!/usr/bin/env python3
"""Safe, bounded snapshot/verify/restore for AI Sandbox workspaces.

Archives contain regular files and directories only. Symlinks, hard-linked
files, sockets, FIFOs, devices, non-canonical paths and ambiguous Unicode names
are rejected. Restores are staged in the workspace filesystem and published
with renameat2(RENAME_NOREPLACE), so a failed restore never exposes a partial
workspace or replaces an existing one.

This is a portability mechanism, not a remote backup service or a trust
boundary for restored content. Restored files remain untrusted task inputs.
"""
from __future__ import annotations

import contextlib
import datetime as dt
import errno
import hashlib
import json
import os
import re
import stat
import unicodedata
import uuid
import zipfile
from pathlib import PurePosixPath

FORMAT = "ai-sandbox-workspace-snapshot"
SCHEMA_VERSION = 1
MANIFEST_PATH = "META/manifest.json"
MAX_ENTRIES = 20_000
MAX_PATH_DEPTH = 32
MAX_PATH_BYTES = 4096
MAX_FILE_BYTES = 512 * 1024 * 1024
MAX_TOTAL_BYTES = 1024 * 1024 * 1024
MAX_ARCHIVE_BYTES = MAX_TOTAL_BYTES + 64 * 1024 * 1024
MAX_MANIFEST_BYTES = 16 * 1024 * 1024
MAX_COMPRESSION_RATIO = 10_000
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,47}$")
ARCHIVE_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}\.zip$")
DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
FILE_READ_FLAGS = os.O_RDONLY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
FILE_WRITE_FLAGS = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
RENAME_NOREPLACE = 1
REQUIRED_TOP_LEVEL_DIRS = {".home", ".tmp", ".cache", ".deps", "inputs", "outputs"}


class ArchiveError(ValueError):
    """A snapshot is unsafe, malformed, inconsistent or exceeds a limit."""


def _reject_duplicate_json_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ArchiveError(f"duplicate JSON key in snapshot manifest: {key}")
        result[key] = value
    return result


def _validate_archive_name(name: str) -> str:
    if not isinstance(name, str) or not ARCHIVE_NAME_RE.fullmatch(name):
        raise ArchiveError("Archive name must be a simple .zip filename (no directories or traversal)")
    if name in {".", ".."} or "/" in name or "\\" in name:
        raise ArchiveError("Unsafe archive filename")
    return name


def _validate_workspace_name(name: str) -> str:
    if not isinstance(name, str) or not NAME_RE.fullmatch(name):
        raise ArchiveError("Workspace name must contain 1-48 letters, numbers, '_' or '-'")
    return name


def _validate_component(component: str) -> str:
    if not isinstance(component, str) or not component or component in {".", ".."}:
        raise ArchiveError("Empty or traversal path component")
    if "/" in component or "\\" in component or "\x00" in component:
        raise ArchiveError("Path component contains a separator or NUL")
    try:
        raw = component.encode("utf-8", errors="strict")
    except UnicodeError as exc:
        raise ArchiveError("Path component is not valid UTF-8") from exc
    if len(raw) > 255 or unicodedata.normalize("NFC", component) != component:
        raise ArchiveError("Path component is too long or not Unicode NFC-normalized")
    if any(unicodedata.category(ch) in {"Cc", "Cf", "Cs"} for ch in component):
        raise ArchiveError("Path component contains control, format or surrogate characters")
    return component


def _validate_rel_path(path: str) -> tuple[str, ...]:
    if not isinstance(path, str) or not path or path.startswith("/") or "\\" in path or "\x00" in path:
        raise ArchiveError("Snapshot path must be a non-empty relative POSIX path")
    try:
        raw = path.encode("utf-8", errors="strict")
    except UnicodeError as exc:
        raise ArchiveError("Snapshot path is not valid UTF-8") from exc
    parts = tuple(path.split("/"))
    if len(raw) > MAX_PATH_BYTES or len(parts) > MAX_PATH_DEPTH:
        raise ArchiveError("Snapshot path exceeds its length or depth limit")
    for part in parts:
        _validate_component(part)
    if PurePosixPath(path).as_posix() != path:
        raise ArchiveError("Snapshot path is not canonical")
    return parts


def _path_key(path: str) -> str:
    return unicodedata.normalize("NFKC", path).casefold()


def _identity_tuple(st: os.stat_result) -> tuple[int, ...]:
    return (st.st_dev, st.st_ino, st.st_mode, st.st_size,
            st.st_mtime_ns, st.st_ctime_ns, st.st_nlink, st.st_uid)


def _same_object(before: os.stat_result, after: os.stat_result) -> bool:
    return _identity_tuple(before) == _identity_tuple(after)


def _same_object_from_identity(st: os.stat_result, identity: tuple[int, ...]) -> bool:
    return _identity_tuple(st) == identity


def _open_dir_at(parent_fd: int, name: str) -> int:
    try:
        fd = os.open(name, DIR_FLAGS, dir_fd=parent_fd)
    except OSError as exc:
        raise ArchiveError(f"Refusing unsafe directory component {name!r}: {exc}") from exc
    if not stat.S_ISDIR(os.fstat(fd).st_mode):
        os.close(fd)
        raise ArchiveError(f"Expected a directory: {name!r}")
    return fd


def _open_dir_path(root_fd: int, parts: tuple[str, ...]) -> int:
    current = os.dup(root_fd)
    try:
        for part in parts:
            nxt = _open_dir_at(current, part)
            os.close(current)
            current = nxt
        return current
    except Exception:
        os.close(current)
        raise


def _open_file_at(root_fd: int, parts: tuple[str, ...]) -> int:
    if not parts:
        raise ArchiveError("Empty file path")
    parent_fd = _open_dir_path(root_fd, parts[:-1])
    try:
        try:
            return os.open(parts[-1], FILE_READ_FLAGS, dir_fd=parent_fd)
        except OSError as exc:
            raise ArchiveError(f"Refusing unsafe file {parts[-1]!r}: {exc}") from exc
    finally:
        os.close(parent_fd)


def _scan_workspace(workspace_fd: int, expected_uid: int) -> list[dict]:
    entries: list[dict] = []
    normalized: dict[str, str] = {}
    total_bytes = 0
    files = 0
    directories = 0

    def walk(directory_fd: int, prefix: tuple[str, ...]) -> None:
        nonlocal total_bytes, files, directories
        try:
            with os.scandir(directory_fd) as iterator:
                names = sorted((entry.name for entry in iterator), key=os.fsencode)
        except OSError as exc:
            raise ArchiveError(f"Cannot enumerate workspace directory: {exc}") from exc
        for name in names:
            _validate_component(name)
            parts = prefix + (name,)
            rel = "/".join(parts)
            if len(rel.encode("utf-8")) > MAX_PATH_BYTES or len(parts) > MAX_PATH_DEPTH:
                raise ArchiveError(f"Workspace path exceeds supported bounds: {rel!r}")
            key = _path_key(rel)
            if key in normalized:
                raise ArchiveError(f"Ambiguous path collision: {normalized[key]!r} and {rel!r}")
            normalized[key] = rel
            try:
                before = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            except OSError as exc:
                raise ArchiveError(f"Workspace entry changed during scan: {rel}: {exc}") from exc
            if before.st_uid != expected_uid:
                raise ArchiveError(f"Workspace entry has an unexpected owner: {rel}")
            if stat.S_ISDIR(before.st_mode):
                child_fd = _open_dir_at(directory_fd, name)
                try:
                    after = os.fstat(child_fd)
                    if not _same_object(before, after):
                        raise ArchiveError(f"Directory changed during scan: {rel}")
                    directories += 1
                    entries.append({
                        "path": rel, "type": "directory",
                        "mode": stat.S_IMODE(before.st_mode) & 0o777,
                        "_identity": (after.st_dev, after.st_ino, after.st_mode, after.st_size,
                                      after.st_mtime_ns, after.st_ctime_ns, after.st_nlink, after.st_uid),
                    })
                    if len(entries) > MAX_ENTRIES:
                        raise ArchiveError(f"Workspace exceeds {MAX_ENTRIES} entries")
                    walk(child_fd, parts)
                finally:
                    os.close(child_fd)
            elif stat.S_ISREG(before.st_mode):
                if before.st_nlink != 1:
                    raise ArchiveError(f"Hard-linked workspace files are not snapshot-safe: {rel}")
                if before.st_size < 0 or before.st_size > MAX_FILE_BYTES:
                    raise ArchiveError(f"Workspace file exceeds the per-file limit: {rel}")
                total_bytes += before.st_size
                files += 1
                if total_bytes > MAX_TOTAL_BYTES:
                    raise ArchiveError(f"Workspace exceeds the {MAX_TOTAL_BYTES}-byte snapshot limit")
                entries.append({
                    "path": rel,
                    "type": "file",
                    "mode": stat.S_IMODE(before.st_mode) & 0o777,
                    "size": before.st_size,
                    "_identity": (before.st_dev, before.st_ino, before.st_mode, before.st_size,
                                  before.st_mtime_ns, before.st_ctime_ns, before.st_nlink, before.st_uid),
                })
                if len(entries) > MAX_ENTRIES:
                    raise ArchiveError(f"Workspace exceeds {MAX_ENTRIES} entries")
            else:
                kind = "symlink" if stat.S_ISLNK(before.st_mode) else "special file"
                raise ArchiveError(f"Snapshot refuses {kind}: {rel}")

    walk(workspace_fd, ())
    top_dirs = {entry["path"] for entry in entries if entry["type"] == "directory" and "/" not in entry["path"]}
    missing = REQUIRED_TOP_LEVEL_DIRS - top_dirs
    if missing:
        raise ArchiveError(f"Workspace is missing required directories: {sorted(missing)}")
    return sorted(entries, key=lambda e: (len(e["path"].split("/")), e["path"].casefold(), e["path"]))


def _zip_info(name: str, mode: int, is_dir: bool = False) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.compress_type = zipfile.ZIP_STORED if is_dir else zipfile.ZIP_DEFLATED
    info.external_attr = ((stat.S_IFDIR if is_dir else stat.S_IFREG) | (mode & 0o777)) << 16
    info.flag_bits = 0
    return info


def _publish_noreplace(directory_fd: int, temporary_name: str, final_name: str) -> None:
    try:
        os.link(temporary_name, final_name, src_dir_fd=directory_fd,
                dst_dir_fd=directory_fd, follow_symlinks=False)
    except FileExistsError:
        raise ArchiveError(f"Refusing to overwrite existing archive: {final_name}")
    os.unlink(temporary_name, dir_fd=directory_fd)
    os.fsync(directory_fd)


def create_snapshot(workspaces_fd: int, workspace_name: str,
                    artifacts_fd: int, archive_name: str) -> dict:
    workspace_name = _validate_workspace_name(workspace_name)
    archive_name = _validate_archive_name(archive_name)
    workspace_fd = _open_dir_at(workspaces_fd, workspace_name)
    temporary_name = f".snapshot-{uuid.uuid4().hex}.tmp"
    archive_fd = None
    try:
        workspace_stat = os.fstat(workspace_fd)
        entries = _scan_workspace(workspace_fd, workspace_stat.st_uid)
        try:
            archive_fd = os.open(temporary_name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0), 0o600, dir_fd=artifacts_fd)
        except OSError as exc:
            raise ArchiveError(f"Cannot create private snapshot staging file: {exc}") from exc
        archive_stream = os.fdopen(os.dup(archive_fd), "w+b")
        try:
            with zipfile.ZipFile(archive_stream, "w", compression=zipfile.ZIP_DEFLATED,
                                 compresslevel=6, allowZip64=True, strict_timestamps=True) as archive:
                final_entries = []
                for entry in entries:
                    path = entry["path"]
                    if entry["type"] == "directory":
                        directory_fd = _open_dir_path(workspace_fd, _validate_rel_path(path))
                        try:
                            current = os.fstat(directory_fd)
                            if not _same_object_from_identity(current, entry["_identity"]):
                                raise ArchiveError(f"Directory changed before snapshot read: {path}")
                        finally:
                            os.close(directory_fd)
                        archive.writestr(_zip_info(f"workspace/{path}/", entry["mode"], True), b"")
                        final_entries.append({k: entry[k] for k in ("path", "type", "mode")})
                        continue
                    parts = _validate_rel_path(path)
                    source_fd = _open_file_at(workspace_fd, parts)
                    digest = hashlib.sha256()
                    copied = 0
                    try:
                        before = os.fstat(source_fd)
                        identity = entry["_identity"]
                        if (before.st_dev, before.st_ino, before.st_mode, before.st_size,
                            before.st_mtime_ns, before.st_ctime_ns, before.st_nlink, before.st_uid) != identity:
                            raise ArchiveError(f"File changed before snapshot read: {path}")
                        zip_info = _zip_info(f"workspace/{path}", entry["mode"], False)
                        with archive.open(zip_info, "w", force_zip64=True) as destination:
                            while True:
                                chunk = os.read(source_fd, 1024 * 1024)
                                if not chunk:
                                    break
                                copied += len(chunk)
                                if copied > entry["size"] or copied > MAX_FILE_BYTES:
                                    raise ArchiveError(f"File grew during snapshot: {path}")
                                digest.update(chunk)
                                destination.write(chunk)
                        after = os.fstat(source_fd)
                        if copied != entry["size"] or not _same_object(before, after):
                            raise ArchiveError(f"File changed while snapshotting: {path}")
                    finally:
                        os.close(source_fd)
                    final_entries.append({
                        "path": path, "type": "file", "mode": entry["mode"],
                        "size": copied, "sha256": digest.hexdigest(),
                    })
                # Re-scan after streaming the archive. This catches additions,
                # removals, renames and metadata/content changes that occurred
                # between the initial inventory and the last file read.
                final_scan = _scan_workspace(workspace_fd, workspace_stat.st_uid)
                initial_identity = [
                    (e["path"], e["type"], e["_identity"]) for e in entries
                ]
                final_identity = [
                    (e["path"], e["type"], e["_identity"]) for e in final_scan
                ]
                if initial_identity != final_identity:
                    raise ArchiveError("Workspace changed during snapshot; no archive was published")
                manifest = {
                    "format": FORMAT,
                    "schema_version": SCHEMA_VERSION,
                    "source_workspace": workspace_name,
                    "created_at_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                    "entries": final_entries,
                    "totals": {
                        "files": sum(1 for e in final_entries if e["type"] == "file"),
                        "directories": sum(1 for e in final_entries if e["type"] == "directory"),
                        "bytes": sum(e.get("size", 0) for e in final_entries),
                    },
                }
                manifest_raw = (json.dumps(manifest, ensure_ascii=False, sort_keys=True,
                                           separators=(",", ":")) + "\n").encode("utf-8")
                if len(manifest_raw) > MAX_MANIFEST_BYTES:
                    raise ArchiveError("Snapshot manifest exceeds its size limit")
                archive.writestr(_zip_info(MANIFEST_PATH, 0o600), manifest_raw)
        finally:
            archive_stream.flush()
            os.fsync(archive_fd)
            archive_stream.close()
        archive_stat = os.fstat(archive_fd)
        if archive_stat.st_size > MAX_ARCHIVE_BYTES:
            raise ArchiveError(f"Snapshot archive exceeds {MAX_ARCHIVE_BYTES}-byte limit")
        os.fchmod(archive_fd, 0o600)
        os.fsync(archive_fd)
        _publish_noreplace(artifacts_fd, temporary_name, archive_name)
        temporary_name = ""
        digest = _hash_fd(archive_fd)
        return {
            "archive": archive_name,
            "path": f"artifacts/{archive_name}",
            "sha256": digest,
            "archive_bytes": archive_stat.st_size,
            "source_workspace": workspace_name,
            "files": manifest["totals"]["files"],
            "directories": manifest["totals"]["directories"],
            "uncompressed_bytes": manifest["totals"]["bytes"],
            "format": FORMAT,
            "schema_version": SCHEMA_VERSION,
        }
    finally:
        if archive_fd is not None:
            os.close(archive_fd)
        if temporary_name:
            try:
                os.unlink(temporary_name, dir_fd=artifacts_fd)
            except OSError:
                pass
        os.close(workspace_fd)


def _hash_fd(fd: int) -> str:
    digest = hashlib.sha256()
    offset = 0
    while True:
        chunk = os.pread(fd, 1024 * 1024, offset)
        if not chunk:
            break
        digest.update(chunk)
        offset += len(chunk)
    return digest.hexdigest()


def _read_manifest(archive: zipfile.ZipFile, infos: list[zipfile.ZipInfo]) -> tuple[dict, dict[str, zipfile.ZipInfo]]:
    if not infos or len(infos) > MAX_ENTRIES + 1:
        raise ArchiveError("Snapshot archive has an invalid entry count")
    by_name: dict[str, zipfile.ZipInfo] = {}
    canonical_names: dict[str, str] = {}
    workspace_members: dict[str, zipfile.ZipInfo] = {}
    manifest_info = None
    for info in infos:
        name = info.filename
        if info.orig_filename != name or "\x00" in name or "\\" in name or name.startswith("/"):
            raise ArchiveError("Archive contains a non-canonical ZIP member name")
        if len(name.encode("utf-8", errors="strict")) > MAX_PATH_BYTES + 16:
            raise ArchiveError("ZIP member path exceeds its limit")
        if info.flag_bits & 0x1:
            raise ArchiveError("Encrypted ZIP entries are not supported")
        if info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}:
            raise ArchiveError("Only stored and deflated ZIP entries are supported")
        if len(info.extra) > 4096 or len(info.comment) > 1024:
            raise ArchiveError("ZIP extra data or entry comment exceeds its limit")
        if info.file_size < 0 or info.compress_size < 0:
            raise ArchiveError("ZIP entry has a negative declared size")
        if info.file_size > MAX_FILE_BYTES and name != MANIFEST_PATH:
            raise ArchiveError(f"ZIP entry exceeds the per-file limit: {name}")
        if info.file_size and not info.compress_size:
            raise ArchiveError(f"ZIP entry has impossible compressed size: {name}")
        if info.compress_size and info.file_size / info.compress_size > MAX_COMPRESSION_RATIO:
            raise ArchiveError(f"ZIP entry compression ratio exceeds its limit: {name}")
        if name in by_name:
            raise ArchiveError(f"Duplicate ZIP member: {name}")
        folded = _path_key(name)
        if folded in canonical_names:
            raise ArchiveError(f"Ambiguous ZIP member collision: {canonical_names[folded]!r} and {name!r}")
        canonical_names[folded] = name
        by_name[name] = info
        mode = (info.external_attr >> 16) & 0xFFFF
        file_type = stat.S_IFMT(mode)
        is_dir = name.endswith("/")
        if file_type not in {0, stat.S_IFDIR if is_dir else stat.S_IFREG}:
            raise ArchiveError(f"ZIP entry has an unsafe file type: {name}")
        if is_dir and info.file_size != 0:
            raise ArchiveError(f"Directory ZIP entry is not empty: {name}")
        if name == MANIFEST_PATH:
            if is_dir or info.file_size > MAX_MANIFEST_BYTES:
                raise ArchiveError("Snapshot manifest is missing, a directory or oversized")
            manifest_info = info
            continue
        if name.startswith("META/"):
            raise ArchiveError(f"Unexpected metadata member: {name}")
        if not name.startswith("workspace/"):
            raise ArchiveError(f"Unexpected top-level ZIP member: {name}")
        raw_relative = name[len("workspace/"):]
        if not raw_relative:
            raise ArchiveError("Explicit workspace-root ZIP member is not part of the canonical format")
        if is_dir:
            raw_relative = raw_relative[:-1]
        parts = _validate_rel_path(raw_relative)
        rel = "/".join(parts)
        if rel in workspace_members:
            raise ArchiveError(f"Duplicate workspace path: {rel}")
        workspace_members[rel] = info
    if manifest_info is None:
        raise ArchiveError("Snapshot manifest is missing")
    try:
        raw = bytearray()
        with archive.open(manifest_info, "r") as manifest_stream:
            while True:
                chunk = manifest_stream.read(65536)
                if not chunk:
                    break
                raw.extend(chunk)
                if len(raw) > MAX_MANIFEST_BYTES:
                    raise ArchiveError("Snapshot manifest expands beyond its size limit")
        if len(raw) != manifest_info.file_size:
            raise ArchiveError("Snapshot manifest size does not match its ZIP header")
        manifest = json.loads(bytes(raw).decode("utf-8"), object_pairs_hook=_reject_duplicate_json_keys)
    except ArchiveError:
        raise
    except Exception as exc:
        raise ArchiveError(f"Snapshot manifest is unreadable: {exc}") from exc
    if not isinstance(manifest, dict) or set(manifest) != {
        "format", "schema_version", "source_workspace", "created_at_utc", "entries", "totals"
    }:
        raise ArchiveError("Snapshot manifest has an unknown or incomplete schema")
    if manifest["format"] != FORMAT or type(manifest["schema_version"]) is not int or manifest["schema_version"] != SCHEMA_VERSION:
        raise ArchiveError("Unsupported workspace snapshot format or schema version")
    _validate_workspace_name(manifest["source_workspace"])
    timestamp = manifest["created_at_utc"]
    if not isinstance(timestamp, str) or not timestamp.endswith("Z"):
        raise ArchiveError("Snapshot timestamp must be a UTC ISO-8601 string")
    try:
        dt.datetime.fromisoformat(timestamp[:-1] + "+00:00")
    except ValueError as exc:
        raise ArchiveError("Snapshot timestamp is invalid") from exc
    entries = manifest["entries"]
    totals = manifest["totals"]
    if not isinstance(entries, list) or len(entries) > MAX_ENTRIES:
        raise ArchiveError("Snapshot manifest entry list is invalid or too large")
    if not isinstance(totals, dict) or set(totals) != {"files", "directories", "bytes"}:
        raise ArchiveError("Snapshot totals are invalid")
    for key in ("files", "directories", "bytes"):
        if type(totals[key]) is not int or totals[key] < 0:
            raise ArchiveError(f"Snapshot totals.{key} must be a non-negative integer")
    expected_members: dict[str, str] = {}
    normalized_paths: dict[str, str] = {}
    manifest_entries_by_path: dict[str, dict] = {}
    declared_files = declared_dirs = declared_bytes = 0
    for entry in entries:
        if not isinstance(entry, dict):
            raise ArchiveError("Snapshot entry must be an object")
        kind = entry.get("type")
        expected_keys = {"path", "type", "mode", "size", "sha256"} if kind == "file" else {"path", "type", "mode"} if kind == "directory" else set()
        if not expected_keys or set(entry) != expected_keys:
            raise ArchiveError("Snapshot entry has an unknown type or fields")
        path = entry["path"]
        _validate_rel_path(path)
        folded = _path_key(path)
        if folded in normalized_paths:
            raise ArchiveError(f"Ambiguous manifest path collision: {normalized_paths[folded]!r} and {path!r}")
        normalized_paths[folded] = path
        manifest_entries_by_path[path] = entry
        if type(entry["mode"]) is not int or not 0 <= entry["mode"] <= 0o777:
            raise ArchiveError(f"Unsafe mode in snapshot manifest: {path}")
        if kind == "directory":
            expected_members[path] = "directory"
            declared_dirs += 1
        else:
            if type(entry["size"]) is not int or entry["size"] < 0 or entry["size"] > MAX_FILE_BYTES:
                raise ArchiveError(f"Invalid file size in snapshot manifest: {path}")
            if not isinstance(entry["sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", entry["sha256"]):
                raise ArchiveError(f"Invalid SHA-256 digest in snapshot manifest: {path}")
            expected_members[path] = "file"
            declared_files += 1
            declared_bytes += entry["size"]
            if declared_bytes > MAX_TOTAL_BYTES:
                raise ArchiveError("Snapshot manifest exceeds the aggregate uncompressed size limit")
    if declared_files != totals["files"] or declared_dirs != totals["directories"] or declared_bytes != totals["bytes"]:
        raise ArchiveError("Snapshot manifest totals do not match its entries")
    if len(expected_members) != len(workspace_members):
        raise ArchiveError("ZIP member count does not match the manifest")
    if set(expected_members) != set(workspace_members):
        raise ArchiveError("ZIP member paths do not match the manifest")
    for path, kind in expected_members.items():
        info = workspace_members[path]
        if (kind == "directory") != info.filename.endswith("/"):
            raise ArchiveError(f"ZIP member type does not match manifest: {path}")
        if kind == "file":
            entry = manifest_entries_by_path[path]
            if info.file_size != entry["size"]:
                raise ArchiveError(f"ZIP file size does not match manifest: {path}")
    # Every non-root parent must be explicitly represented as a directory.
    dir_paths = {path for path, kind in expected_members.items() if kind == "directory"}
    for path in expected_members:
        parts = path.split("/")
        for index in range(1, len(parts)):
            parent = "/".join(parts[:index])
            if parent not in dir_paths:
                raise ArchiveError(f"Snapshot path lacks an explicit parent directory: {path}")
    if not REQUIRED_TOP_LEVEL_DIRS.issubset(dir_paths):
        raise ArchiveError("Snapshot omits one or more required workspace directories")
    return manifest, workspace_members


def _open_external_regular_file(source_path: str) -> int:
    """Open an operator-selected archive path without following any symlink."""
    if not isinstance(source_path, str) or not source_path or "\x00" in source_path:
        raise ArchiveError("Import source must be a non-empty filesystem path")
    try:
        encoded = os.fsencode(source_path)
    except UnicodeError as exc:
        raise ArchiveError("Import source path is not representable by the filesystem") from exc
    if len(encoded) > MAX_PATH_BYTES:
        raise ArchiveError("Import source path exceeds its length limit")
    absolute = source_path.startswith("/")
    components = source_path.split("/")
    if absolute:
        components = components[1:]
    if (not components or any(part in {"", ".", ".."} for part in components)
            or len(components) > MAX_PATH_DEPTH):
        raise ArchiveError("Import source path must be canonical and contain no traversal components")

    current_fd = os.open("/" if absolute else ".", DIR_FLAGS)
    try:
        for component in components[:-1]:
            try:
                next_fd = os.open(component, DIR_FLAGS, dir_fd=current_fd)
            except OSError as exc:
                raise ArchiveError(f"Import source has an unsafe directory component {component!r}: {exc}") from exc
            os.close(current_fd)
            current_fd = next_fd
        flags = FILE_READ_FLAGS | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_NOCTTY", 0)
        try:
            fd = os.open(components[-1], flags, dir_fd=current_fd)
        except OSError as exc:
            raise ArchiveError(f"Cannot safely open import source: {exc}") from exc
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            os.close(fd)
            raise ArchiveError("Import source must be a regular file; symlinks and special files are refused")
        if st.st_size <= 0 or st.st_size > MAX_ARCHIVE_BYTES:
            os.close(fd)
            raise ArchiveError(f"Import source must be 1..{MAX_ARCHIVE_BYTES} bytes")
        return fd
    finally:
        os.close(current_fd)


def import_snapshot(source_path: str, artifacts_fd: int,
                    archive_name: str | None = None) -> dict:
    """Copy, fully verify and atomically import a workspace snapshot archive.

    The caller-selected source is never modified or removed. The imported file
    is published only after the ZIP structure, manifest, CRCs and every file
    digest pass the same verifier used by verify_snapshot().
    """
    if archive_name is None:
        archive_name = source_path.rsplit("/", 1)[-1] if isinstance(source_path, str) else ""
    archive_name = _validate_archive_name(archive_name)
    source_fd = _open_external_regular_file(source_path)
    temporary_name = f"import-{uuid.uuid4().hex}.zip"
    destination_fd = None
    try:
        before = os.fstat(source_fd)
        flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
        try:
            destination_fd = os.open(temporary_name, flags, 0o600, dir_fd=artifacts_fd)
        except OSError as exc:
            raise ArchiveError(f"Cannot create private import staging file: {exc}") from exc
        copied = 0
        source_digest = hashlib.sha256()
        while True:
            chunk = os.read(source_fd, 1024 * 1024)
            if not chunk:
                break
            copied += len(chunk)
            if copied > before.st_size or copied > MAX_ARCHIVE_BYTES:
                raise ArchiveError("Import source grew beyond its declared or allowed size")
            source_digest.update(chunk)
            view = memoryview(chunk)
            while view:
                written = os.write(destination_fd, view)
                if written <= 0:
                    raise ArchiveError("Short write during snapshot import")
                view = view[written:]
        after = os.fstat(source_fd)
        if copied != before.st_size or not _same_object(before, after):
            raise ArchiveError("Import source changed while being copied; nothing was published")
        os.fchmod(destination_fd, 0o600)
        os.fsync(destination_fd)
        os.fsync(artifacts_fd)

        # Verify the private copy, not the user-controlled source path.
        verification = verify_snapshot(artifacts_fd, temporary_name)
        staged_stat = os.fstat(destination_fd)
        named_stat = os.stat(temporary_name, dir_fd=artifacts_fd, follow_symlinks=False)
        if not stat.S_ISREG(named_stat.st_mode) or (staged_stat.st_dev, staged_stat.st_ino) != (named_stat.st_dev, named_stat.st_ino):
            raise ArchiveError("Import staging file changed during verification")
        if verification["sha256"] != source_digest.hexdigest():
            raise ArchiveError("Imported archive bytes differ from the copied source")

        _publish_noreplace(artifacts_fd, temporary_name, archive_name)
        temporary_name = ""
        return {
            "imported": True,
            "archive": archive_name,
            "sha256": verification["sha256"],
            "archive_bytes": verification["archive_bytes"],
            "source_workspace": verification["source_workspace"],
            "files": verification["files"],
            "directories": verification["directories"],
            "uncompressed_bytes": verification["uncompressed_bytes"],
            "format": FORMAT,
            "schema_version": SCHEMA_VERSION,
        }
    finally:
        if destination_fd is not None:
            os.close(destination_fd)
        os.close(source_fd)
        if temporary_name:
            try:
                os.unlink(temporary_name, dir_fd=artifacts_fd)
                os.fsync(artifacts_fd)
            except FileNotFoundError:
                pass
            except OSError:
                pass


@contextlib.contextmanager
def _open_snapshot(artifacts_fd: int, archive_name: str):
    archive_name = _validate_archive_name(archive_name)
    try:
        archive_fd = os.open(archive_name, FILE_READ_FLAGS, dir_fd=artifacts_fd)
    except OSError as exc:
        raise ArchiveError(f"Cannot safely open snapshot archive {archive_name}: {exc}") from exc
    try:
        st = os.fstat(archive_fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size > MAX_ARCHIVE_BYTES:
            raise ArchiveError("Snapshot must be a regular file within the archive size limit")
        stream = os.fdopen(os.dup(archive_fd), "rb")
        try:
            with zipfile.ZipFile(stream, "r") as archive:
                infos = archive.infolist()
                manifest, members = _read_manifest(archive, infos)
                yield archive_fd, st, archive, manifest, members
        except ArchiveError:
            raise
        except Exception as exc:
            raise ArchiveError(f"Snapshot ZIP is malformed or corrupt: {exc}") from exc
        finally:
            if not stream.closed:
                stream.close()
    finally:
        os.close(archive_fd)


def _verify_payloads(archive: zipfile.ZipFile, manifest: dict,
                     members: dict[str, zipfile.ZipInfo]) -> None:
    for entry in manifest["entries"]:
        path = entry["path"]
        info = members[path]
        try:
            if entry["type"] == "directory":
                if archive.read(info) != b"":
                    raise ArchiveError(f"Directory entry contains data: {path}")
                continue
            digest = hashlib.sha256()
            copied = 0
            with archive.open(info, "r") as source:
                while True:
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    copied += len(chunk)
                    if copied > entry["size"] or copied > MAX_FILE_BYTES:
                        raise ArchiveError(f"Snapshot member expands beyond its declared size: {path}")
                    digest.update(chunk)
            if copied != entry["size"] or digest.hexdigest() != entry["sha256"]:
                raise ArchiveError(f"Snapshot file digest or size mismatch: {path}")
        except ArchiveError:
            raise
        except Exception as exc:
            raise ArchiveError(f"Cannot verify snapshot member {path}: {exc}") from exc


def verify_snapshot(artifacts_fd: int, archive_name: str) -> dict:
    with _open_snapshot(artifacts_fd, archive_name) as (archive_fd, st, archive, manifest, members):
        _verify_payloads(archive, manifest, members)
        totals = manifest["totals"]
        return {
            "valid": True,
            "archive": archive_name,
            "sha256": _hash_fd(archive_fd),
            "archive_bytes": st.st_size,
            "source_workspace": manifest["source_workspace"],
            "files": totals["files"],
            "directories": totals["directories"],
            "uncompressed_bytes": totals["bytes"],
            "format": FORMAT,
            "schema_version": SCHEMA_VERSION,
        }


def _mkdir_owned(parent_fd: int, name: str, uid: int, gid: int, mode: int = 0o700) -> int:
    try:
        os.mkdir(name, mode, dir_fd=parent_fd)
    except FileExistsError as exc:
        raise ArchiveError(f"Unexpected existing restore path: {name}") from exc
    fd = _open_dir_at(parent_fd, name)
    try:
        os.fchown(fd, uid, gid)
        os.fchmod(fd, mode)
        os.fsync(parent_fd)
        return fd
    except Exception:
        os.close(fd)
        raise


def _remove_tree_at(parent_fd: int, name: str) -> None:
    """Remove an incomplete staging tree without following symlinks."""
    try:
        fd = os.open(name, DIR_FLAGS, dir_fd=parent_fd)
    except FileNotFoundError:
        return
    except OSError:
        try:
            os.unlink(name, dir_fd=parent_fd)
        except OSError:
            pass
        return
    try:
        with os.scandir(fd) as iterator:
            names = [entry.name for entry in iterator]
        for child in names:
            try:
                st = os.stat(child, dir_fd=fd, follow_symlinks=False)
                if stat.S_ISDIR(st.st_mode):
                    _remove_tree_at(fd, child)
                else:
                    os.unlink(child, dir_fd=fd)
            except OSError:
                pass
    finally:
        os.close(fd)
    try:
        os.rmdir(name, dir_fd=parent_fd)
        os.fsync(parent_fd)
    except OSError:
        pass


def _rename_noreplace(old_dir_fd: int, old_name: str,
                      new_dir_fd: int, new_name: str) -> None:
    import ctypes
    libc = ctypes.CDLL(None, use_errno=True)
    try:
        function = libc.renameat2
    except AttributeError as exc:
        raise ArchiveError("This Linux host lacks renameat2; refusing a non-atomic restore publish") from exc
    function.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    function.restype = ctypes.c_int
    rc = function(old_dir_fd, os.fsencode(old_name), new_dir_fd, os.fsencode(new_name), RENAME_NOREPLACE)
    if rc != 0:
        err = ctypes.get_errno()
        if err == errno.EEXIST:
            raise ArchiveError(f"Refusing to replace existing workspace: {new_name}")
        raise ArchiveError(f"Atomic workspace publish failed: {os.strerror(err)}")


def restore_snapshot(artifacts_fd: int, archive_name: str,
                     workspaces_fd: int, workspace_name: str,
                     owner_uid: int, owner_gid: int) -> dict:
    workspace_name = _validate_workspace_name(workspace_name)
    stage_name = f".restore-{uuid.uuid4().hex}"
    stage_fd = None
    published = False
    with _open_snapshot(artifacts_fd, archive_name) as (_archive_fd, archive_stat, archive, manifest, members):
        try:
            stage_fd = _mkdir_owned(workspaces_fd, stage_name, owner_uid, owner_gid, 0o700)
            directory_entries = [e for e in manifest["entries"] if e["type"] == "directory"]
            file_entries = [e for e in manifest["entries"] if e["type"] == "file"]
            for entry in directory_entries:
                if archive.read(members[entry["path"]]) != b"":
                    raise ArchiveError(f"Directory entry contains data: {entry['path']}")
            for entry in sorted(directory_entries, key=lambda e: (len(e["path"].split("/")), e["path"].casefold(), e["path"])):
                parts = _validate_rel_path(entry["path"])
                parent_fd = _open_dir_path(stage_fd, parts[:-1])
                try:
                    directory_fd = _mkdir_owned(parent_fd, parts[-1], owner_uid, owner_gid, 0o700)
                    os.close(directory_fd)
                finally:
                    os.close(parent_fd)
            for entry in sorted(file_entries, key=lambda e: (e["path"].casefold(), e["path"])):
                parts = _validate_rel_path(entry["path"])
                parent_fd = _open_dir_path(stage_fd, parts[:-1])
                destination_fd = None
                try:
                    try:
                        destination_fd = os.open(parts[-1], FILE_WRITE_FLAGS, 0o600, dir_fd=parent_fd)
                    except OSError as exc:
                        raise ArchiveError(f"Cannot safely create restored file {entry['path']}: {exc}") from exc
                    os.fchown(destination_fd, owner_uid, owner_gid)
                    digest = hashlib.sha256()
                    copied = 0
                    try:
                        with archive.open(members[entry["path"]], "r") as source:
                            while True:
                                chunk = source.read(1024 * 1024)
                                if not chunk:
                                    break
                                copied += len(chunk)
                                if copied > entry["size"] or copied > MAX_FILE_BYTES:
                                    raise ArchiveError(f"Restored file expands beyond its declared size: {entry['path']}")
                                digest.update(chunk)
                                view = memoryview(chunk)
                                while view:
                                    written = os.write(destination_fd, view)
                                    if written <= 0:
                                        raise ArchiveError("Short write during workspace restore")
                                    view = view[written:]
                        if copied != entry["size"] or digest.hexdigest() != entry["sha256"]:
                            raise ArchiveError(f"Restored file digest or size mismatch: {entry['path']}")
                        # Keep workspace files private; preserve only the owner's
                        # execute bit so executable scripts remain runnable.
                        restored_mode = 0o600 | (entry["mode"] & 0o100)
                        os.fchmod(destination_fd, restored_mode)
                        os.fsync(destination_fd)
                        os.fsync(parent_fd)
                    except Exception:
                        raise
                finally:
                    if destination_fd is not None:
                        os.close(destination_fd)
                    os.close(parent_fd)
            os.fsync(stage_fd)
            _rename_noreplace(workspaces_fd, stage_name, workspaces_fd, workspace_name)
            published = True
            os.fsync(workspaces_fd)
            totals = manifest["totals"]
            return {
                "restored": True,
                "archive": archive_name,
                "workspace": workspace_name,
                "source_workspace": manifest["source_workspace"],
                "files": totals["files"],
                "directories": totals["directories"],
                "uncompressed_bytes": totals["bytes"],
                "archive_bytes": archive_stat.st_size,
                "format": FORMAT,
                "schema_version": SCHEMA_VERSION,
            }
        except Exception:
            if not published:
                _remove_tree_at(workspaces_fd, stage_name)
            raise
        finally:
            if stage_fd is not None:
                os.close(stage_fd)
