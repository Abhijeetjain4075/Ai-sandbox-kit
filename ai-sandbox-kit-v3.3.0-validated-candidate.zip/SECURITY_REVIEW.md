# Security review — Portable AI Sandbox Kit 3.3.0

**Assessment:** Scope-limited single-user Linux session runner. **Production readiness for hostile multi-tenant or standalone enterprise hosting: NOT APPROVED.**

**Validation scope:** one measured Debian 13 / Linux 6.18.57 / x86_64 hosted container with 2 CPU-equivalents and a 4 GiB outer memory ceiling. No KVM, GPU, writable delegated per-task cgroups, Landlock, task egress or independent VM was exposed. These results do not generalize to other hosts.

## 1. Security objective and trust boundary

The runner reduces accidental and malicious task access to host files, environment secrets, network resources and persistent artifacts. It creates user, mount, network, PID, IPC, UTS and cgroup namespaces, a per-run chroot, read-only runtime mounts, a selected writable session-local tmpfs workspace, bounded scratch tmpfs mounts, dropped capabilities, `no_new_privs`, seccomp and process resource limits.

The outer hosted container, kernel and runtime remain the primary security boundary. The runner shares the outer kernel. Chroot and namespaces are defense-in-depth and do not equal Firecracker/KVM microVM isolation.

## 2. Assets and adversary assumptions

Protected assets include host filesystem content outside the workspace, sibling workspaces, credentials, inherited descriptors, controller policy, task receipts, exported artifacts, outer-container network and host availability.

Treat generated code, repositories, package archives, data files, models, webpages and tool output as untrusted. Anticipate path traversal, symlink/hard-link races, process/threads abuse, resource exhaustion, credential exfiltration, network bypass, malformed input, duplicate execution and controller failure.

The design does not claim containment against kernel/host runtime vulnerabilities, outer container compromise, host root compromise or hypervisor compromise.

## 3. Controls implemented in 3.3.0

### 3.1 Installer and release integrity
- Release allowlist with canonical, bounded paths.
- Descriptor-relative source reads with `O_NOFOLLOW` on every component.
- Regular-file-only package inputs; file count and aggregate payload ceilings.
- SHA-256 manifest verification before staging and after staging.
- Refuse existing install and CLI destination paths.
- Reject symlinked install parents and source-tree path components.
- Build a staged kit and wrapper, publish via `renameat2(RENAME_NOREPLACE)`, and roll back on tested post-publication failures.
- Residual: two final filesystem names are not a true single atomic transaction across sudden power loss; no persistent install journal or automatic recovery scan is implemented.

### 3.2 Task isolation
- User, mount, network, PID, IPC, UTS and cgroup namespaces per task.
- Per-run chroot; read-only `/usr` plus selected Python/toolchain roots under `/opt`; generated minimal `/etc` with synthetic account/NSS/hosts files and bounded no-follow copies of selected runtime files; one writable workspace.
- Bounded tmpfs scratch mounts with `nosuid,nodev,noexec`.
- No host `/mnt`, host `/home`, `/proc` or `/sys` in task rootfs.
- Host-root invocation maps task to `nobody:nogroup`; rootless invocation maps caller UID and relies on outer boundary.
- Capabilities are cleared; `no_new_privs` is enabled.
- Seccomp denies selected namespace/mount/inspection/kernel interfaces and `CLONE_NEWTIME` while retaining ordinary pthread behavior.
- Seccomp is default-allow deny-list, not a complete syscall allowlist.

### 3.3 Resource and lifecycle controls
- Per-process `RLIMIT_AS`, `RLIMIT_CPU`, `RLIMIT_FSIZE`, `RLIMIT_NPROC`, `RLIMIT_NOFILE`, `RLIMIT_STACK`, `RLIMIT_CORE` and `RLIMIT_MEMLOCK` where supported.
- Wall timeout and sampled workspace disk budget.
- Output capture bounded to 256 KiB per stream in memory; raw stdout/stderr and raw argv are not persisted.
- Best-effort redaction of common credential patterns before display; not a complete secret detector.
- Per-workspace locks permit independent workspace concurrency while serializing the same workspace.
- `PR_SET_PDEATHSIG` registered after the launcher drops to its final UID/GID (Linux clears it during credential changes), plus `unshare --kill-child=KILL` and controller exception cleanup. A regression kills the controller and confirms the child workload disappears.
- Residual: no independent watchdog survives every controller/host failure; no aggregate task cgroup is writable; sampled disk budget may overshoot; `RLIMIT_AS`, CPU and NPROC scopes are per process/real UID rather than dedicated per-task aggregates.

### 3.4 Filesystem and artifact controls
- Descriptor-relative `O_NOFOLLOW` workspace creation and tree accounting.
- Workspace and control directories use private permissions.
- Export traverses without following symlinks, requires a regular file, refuses overwrite, applies a 512 MiB copy-time ceiling, hashes the copied bytes and removes partial output on failure.
- Execution receipts record command digest and bounded metadata, not raw arguments or raw output; receipt files are private.
- The `doctor` command writes live capability reports under `~/.local/state/ai-sandbox/`, not into the immutable installed release tree, preserving the package SHA-256 manifest after diagnostics.
- Workspaces persist until explicitly removed; no automatic destructive cleanup.

### 3.5 Workspace snapshot, import and restore
- Snapshots traverse with pinned directory descriptors and `O_NOFOLLOW`; symlinks, hard links, special files, non-canonical names, cross-owner entries, and over-limit trees are rejected.
- Local ZIP archives contain a strict versioned manifest, per-file SHA-256 digests and bounded entries/aggregate sizes.
- Verification checks central-directory structure, member types, ZIP CRCs, manifest consistency and every file digest.
- Import opens an operator-selected source path component-by-component with `O_NOFOLLOW`, requires a regular file within the archive ceiling, copies it into a private staging file, checks source stability, verifies ZIP structure/CRC/manifest/every file digest, then publishes with no-overwrite semantics.
- Snapshot capture records file and directory identities, checks them during reads, then re-inventories the workspace before publication to reject observed concurrent changes.
- Restore writes into a private staging directory, verifies each file while streaming, assigns the sandbox identity, then publishes with `renameat2(RENAME_NOREPLACE)`. Existing workspaces are never overwritten; failed staging trees are removed.
- Residual: archives are unsigned and not encrypted by this tool; hashes prove internal consistency, not author identity. They may contain secrets. Symlinks, hard links, ACLs, xattrs, sparse extents and ownership are not preserved.

### 3.6 Policy
- Strict `runtime_policy` schema version 1 loaded before CLI dispatch.
- Reject duplicate JSON keys, unknown/missing keys in the strict block, boolean-as-integer, unsafe owner/mode, symlink policy files and oversized files.
- Resource defaults/maxima are bounded by compiled ceilings; only `network_mode=isolated` is accepted.
- This remains a narrow runtime resource policy, not a general policy-as-code engine, tenant authorization system, capability broker or approval gateway.

## 4. Test evidence

The release test record includes:
- Full sandbox integration suite: `ALL_SANDBOX_TESTS_PASSED` on the measured host.
- Installer regression suite: 10 scenarios including symlink/file preservation, parent/source path symlinks, clean/custom installation and injected rollback failures.
- Runtime policy tests: valid policy, ten malformed/over-limit classes, permissions, symlink, duplicate keys and actual bundled policy load.
- Deterministic policy mutation/fuzz suite: 1,249 invalid mutations rejected.
- Filesystem tests: symlink no-follow and partial artifact cleanup.
- Workspace archive tests: snapshot/import/verify/restore round trip, source-path symlink refusal, symlink/hard-link/special-file refusal, digest tamper detection, rollback cleanup, archive path validation and no-overwrite publication.
- Controller tests: independent workspace concurrency, bounded output, output redaction/non-persistence and controller-crash child cleanup.
- Syscall probe: `CLONE_NEWTIME` denied with `EPERM`, ordinary pthread works, `clone3` compatibility behavior, `io_uring` and `CLONE_NEWUSER` denied.
- Packaging tests: safe allowlist, symlink rejection, archive CRC, extraction and SHA-256 manifest verification, same-environment deterministic rebuild.

Remote GitHub Actions has not been observed running on this kit's repository; CI is authored, not remotely certified. Independent penetration testing and external security review have not been conducted.

## 5. Residual risks and excluded guarantees

1. No independent Firecracker/KVM or equivalent VM boundary.
2. No per-task delegated cgroup v2 CPU/memory/pids/io enforcement.
3. No hard filesystem block or inode quota.
4. No egress proxy, DNS answer pinning, redirect revalidation or SSRF gateway; task network is disabled.
5. No independent persistent watchdog or crash journal capable of recovering from host power loss in all cases.
6. No multi-tenant identity service, RBAC, capability grants, secret broker or action-bound approval service.
7. No durable distributed queue, worker fleet, database-backed orchestration, snapshots or remote artifact store.
8. No signed releases, independent reproducible builder or SLSA provenance. The included provenance is unsigned local metadata.
9. No final project license has been selected; public redistribution rights are not granted by the package.
10. No independent penetration test, formal verification, security certification or production operational acceptance.

## 6. Release gates for hostile multi-tenant / enterprise production

Do not host customer or adversarial code until all applicable gates are implemented and independently evidenced:
- Independent VM boundary per task or trust domain; patched host and guest kernels.
- Enforced aggregate CPU, memory, PID, I/O, storage-block and inode quotas.
- Default-deny proxy with DNS pinning, redirect checks, metadata/private network protection, protocol and bandwidth limits.
- Tenant-bound identity and short-lived secret brokerage; no ambient credentials.
- Durable scheduler, idempotency, cancellation, retries, recovery and single-owner state transitions.
- Signed immutable images, SBOM, verified provenance and vulnerability response.
- Artifact scanning/quarantine, storage encryption, immutable audit and retention controls.
- Fuzzing, adversarial testing, multi-kernel/architecture matrix and independent penetration testing.
- Backup/restore, incident-response, SLO, capacity and rollback drills.
- Approved legal license, privacy/data-processing and operational controls.

## 7. Operational rules

- Never put API keys, tokens, SSH keys or browser profiles in task workspaces.
- Never silently downgrade to unsandboxed execution if namespace setup fails.
- Treat outputs as untrusted until validated.
- Do not automatically delete user workspaces or artifacts.
- External commits, pushes, deployments, messages and API writes require separate authorization and post-action verification.
- Verify the actual host and release hash on every new environment.

## 8. Historical release notes

The preceding v3.0.1-rc1/rc2/rc3 development history and corrective evidence are preserved in the Notion engineering dossier. Rc2 was superseded after its bundled runtime policy rejected an unexpected key; rc3 corrected that defect. Version 3.3.0 builds on 3.2.0 with local bounded workspace snapshots, secure snapshot import, per-file integrity verification and atomic no-overwrite restore, while retaining the same stated single-user/session security boundary.
