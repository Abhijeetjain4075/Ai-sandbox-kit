#!/usr/bin/env python3
"""Transactional, no-follow installer for the portable AI sandbox kit.

Linux-only by design: publication requires renameat2(RENAME_NOREPLACE).
The install root must be below the invoking user's home directory.
"""
from __future__ import annotations

import ctypes
import ctypes.util
import hashlib
import os
import secrets
import shutil
import shlex
import stat
import sys
import re
import unicodedata
from pathlib import Path, PurePosixPath

DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
FILE_FLAGS = os.O_RDONLY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
RENAME_NOREPLACE = 1
MAX_PACKAGE_FILES = 512
MAX_PACKAGE_BYTES = 256 * 1024 * 1024


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def open_dir_at(parent_fd: int, name: str, *, create: bool = False, mode: int = 0o700,
                require_owner: int | None = None) -> int:
    if not name or name in (".", "..") or "/" in name:
        fail(f"unsafe directory component: {name!r}")
    created = False
    if create:
        try:
            os.mkdir(name, mode, dir_fd=parent_fd)
            created = True
            os.fsync(parent_fd)
        except FileExistsError:
            pass
    fd = os.open(name, DIR_FLAGS, dir_fd=parent_fd)
    st = os.fstat(fd)
    if not stat.S_ISDIR(st.st_mode):
        os.close(fd)
        fail(f"not a directory: {name}")
    if require_owner is not None and st.st_uid != require_owner:
        os.close(fd)
        fail(f"directory is not owned by invoking user: {name}")
    if st.st_mode & 0o022:
        os.close(fd)
        fail(f"directory is group/world writable: {name}")
    if created:
        os.fsync(fd)
    return fd


def open_absolute_dir_no_follow(path: Path) -> int:
    """Open an absolute directory by walking from / without following links."""
    if not path.is_absolute():
        fail("expected an absolute directory path")
    current = os.open("/", DIR_FLAGS)
    try:
        for part in path.parts[1:]:
            if part in ("", ".", ".."):
                fail(f"unsafe absolute path component: {part!r}")
            nxt = os.open(part, DIR_FLAGS, dir_fd=current)
            os.close(current)
            current = nxt
        return current
    except Exception:
        os.close(current)
        raise


def open_relative_dir(root_fd: int, parts: tuple[str, ...], *, create: bool,
                      owner: int) -> int:
    current = os.dup(root_fd)
    try:
        for part in parts:
            nxt = open_dir_at(current, part, create=create, mode=0o700,
                              require_owner=owner)
            os.close(current)
            current = nxt
        return current
    except Exception:
        os.close(current)
        raise


def open_source_file_at(source_fd: int, rel: str) -> int:
    """Open a canonical manifest path relative to a pinned source directory.

    Every component is opened with O_NOFOLLOW; a symlinked intermediate
    directory cannot redirect installation outside the supplied source tree.
    """
    p = PurePosixPath(rel)
    if (not rel or "\\" in rel or "\x00" in rel or p.is_absolute()
            or not p.parts or str(p) != rel
            or any(part in ("", ".", "..") for part in p.parts)):
        fail(f"unsafe or non-canonical manifest path: {rel!r}")
    current_fd = os.dup(source_fd)
    try:
        for part in p.parts[:-1]:
            nxt = os.open(part, DIR_FLAGS, dir_fd=current_fd)
            os.close(current_fd)
            current_fd = nxt
        return os.open(p.parts[-1], FILE_FLAGS, dir_fd=current_fd)
    finally:
        os.close(current_fd)


def read_manifest(source_fd: int) -> dict[str, str]:
    fd = open_source_file_at(source_fd, "SHA256SUMS")
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size > 1024 * 1024:
            fail("SHA256SUMS must be a regular file no larger than 1 MiB")
        raw_bytes = bytearray()
        while len(raw_bytes) <= 1024 * 1024:
            chunk = os.read(fd, min(65536, 1024 * 1024 + 1 - len(raw_bytes)))
            if not chunk:
                break
            raw_bytes.extend(chunk)
        if len(raw_bytes) > 1024 * 1024:
            fail("SHA256SUMS exceeds 1 MiB")
        raw = bytes(raw_bytes).decode("utf-8")
    finally:
        os.close(fd)
    result: dict[str, str] = {}
    normalized_paths: set[str] = set()
    for line in raw.splitlines():
        if not line.strip():
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            fail(f"invalid SHA256SUMS line: {line!r}")
        digest, rel = parts
        rel = rel.lstrip("* ")
        p = PurePosixPath(rel)
        if (len(digest) != 64 or any(c not in "0123456789abcdefABCDEF" for c in digest)
                or p.is_absolute() or not p.parts or str(p) != rel
                or "\\" in rel or "\x00" in rel or len(rel) > 1024
                or len(p.parts) > 20 or any(len(x.encode("utf-8")) > 255 for x in p.parts)
                or any(x in ("", ".", "..") for x in p.parts)
                or any(not re.fullmatch(r"[A-Za-z0-9_.-]+", x) for x in p.parts)
                or rel == "SHA256SUMS"):
            fail(f"invalid or unsafe manifest entry: {rel!r}")
        normalized = unicodedata.normalize("NFKC", rel).casefold()
        if normalized in normalized_paths:
            fail(f"duplicate or ambiguous normalized manifest path: {rel!r}")
        normalized_paths.add(normalized)
        result[rel] = digest.lower()
        if len(result) > MAX_PACKAGE_FILES:
            fail(f"release contains more than {MAX_PACKAGE_FILES} files")
    if not result:
        fail("empty SHA256SUMS manifest")
    return result


def read_source_file(source_fd: int, rel: str, expected: str) -> tuple[bytes, int]:
    fd = open_source_file_at(source_fd, rel)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            fail(f"manifest entry is not a regular file: {rel}")
        if st.st_size > 64 * 1024 * 1024:
            fail(f"release file exceeds 64 MiB limit: {rel}")
        chunks = []
        hasher = hashlib.sha256()
        remaining = st.st_size
        while remaining:
            chunk = os.read(fd, min(1024 * 1024, remaining))
            if not chunk:
                fail(f"short read: {rel}")
            chunks.append(chunk)
            hasher.update(chunk)
            remaining -= len(chunk)
        if hasher.hexdigest() != expected:
            fail(f"source checksum mismatch: {rel}")
        return b"".join(chunks), stat.S_IMODE(st.st_mode) & 0o755
    finally:
        os.close(fd)

def mkdirs_inside(root_fd: int, parts: tuple[str, ...], owner: int) -> int:
    return open_relative_dir(root_fd, parts, create=True, owner=owner)


def write_file_at(parent_fd: int, name: str, data: bytes, mode: int) -> None:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(name, flags, mode or 0o600, dir_fd=parent_fd)
    try:
        view = memoryview(data)
        while view:
            n = os.write(fd, view)
            if n <= 0:
                raise OSError("short write")
            view = view[n:]
        os.fchmod(fd, mode or 0o600)
        os.fsync(fd)
    finally:
        os.close(fd)


def rename_noreplace(libc, old_dir_fd: int, old_name: str,
                     new_dir_fd: int, new_name: str) -> None:
    fn = libc.renameat2
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    fn.restype = ctypes.c_int
    rc = fn(old_dir_fd, os.fsencode(old_name), new_dir_fd, os.fsencode(new_name), RENAME_NOREPLACE)
    if rc != 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err), new_name)


def remove_tree_at(parent_fd: int, name: str) -> None:
    """Remove only a directory opened without following links."""
    try:
        fd = os.open(name, DIR_FLAGS, dir_fd=parent_fd)
    except FileNotFoundError:
        return
    try:
        with os.scandir(fd) as entries:
            for entry in list(entries):
                child = entry.name
                st = entry.stat(follow_symlinks=False)
                if stat.S_ISDIR(st.st_mode):
                    remove_tree_at(fd, child)
                else:
                    os.unlink(child, dir_fd=fd)
    finally:
        os.close(fd)
    os.rmdir(name, dir_fd=parent_fd)



def read_source_file_unhashed(source_fd: int, rel: str) -> tuple[bytes, int]:
    fd = open_source_file_at(source_fd, rel)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size > 1024 * 1024:
            fail(f"{rel} must be a regular file no larger than 1 MiB")
        data = bytearray()
        while len(data) < st.st_size:
            chunk = os.read(fd, min(65536, st.st_size - len(data)))
            if not chunk:
                fail(f"short read: {rel}")
            data.extend(chunk)
        return bytes(data), stat.S_IMODE(st.st_mode) & 0o755
    finally:
        os.close(fd)


def main() -> int:
    if len(sys.argv) != 3:
        fail("usage: install_transaction.py SOURCE_DIR INSTALL_DIR")
    # Preserve the caller's lexical source path so the descriptor walk below
    # can reject symlinked root components instead of resolving them away.
    source = Path(os.path.abspath(sys.argv[1]))
    requested = Path(sys.argv[2]).expanduser()
    if not requested.is_absolute():
        fail("AI_SANDBOX_HOME must be an absolute path")
    home = Path(os.path.abspath(Path.home()))
    dest = Path(os.path.abspath(requested))
    try:
        relative = dest.relative_to(home)
    except ValueError:
        fail("AI_SANDBOX_HOME must be inside the invoking user's home directory")
    if not relative.parts:
        fail("AI_SANDBOX_HOME cannot be the home directory itself")
    if any(p in (".", "..") for p in relative.parts):
        fail("unsafe installation path")

    uid = os.getuid()
    home_fd = open_absolute_dir_no_follow(home)
    source_fd = open_absolute_dir_no_follow(source)
    local_fd = bin_fd = dest_parent_fd = stage_fd = None
    stage_name = f".aisandbox-stage-{secrets.token_hex(8)}"
    wrapper_stage = f".aisandbox-wrapper-{secrets.token_hex(8)}"
    dest_name = relative.name
    committed_dir = False
    committed_wrapper = False
    install_complete = False
    wrapper_default = shlex.quote(str(dest))
    wrapper_content = (
        "#!/bin/sh\nset -eu\n"
        f"ROOT=${{AI_SANDBOX_HOME:-{wrapper_default}}}\n"
        "exec python3 \"$ROOT/sandboxctl.py\" \"$@\"\n"
    ).encode()
    try:
        # Use only user-owned, non-group/world-writable directories below HOME.
        local_fd = open_dir_at(home_fd, ".local", create=True, require_owner=uid)
        bin_fd = open_dir_at(local_fd, "bin", create=True, require_owner=uid)
        # Default parent is .local/share. Custom paths are created component-wise.
        dest_parent_fd = open_relative_dir(home_fd, tuple(relative.parts[:-1]), create=True, owner=uid)

        # Both final names must be absent; no pre-existing files are replaced.
        for parent_fd, name in ((dest_parent_fd, dest_name), (bin_fd, "aisandbox")):
            try:
                os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
            except FileNotFoundError:
                continue
            fail(f"refusing to overwrite existing path: {name}")

        # Require Linux renameat2 with no-replace semantics before staging.
        libc_name = ctypes.util.find_library("c")
        libc = ctypes.CDLL(libc_name or None, use_errno=True)
        if not hasattr(libc, "renameat2"):
            fail("renameat2(RENAME_NOREPLACE) is required for safe installation")

        manifest = read_manifest(source_fd)
        os.mkdir(stage_name, 0o700, dir_fd=dest_parent_fd)
        stage_fd = os.open(stage_name, DIR_FLAGS, dir_fd=dest_parent_fd)
        total_payload_bytes = 0
        for rel, digest in sorted(manifest.items()):
            data, mode = read_source_file(source_fd, rel, digest)
            total_payload_bytes += len(data)
            if total_payload_bytes > MAX_PACKAGE_BYTES:
                fail(f"release payload exceeds {MAX_PACKAGE_BYTES}-byte aggregate limit")
            p = PurePosixPath(rel)
            parent = mkdirs_inside(stage_fd, tuple(p.parts[:-1]), owner=uid) if len(p.parts) > 1 else os.dup(stage_fd)
            try:
                write_file_at(parent, p.name, data, mode)
            finally:
                os.close(parent)
        # Preserve the manifest itself (self-hashing is intentionally omitted).
        manifest_data, manifest_mode = read_source_file_unhashed(source_fd, "SHA256SUMS")
        write_file_at(stage_fd, "SHA256SUMS", manifest_data, manifest_mode)
        # Verify the staged manifest's file bytes independently.
        for rel, digest in manifest.items():
            path_fd = os.dup(stage_fd)
            try:
                parts = PurePosixPath(rel).parts
                for part in parts[:-1]:
                    nxt = os.open(part, DIR_FLAGS, dir_fd=path_fd)
                    os.close(path_fd)
                    path_fd = nxt
                fd = os.open(parts[-1], FILE_FLAGS, dir_fd=path_fd)
                try:
                    h = hashlib.sha256()
                    while True:
                        chunk = os.read(fd, 1024 * 1024)
                        if not chunk:
                            break
                        h.update(chunk)
                    if h.hexdigest() != digest:
                        fail(f"staged checksum mismatch: {rel}")
                finally:
                    os.close(fd)
            finally:
                os.close(path_fd)
        os.fchmod(stage_fd, 0o700)
        os.fsync(stage_fd)

        # Stage the wrapper in the same directory as its final name.
        write_file_at(bin_fd, wrapper_stage, wrapper_content, 0o700)
        os.fsync(bin_fd)

        # Publish kit then wrapper. If any operation after the first rename
        # fails, remove only our own wrapper inode (if published) and move the
        # kit back to its staging name. Both final names use NOREPLACE.
        wrapper_stage_stat = os.stat(wrapper_stage, dir_fd=bin_fd, follow_symlinks=False)
        try:
            rename_noreplace(libc, dest_parent_fd, stage_name, dest_parent_fd, dest_name)
            committed_dir = True
            os.fsync(dest_parent_fd)
            rename_noreplace(libc, bin_fd, wrapper_stage, bin_fd, "aisandbox")
            committed_wrapper = True
            os.fsync(bin_fd)
            os.fsync(home_fd)
        except Exception as publish_exc:
            rollback_errors = []
            if committed_wrapper:
                try:
                    current = os.stat("aisandbox", dir_fd=bin_fd, follow_symlinks=False)
                    if (current.st_dev, current.st_ino) != (wrapper_stage_stat.st_dev, wrapper_stage_stat.st_ino):
                        raise OSError("published wrapper inode changed; refusing rollback unlink")
                    os.unlink("aisandbox", dir_fd=bin_fd)
                    committed_wrapper = False
                    os.fsync(bin_fd)
                except Exception as rollback_exc:
                    rollback_errors.append(f"wrapper rollback: {rollback_exc}")
            # Keep the published kit in place if wrapper removal failed; a
            # working wrapper+kit pair is safer than a wrapper pointing nowhere.
            if committed_dir and not rollback_errors:
                try:
                    rename_noreplace(libc, dest_parent_fd, dest_name, dest_parent_fd, stage_name)
                    committed_dir = False
                    os.fsync(dest_parent_fd)
                except Exception as rollback_exc:
                    rollback_errors.append(f"kit rollback: {rollback_exc}")
            if rollback_errors:
                fail(f"installation publication failed ({publish_exc}); rollback incomplete: {'; '.join(rollback_errors)}")
            raise
        install_complete = True

        print(f"Installed sandbox kit: {dest}")
        print(f"CLI: {home / '.local/bin/aisandbox'}")
        print(f"Next: {home / '.local/bin/aisandbox'} doctor")
        print("Install publication used staged checksums and no-replace atomic renames.")
        return 0
    except FileExistsError as exc:
        fail(f"refusing to overwrite an existing install path: {exc}")
    finally:
        if not install_complete:
            try:
                os.unlink(wrapper_stage, dir_fd=bin_fd) if bin_fd is not None else None
            except FileNotFoundError:
                pass
            except OSError:
                pass
        if stage_fd is not None:
            os.close(stage_fd)
        if not committed_dir and dest_parent_fd is not None:
            try:
                remove_tree_at(dest_parent_fd, stage_name)
            except FileNotFoundError:
                pass
        for fd in (dest_parent_fd, bin_fd, local_fd, source_fd, home_fd):
            if fd is not None:
                os.close(fd)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except OSError as exc:
        print(f"installation failed safely: {exc}", file=sys.stderr)
        raise SystemExit(1)
