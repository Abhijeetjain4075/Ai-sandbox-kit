# Portable AI Sandbox Kit

**Current engineering target:** 3.3.0 (scope-limited Linux session runner with portable workspace snapshots)  
**Production boundary:** Not approved for hostile multi-tenant workloads or standalone enterprise hosting.  
**Target:** Linux environments that permit unprivileged user and mount namespaces, `unshare`, and the required security libraries.  
**Purpose:** A reusable, non-destructive execution harness for AI-assisted coding, data analysis, scientific computation, simulations, and repository work.

This kit strengthens the current execution environment with per-task isolation and controls. It does not replace ChatGPT's platform infrastructure, create a new cloud host, or turn the current container into a Firecracker/KVM microVM. The platform's outer container remains the primary boundary.

## 1. Measured execution host

Last measured: **19 November 2026**. Use `aisandbox doctor` to re-measure any other host; do not assume these figures transfer to another conversation or machine.

| Resource | Observed value |
|---|---|
| OS | Debian GNU/Linux 13 (trixie) |
| Kernel / architecture | Linux 6.18.57 / x86_64 |
| CPU | AMD EPYC 9V74 80-Core Processor; 3 visible CPUs |
| Outer CPU quota | 2 CPU-equivalents |
| Outer memory ceiling | 4 GiB cgroup limit |
| Workspace filesystem | ~2.9 GiB total; ~2.9 GiB free on the session-local /dev/shm workspace filesystem at last probe |
| Python | 3.13.5 (`/opt/pyvenv`) |
| Node.js | 22.16.0 |
| Git | 2.47.3 |
| GPU / KVM | No CUDA, NVIDIA, DRM, or `/dev/kvm` device exposed |
| Network from host | DNS failed; TCP to `1.1.1.1:443` was refused at last probe |
| Per-task cgroups | Not delegable: cgroup v2 mount is read-only |
| Landlock | Unavailable: kernel/runtime probe returned `ENOSYS` |

### Useful preinstalled capabilities

**Python/scientific:** NumPy, SciPy, pandas, Matplotlib, Pillow, SymPy, scikit-learn, PyTorch (CPU), JAX (CPU), Numba, OpenCV, NetworkX, statsmodels, XGBoost, LightGBM, FastAPI, Pydantic, SQLAlchemy, h5py, Biopython, pytest, and Jupyter/IPython components.

**Native/tooling:** GCC/G++, Clang, make, CMake, Ninja, Go, Java, Node/npm, Git, FFmpeg and Pandoc. Rust/Cargo, Docker/Podman, Firecracker, QEMU, kubectl and Terraform were not found at the last probe.

The tool inventory is a snapshot, not a promise that every utility exists on future hosts.

## 2. Architecture

Each task run is launched in new:

- user namespace;
- mount namespace;
- network namespace;
- PID namespace;
- IPC namespace;
- UTS namespace;
- cgroup namespace (namespace view only; this host does not delegate task cgroup controllers).

A bootstrap process builds a per-run chroot, mounts the runtime read-only, binds only the selected session-local tmpfs workspace as writable, adds bounded scratch tmpfs mounts, drops Linux capabilities, enables `no_new_privs`, installs seccomp rules, closes inherited descriptors, and execs the requested command.

The control plane and export logic execute outside the task chroot. Output is drained through bounded in-memory pipes (256 KiB per stream); raw stdout/stderr and raw command arguments are not persisted. Common credential patterns are redacted before display as best-effort defence in depth, not a complete secret detector. A private JSON execution receipt records a command hash, status, timing, limits and capture metadata. Different workspaces use separate lock buckets and can run concurrently; operations on the same workspace serialize.

## 3. Isolation controls

### Filesystem

- Read-only bind mount for `/usr` plus only the active Python prefix and selected toolchain roots beneath `/opt`; unrelated host `/opt` services and repositories are not exposed. `/etc` is generated as a minimal synthetic configuration with a bounded no-follow allowlist of runtime files.
- One selected workspace mounted writable at `/workspace`.
- Private scratch tmpfs for `/tmp`, `/var`, `/run`, `/dev`, and `/dev/shm`, with `nosuid,nodev,noexec`.
- Minimal device surface: `/dev/null`, `/dev/zero`, `/dev/random`, `/dev/urandom`.
- No `/proc`, `/sys`, host `/mnt`, host `/home`, or sibling workspace view.
- The sandbox root tree is read-only outside the explicit writable mounts.
- The task workspace persists until the operator explicitly removes it; the controller never performs automatic workspace cleanup. Live `doctor` output is written outside the installed package under `~/.local/state/ai-sandbox/`, so it does not invalidate the immutable release manifest.

### Identity and kernel restrictions

- When invoked by host root, task processes run as host `nobody:nogroup` (65534:65534), mapped to UID/GID 0 only inside the user namespace.
- When installed and invoked by a normal unprivileged user, that invoking UID is mapped to namespace root. This is rootless-compatible, but does not create a second host UID identity: the outer container remains the security boundary.
- Supplementary groups are cleared in the root-managed invocation.
- Linux effective, permitted, inheritable and bounding capabilities are cleared after filesystem setup.
- `no_new_privs` is set.
- Seccomp denies namespace/mount/chroot changes, selected process-inspection interfaces, kernel-management calls, `io_uring`, `pidfd` operations, BPF/perf interfaces and other high-risk syscalls. `clone3` returns `ENOSYS` for libc compatibility; namespace-creating legacy `clone` flags are denied while ordinary threading remains available.
- Seccomp is a **default-allow deny-list**, not a syscall allowlist or a complete defence against kernel vulnerabilities.

### Environment and descriptors

- Task environment is rebuilt from an explicit allowlist. Parent API keys, cloud credentials, proxy variables, browser sessions and arbitrary `PATH` entries are not inherited.
- `PATH` is built from the active Python interpreter and discovered executables under `/usr` or `/opt`.
- User-site Python packages are disabled; optional local wheels can be staged under `/workspace/.deps`.
- Inherited file descriptors above stdin/stdout/stderr are closed before task execution.
- Network access is disabled inside task environments. Use separate research/download tools and stage reviewed files into task inputs.

### Filesystem path hardening

- Workspace directory preparation uses pinned directory file descriptors, `openat`-style operations, `O_NOFOLLOW`, `fchown` and `fchmod`; it does not rely on check-then-follow string paths.
- Controller operations use descriptor-relative paths, `O_NOFOLLOW`, exclusive creation and private directory permissions.
- Workspace-size traversal opens directory descriptors without following task-controlled symlinks.
- Export opens every directory component without following symlinks, uses `O_EXCL|O_NOFOLLOW`, enforces a 512 MiB export ceiling and records a SHA-256 digest.
- If a source grows past the export ceiling during copying, the partial destination is removed; the destination directory is fsynced after successful publication.
- Existing artifacts are never overwritten.

## 4. Runtime policy loading

The 3.3.0 source strictly loads `policy/default.json` before CLI dispatch. The `runtime_policy` object must use schema version 1 and contain exactly the supported defaults, maxima and `network_mode` fields. The loader opens the policy with `O_NOFOLLOW`, requires a regular file owned by root or the invoking user, rejects group/world-writable files, caps input at 1 MiB, rejects duplicate JSON keys, and validates types/ranges. CLI defaults come from this policy. Configured maxima may tighten but cannot exceed the controller's compiled hard ceilings. Network mode is restricted to `isolated`; no configuration field can enable arbitrary egress. This is a narrow runtime policy subset, not a general policy-as-code or capability authorization system.

## 5. Resource limits

Defaults and hard maxima accepted by the CLI:

| Control | Default | CLI maximum / scope |
|---|---:|---|
| Wall timeout | 300 seconds | 1,800 seconds |
| Address space | 3,072 MiB | 3,072 MiB **per process** |
| Workspace storage budget | 1,024 MiB | 2,048 MiB; sampled every 250 ms |
| Individual file size | 256 MiB | 512 MiB per process file |
| Processes per real UID | 64 | Fixed `RLIMIT_NPROC` |
| Open file descriptors | 256 | Fixed `RLIMIT_NOFILE` |
| CPU time | Configured from wall timeout | Per process `RLIMIT_CPU` |
| Stack | 64 MiB | Fixed `RLIMIT_STACK` |
| Core dumps | Disabled | `RLIMIT_CORE=0` |
| Memory locking | Disabled | `RLIMIT_MEMLOCK=0` where supported |
| BLAS/OpenMP/NumExpr | 2 threads | Environment caps |

Important: this host cannot enforce aggregate per-task CPU or memory through cgroups. The 2-CPU and 4-GiB limits are shared by the whole outer container. `RLIMIT_AS` is per process, not an aggregate task-memory budget. Workspace storage is sampled and can briefly overshoot; it is not a dedicated filesystem quota. `RLIMIT_NPROC` is per real UID and is not a substitute for a task-specific pids cgroup.

## 6. Quick start

Run these commands from the extracted kit directory:

```bash
python3 sandboxctl.py doctor
python3 tests/validate_sandbox.py
python3 tests/test_installer_safety.py
python3 tests/test_policy_validation.py
python3 tests/test_policy_fuzz.py
python3 tests/test_filesystem_safety.py
python3 tests/test_controller_features.py
python3 tests/test_workspace_archive.py
python3 tests/test_minimal_etc.py
python3 tests/test_build_release.py
# After building a release ZIP, verify install and execution from that exact archive:
python3 tests/test_archive_install.py --archive /path/to/ai-sandbox-kit-v3.3.0-final.zip
python3 tests/test_archive_install.py --archive /path/to/ai-sandbox-kit-v3.3.0-final.zip --rootless
python3 sandboxctl.py create default
python3 sandboxctl.py run --timeout 300 --memory-mib 3072 default -- python -c 'print(1 + 1)'
python3 sandboxctl.py run --timeout 300 default -- python inputs/numerical_smoke.py
python3 sandboxctl.py run --timeout 60 default -- node --version
python3 sandboxctl.py list
python3 sandboxctl.py export default outputs/result.csv
python3 sandboxctl.py snapshot default --name default-snapshot.zip
python3 sandboxctl.py verify-snapshot default-snapshot.zip
python3 sandboxctl.py restore default-snapshot.zip default-restored
```

Runner options go before the workspace name; the executable command follows `--`. Each run emits a JSON receipt with a command digest, status, timing, limits and output-capture metadata. Raw argv and raw stdout/stderr are not stored. Console output is bounded and common-token redaction is best-effort. Receipt files and exported artifacts are private to the invoking user.

Workspace layout:

```text
/dev/shm/ai-sandbox-<uid>-<installation-hash>/workspaces/<name>/
  .home/ .tmp/ .cache/ .deps/
  inputs/
  outputs/
```

Put input code and data under `inputs/`, write results under `outputs/`, inspect the result, then export only the intended file. Do not put secrets in a task workspace.

## 7. Install for another Linux execution environment

The installer is now staged and checksum-verified. It opens source paths component-by-component without following symlinks; limits a release to 512 files and 256 MiB aggregate payload; stages the complete tree and CLI wrapper; publishes both with Linux `renameat2(RENAME_NOREPLACE)`; and attempts rollback if publication or fsync fails. It refuses pre-existing install paths, symlinked parent directories, and symlinked source subdirectories. Rollback is tested for injected wrapper-publish and post-publish-fsync failures. Power-loss recovery across the two final renames is not a fully journaled two-object transaction and remains a residual limitation.


Extract the archive, enter its directory, and run:

```bash
chmod +x install.sh
./install.sh
```

Default installation:

- Kit: `~/.local/share/ai-sandbox`
- CLI: `~/.local/bin/aisandbox`
- Optional custom kit path: `AI_SANDBOX_HOME=/path/to/kit ./install.sh`

Then:

```bash
~/.local/bin/aisandbox doctor
~/.local/bin/aisandbox create project-a
~/.local/bin/aisandbox run --timeout 300 project-a -- python -c 'print("isolated")'
```

Requirements: Linux, Python 3.10+, util-linux `unshare` with `--kill-child`, glibc exposing `renameat2(RENAME_NOREPLACE)`, `libseccomp.so.2`, `libcap.so.2`, and permission to create user/mount/network/PID/IPC/UTS namespaces and mount inside a user namespace. The runner fails closed if its required namespace setup fails; it does not silently downgrade to ordinary unsandboxed execution. Non-Linux operating systems need a VM/container runtime designed for that OS.

## 8. Portable workspace snapshots

Workspaces are still session-local `/dev/shm` directories. Version 3.3.0 adds a local snapshot lifecycle so a workspace can be carried to another compatible host or session without claiming that the tmpfs itself persists:

```bash
# Create a private archive under the kit's artifacts/ directory
aisandbox snapshot project-a --name project-a-20261119.zip

# Verify ZIP structure, CRCs, size ceilings and each file SHA-256
aisandbox verify-snapshot project-a-20261119.zip

# Import a ZIP received from another session into this kit's private artifact store
aisandbox import-snapshot /path/to/project-a-20261119.zip

# Verify and restore as a new workspace; the destination must not already exist
aisandbox verify-snapshot project-a-20261119.zip
aisandbox restore project-a-20261119.zip project-a-restored
```

Snapshots include regular file contents, directory structure, source modes as metadata, and a per-file SHA-256 manifest. Restore makes files private to the sandbox identity and retains the owner's executable bit. Symlinks, hard-linked files, sockets, FIFOs, devices, ambiguous paths, unsupported ZIP compression, malformed manifests and files exceeding the bounded entry/aggregate limits are rejected. Snapshot creation, import and restore use descriptor-relative no-follow operations. Import opens every source path component without following symlinks, copies to a private staging file, checks source stability and archive bounds, verifies ZIP CRCs plus every content digest, and only then publishes without overwrite. Snapshot capture re-inventories the workspace and refuses publication if files or directory identities changed during capture. Restore publishes a complete staging tree with `renameat2(RENAME_NOREPLACE)`. Failed imports and restores clean up their private staging objects.

Archives are portable files, not remote backups or signed attestations. The import command does not authenticate who created an archive; SHA-256 checks detect corruption relative to the embedded manifest, not malicious authorship. Archives may contain credentials, private source code or other sensitive workspace data; inspect them before sharing. Restored content remains untrusted and must not be executed without review. The archive format currently has no hard-link, symlink, extended-attribute, ownership, ACL or sparse-file preservation.

## 9. Reproducible engineering protocol

1. Run `doctor` before assuming any hardware, package, network or kernel capability.
2. Create one named workspace per bounded workload.
3. Copy only required inputs into that workspace.
4. Record commands, parameters, tool versions and input hashes.
5. Execute only via the controller; inspect bounded console output and the private JSON execution receipt. Raw stdout/stderr and raw argv are not persisted.
6. Run functional tests and independent validation, not just a successful exit code.
7. Export reviewed regular files; do not export secrets or untrusted executables without inspection.
8. Keep external side effects—Git pushes, deployments, messages, account changes, API writes—outside the sandbox and require separate authorization and post-action verification.
9. Preserve workspaces unless explicit deletion is requested.

## 10. Portability across conversations

Workspaces reside on `/dev/shm` (tmpfs) because some hosted overlayfs mounts cannot be bind-mounted from an unprivileged user namespace. Workspace contents are session-local and disappear when the host session ends; export important results through the artifact command before the session ends. A durable assistant preference can instruct future chats to use the strongest practical isolated runner and inspect the runtime first. A running container, process, mount namespace, workspace filesystem or live sandbox session does **not** automatically persist into a new conversation. Keep this ZIP in the user's persistent file library or local storage and make it available when a future environment needs to install/reuse it. The future assistant must re-run `doctor` and the validation suite before claiming that the sandbox is active.

## 11. Production upgrade path

For hostile multi-tenant code execution, customer workloads, or high-assurance security, move task execution to independently provisioned Firecracker/KVM microVMs or another hardened VM boundary with:

- one VM per task or tenant;
- enforceable per-VM cgroup CPU/memory/pids/io quotas;
- default-deny egress with DNS pinning and redirect revalidation;
- immutable signed base images and SBOMs;
- snapshot/restore and immutable artifact storage;
- audit trails and action receipts;
- vulnerability management, kernel patching, fuzzing and independent penetration testing.

This portable kit is a hardened session runner and engineering reference. It is not a certified isolation product or a replacement for that infrastructure.

## 12. Version 3.3.0 release status

This is the consolidated, scope-limited release for a Linux session runner. It includes the transactional/no-follow installer, strict runtime policy loading, `CLONE_NEWTIME` seccomp coverage, kernel parent-death signalling plus `unshare --kill-child`, bounded in-memory output capture, best-effort display redaction, private command-hash receipts, per-workspace locks, symlink-safe workspace accounting, bounded artifact export with partial-output cleanup, local verified workspace snapshot/verify/restore with SHA-256 manifest and atomic no-overwrite publication, a deterministic release builder, CycloneDX SBOM, unsigned local provenance record, and a pinned GitHub Actions CI workflow.

The full integration suite and targeted installer, policy, policy-mutation, filesystem, controller, workspace-archive and extracted-package snapshot/restore, syscall, minimal-runtime, release-builder and extracted-archive installation tests are run on the measured hosted Linux environment. The archive-install test runs both root-managed and rootless modes, executes `doctor`, verifies that diagnostics do not mutate the installed SHA-256 manifest, creates a tmpfs workspace and executes a Python task from the installed CLI. The build script verifies archive CRCs, release-manifest coverage, per-file SHA-256 digests, safe archive paths and same-environment reproducibility. Remote GitHub Actions execution is **not** claimed until it has run on a repository and the exact run has been read back.

This is a single-user/session runner inside an existing trusted outer container. It is not a hostile multi-tenant service or independent VM boundary. The measured host does not expose KVM/GPU, writable per-task cgroups, hard block/inode quotas or task network egress. A full enterprise deployment still requires VM-backed isolation, aggregate quotas, a controlled egress proxy, identity/secret services, durable orchestration, independent penetration testing, signed provenance, an approved license, and operational acceptance. No security certification or blanket production-readiness claim is made.

## 13. Build, verify and reproduce a release

The release allowlist is `release_files.txt`. The builder rejects unsafe paths, symlinked inputs, non-regular files, duplicate entries and oversized payloads. It generates a CycloneDX 1.6 file-level SBOM, an explicitly unsigned local provenance record, canonical `SHA256SUMS`, and a deterministic ZIP. It then extracts the ZIP in a fresh temporary directory and verifies every manifest entry.

```bash
python3 tests/test_build_release.py
python3 scripts/build_release.py --output /tmp/ai-sandbox-kit-v3.3.0-final.zip
sha256sum -c SHA256SUMS
```

The provenance record is not a signature, SLSA attestation or independent builder attestation. The ZIP checksum sidecar is external to the archive by design.
