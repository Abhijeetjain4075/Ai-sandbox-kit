#!/bin/sh
set -eu
SOURCE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DEST_DIR=${AI_SANDBOX_HOME:-"$HOME/.local/share/ai-sandbox"}

for cmd in python3 unshare; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "Required command not found: $cmd" >&2
    exit 1
  }
done

python3 - <<'PY'
import ctypes.util
missing = [name for name in ("seccomp", "cap") if not ctypes.util.find_library(name)]
if missing:
    raise SystemExit("Missing required shared libraries: " + ", ".join(missing))
PY

exec python3 "$SOURCE_DIR/install_transaction.py" "$SOURCE_DIR" "$DEST_DIR"
