#!/usr/bin/env python3
"""Build a deterministic, checksum-verified AI Sandbox release archive.

The generated provenance is a local unsigned build record, not a SLSA
attestation or cryptographic signature. This script intentionally packages
only paths in release_files.txt and rejects symlinks and non-regular files.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import shutil
import stat
import tempfile
import uuid
import zipfile
from typing import Iterable

ROOT = pathlib.Path(__file__).resolve().parents[1]
MAX_FILES = 512
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TOTAL_BYTES = 256 * 1024 * 1024
GENERATED_METADATA = {"sbom.cdx.json", "provenance.json", "release.json", "SHA256SUMS"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_relative_path(value: str) -> pathlib.PurePosixPath:
    p = pathlib.PurePosixPath(value)
    if (not value or "\\" in value or "\x00" in value or p.is_absolute()
            or str(p) != value or len(p.parts) > 20
            or any(part in ("", ".", "..") for part in p.parts)
            or any(not re.fullmatch(r"[A-Za-z0-9_.-]+", part) for part in p.parts)):
        raise ValueError(f"unsafe or non-canonical release path: {value!r}")
    if len(value.encode("utf-8")) > 1024 or any(len(x.encode("utf-8")) > 255 for x in p.parts):
        raise ValueError(f"release path too long: {value!r}")
    return p


def load_release_paths(root: pathlib.Path = ROOT) -> list[str]:
    raw, _ = read_regular_file(root, "release_files.txt")
    lines = raw.decode("utf-8").splitlines()
    result: list[str] = []
    seen: set[str] = set()
    for raw in lines:
        value = raw.strip()
        if not value or value.startswith("#"):
            continue
        safe_relative_path(value)
        normalized = value.casefold()
        if normalized in seen:
            raise ValueError(f"duplicate release path: {value}")
        seen.add(normalized)
        result.append(value)
    if not result or len(result) > MAX_FILES:
        raise ValueError(f"release file count must be between 1 and {MAX_FILES}")
    required = {"release_files.txt", "release.json", "sbom.cdx.json", "provenance.json"}
    if not required.issubset(set(result)):
        raise ValueError(f"release list missing required metadata files: {sorted(required - set(result))}")
    return sorted(result)


def read_regular_file(root: pathlib.Path, rel: str) -> tuple[bytes, int]:
    """Read a regular file through pinned O_NOFOLLOW directory descriptors."""
    p = safe_relative_path(rel)
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    directory_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | nofollow
    file_flags = os.O_RDONLY | os.O_CLOEXEC | nofollow
    root_fd = os.open(root, directory_flags)
    current_fd = root_fd
    try:
        for component in p.parts[:-1]:
            next_fd = os.open(component, directory_flags, dir_fd=current_fd)
            if current_fd != root_fd:
                os.close(current_fd)
            current_fd = next_fd
        fd = os.open(p.parts[-1], file_flags, dir_fd=current_fd)
        try:
            st = os.fstat(fd)
            if not stat.S_ISREG(st.st_mode):
                raise ValueError(f"release entry is not a regular file: {rel}")
            if st.st_size > MAX_FILE_BYTES:
                raise ValueError(f"release file exceeds {MAX_FILE_BYTES} bytes: {rel}")
            chunks = []
            remaining = st.st_size
            while remaining:
                chunk = os.read(fd, min(1024 * 1024, remaining))
                if not chunk:
                    raise ValueError(f"file changed or short read during release: {rel}")
                chunks.append(chunk)
                remaining -= len(chunk)
            # Detect growth after the fstat/read window.
            if os.read(fd, 1):
                raise ValueError(f"file grew during release read: {rel}")
            return b"".join(chunks), stat.S_IMODE(st.st_mode) & 0o755
        finally:
            os.close(fd)
    except OSError as exc:
        raise ValueError(f"cannot safely read release path {rel}: {exc}") from exc
    finally:
        if current_fd != root_fd:
            os.close(current_fd)
        os.close(root_fd)


def inventory(root: pathlib.Path, paths: Iterable[str]) -> list[dict]:
    rows = []
    total = 0
    for rel in paths:
        data, mode = read_regular_file(root, rel)
        total += len(data)
        if total > MAX_TOTAL_BYTES:
            raise ValueError(f"release payload exceeds {MAX_TOTAL_BYTES} bytes")
        rows.append({"path": rel, "sha256": sha256(data), "size": len(data), "mode": mode})
    return rows


def source_inventory_digest(rows: list[dict]) -> str:
    material = "".join(f"{row['path']}\0{row['sha256']}\0{row['size']}\n" for row in rows)
    return sha256(material.encode())


def release_timestamp(release_date: str) -> tuple[int, str]:
    epoch_text = os.environ.get("SOURCE_DATE_EPOCH")
    if epoch_text is not None:
        epoch = int(epoch_text)
        moment = dt.datetime.fromtimestamp(epoch, tz=dt.timezone.utc)
    else:
        moment = dt.datetime.combine(dt.date.fromisoformat(release_date), dt.time.min, tzinfo=dt.timezone.utc)
        epoch = int(moment.timestamp())
    if not (1980 <= moment.year <= 2107):
        raise ValueError("ZIP timestamp must be between 1980 and 2107")
    return epoch, moment.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def write_bytes_atomic(path: pathlib.Path, raw: bytes, mode: int = 0o644) -> None:
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    tmp = pathlib.Path(tmp_name)
    try:
        os.fchmod(fd, mode)
        view = memoryview(raw)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("short write during atomic release metadata update")
            view = view[written:]
        os.fsync(fd)
        os.close(fd)
        fd = -1
        os.replace(tmp, path)
        parent_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0))
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
    finally:
        if fd >= 0:
            os.close(fd)
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass


def write_json(path: pathlib.Path, value: dict) -> None:
    raw = (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()
    write_bytes_atomic(path, raw)


def generate_sbom(root: pathlib.Path, paths: list[str], timestamp: str, version: str) -> str:
    included = [p for p in paths if p not in GENERATED_METADATA]
    rows = inventory(root, included)
    src_digest = source_inventory_digest(rows)
    serial = uuid.UUID(bytes=bytes.fromhex(src_digest[:32]), version=5)
    components = []
    for row in rows:
        components.append({
            "type": "file",
            "bom-ref": f"urn:aisandbox:file:{row['path']}",
            "name": row["path"],
            "hashes": [{"alg": "SHA-256", "content": row["sha256"]}],
            "properties": [
                {"name": "aisandbox:relative-path", "value": row["path"]},
                {"name": "aisandbox:file-size-bytes", "value": str(row["size"])},
                {"name": "aisandbox:unix-mode", "value": oct(row["mode"])},
            ],
        })
    document = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.6",
        "serialNumber": f"urn:uuid:{serial}",
        "version": 1,
        "metadata": {
            "timestamp": timestamp,
            "component": {
                "type": "application",
                "bom-ref": f"urn:aisandbox:release:{version}",
                "name": "Portable AI Sandbox Kit",
                "version": version,
                "description": "Scope-limited Linux session execution harness; not a VM-backed multi-tenant service.",
                "licenses": [],
                "properties": [
                    {"name": "aisandbox:project-license-status", "value": "No project license declared; private-use artifact only."},
                    {"name": "aisandbox:source-inventory-sha256", "value": src_digest},
                    {"name": "aisandbox:sbom-scope", "value": "Project release files; host-provided system libraries and Python/Node packages are not vendored."},
                ],
            },
        },
        "components": components,
    }
    write_json(root / "sbom.cdx.json", document)
    return sha256((root / "sbom.cdx.json").read_bytes())


def generate_provenance(root: pathlib.Path, paths: list[str], timestamp: str,
                        version: str, sbom_hash: str) -> str:
    materials_paths = [p for p in paths if p not in {"provenance.json", "release.json", "sbom.cdx.json"}]
    rows = inventory(root, materials_paths)
    source_digest = source_inventory_digest(rows)
    doc = {
        "statement_type": "local-build-provenance-record",
        "schema_version": 1,
        "release": {"name": "Portable AI Sandbox Kit", "version": version},
        "builder": {
            "id": "scripts/build_release.py",
            "python": f"{os.sys.version_info.major}.{os.sys.version_info.minor}.{os.sys.version_info.micro}",
            "platform": os.name,
        },
        "build": {
            "timestamp": timestamp,
            "source_date_epoch": int(dt.datetime.fromisoformat(timestamp.replace("Z", "+00:00")).timestamp()),
            "source_inventory_sha256": source_digest,
            "sbom_sha256": sbom_hash,
            "git_revision": None,
        },
        "materials": rows,
        "trust": {
            "signed": False,
            "signature_status": "unsigned",
            "slsa_attestation": False,
            "independent_builder_reproduction": False,
            "note": "Local integrity/provenance metadata only. This is not a signed statement, SLSA provenance, independent build attestation, or proof of source identity.",
        },
    }
    write_json(root / "provenance.json", doc)
    return sha256((root / "provenance.json").read_bytes())


def verify_manifest_tree(root: pathlib.Path, manifest: str = "SHA256SUMS") -> int:
    raw = (root / manifest).read_text(encoding="utf-8")
    seen = set()
    count = 0
    for line in raw.splitlines():
        if not line:
            continue
        digest, rel = line.split("  ", 1)
        safe_relative_path(rel)
        if rel in seen:
            raise ValueError(f"duplicate manifest entry: {rel}")
        seen.add(rel)
        data, _ = read_regular_file(root, rel)
        if sha256(data) != digest:
            raise ValueError(f"SHA-256 mismatch: {rel}")
        count += 1
    return count


def deterministic_zip(root: pathlib.Path, paths: list[str], output: pathlib.Path,
                      timestamp_epoch: int) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists() or output.is_symlink():
        raise FileExistsError(f"refusing to overwrite release output: {output}")
    manifest_paths = paths + ["SHA256SUMS"]
    rows = inventory(root, manifest_paths)
    total = sum(r["size"] for r in rows)
    if total > MAX_TOTAL_BYTES:
        raise ValueError("archive exceeds aggregate size limit")
    moment = dt.datetime.fromtimestamp(timestamp_epoch, tz=dt.timezone.utc)
    zip_time = (moment.year, moment.month, moment.day, moment.hour, moment.minute, moment.second - (moment.second % 2))
    fd, tmp_name = tempfile.mkstemp(prefix=f".{output.name}.", suffix=".tmp", dir=output.parent)
    os.close(fd)
    tmp = pathlib.Path(tmp_name)
    try:
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as zf:
            for row in sorted(rows, key=lambda x: x["path"]):
                data, mode = read_regular_file(root, row["path"])
                info = zipfile.ZipInfo(row["path"], date_time=zip_time)
                info.create_system = 3
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = ((stat.S_IFREG | (mode or 0o600)) & 0xFFFF) << 16
                info.flag_bits = 0
                zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        with tmp.open("rb") as f:
            os.fsync(f.fileno())
        # link() publishes atomically and fails rather than overwriting a race winner.
        os.link(tmp, output, follow_symlinks=False)
        tmp.unlink()
        dir_fd = os.open(output.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0))
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    finally:
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass


def verify_archive(output: pathlib.Path) -> tuple[str, int]:
    archive_hash = hashlib.sha256(output.read_bytes()).hexdigest()
    with zipfile.ZipFile(output, "r") as zf:
        bad = zf.testzip()
        if bad:
            raise ValueError(f"ZIP CRC failure: {bad}")
        names = zf.namelist()
        if len(names) != len(set(names)):
            raise ValueError("archive contains duplicate file names")
        for name in names:
            safe_relative_path(name)
        with tempfile.TemporaryDirectory(prefix="aisandbox-release-verify-") as td:
            root = pathlib.Path(td)
            zf.extractall(root)
            count = verify_manifest_tree(root)
            if count != len(names) - 1:
                raise ValueError("SHA256SUMS coverage does not match archive contents")
            release = json.loads((root / "release.json").read_text())
            if release.get("version") != "3.3.0":
                raise ValueError("archive release metadata has unexpected version")
            if release.get("validation") != "SCOPE_LIMITED_LOCAL_VALIDATION":
                raise ValueError("archive release validation state is unexpected")
    return archive_hash, len(names)


def build(root: pathlib.Path, output: pathlib.Path, check_reproducible: bool = True) -> dict:
    paths = load_release_paths(root)
    template = json.loads((root / "release.json").read_text(encoding="utf-8"))
    version = "3.3.0"
    release_date = template.get("release_date", "2026-11-19")
    epoch, timestamp = release_timestamp(release_date)

    sbom_hash = generate_sbom(root, paths, timestamp, version)
    provenance_hash = generate_provenance(root, paths, timestamp, version, sbom_hash)

    # Recompute path list after generated metadata. The allowlist remains fixed.
    final_paths = load_release_paths(root)
    source_paths = [p for p in final_paths if p not in GENERATED_METADATA]
    file_rows = inventory(root, source_paths)
    template.update({
        "name": "Portable AI Sandbox Kit",
        "version": version,
        "release_date": release_date,
        "validation": "SCOPE_LIMITED_LOCAL_VALIDATION",
        "production_readiness": "NOT_APPROVED_FOR_HOSTILE_MULTI_TENANT_OR_ENTERPRISE_PRODUCTION",
        "validation_report": "validation_report.json",
        "capability_report": "capability_report.json",
        "security_review": "SECURITY_REVIEW.md",
        "portable_cross_chat_guidance": "PORTABLE_MEMORY.md",
        "sbom": {"file": "sbom.cdx.json", "format": "CycloneDX", "spec_version": "1.6", "sha256": sbom_hash},
        "provenance": {"file": "provenance.json", "sha256": provenance_hash, "signed": False, "slsa_attestation": False},
        "release_contents": final_paths + ["SHA256SUMS"],
        "release_file_count_excluding_manifest": len(final_paths),
        "archive_installation": "PASS — extracted release ZIP installed and executed through the installed CLI in root-managed and rootless test modes; doctor preserved SHA256SUMS; snapshot/import/restore round trips executed in both modes",
        "candidate_status": "LOCAL_VALIDATION_PASS_WITH_HOST_REPEATABILITY_CAVEATS — one full end-to-end integration run and a complete rootless install run passed; later repeats stalled intermittently during scientific imports or restore. On the exact final candidate, manual rootless continuation completed restore/import/re-execution. See validation_report.json.",
        "release_decision": "CANDIDATE: functional local validation is positive, but repeatability of some integration/harness stages is not established on this hosted Linux environment. Not approved for hostile multi-tenant or enterprise production; independent security review, remote CI, license selection and host-level isolation upgrades remain outstanding.",
        "hosted_ci": "workflow authored; remote GitHub Actions execution not observed in this environment",
        "license_status": "No project-level license selected; private-use artifact; no redistribution grant asserted.",
        "archive_hash_is_external": True,
        "source_inventory_sha256": source_inventory_digest(file_rows),
        "change_summary": [
            "Transactional staging, source path no-follow traversal, manifest validation and no-replace installation publication with rollback for injected publication failures.",
            "Strict runtime policy v1 loaded before CLI dispatch; duplicate-key, owner, permission, symlink, schema and compiled-ceiling validation.",
            "Network remains isolated; no policy setting can enable egress.",
            "Seccomp namespace-creation mask includes CLONE_NEWTIME; default-allow deny-list limitation remains explicit.",
            "Controller uses per-workspace locks for independent tasks and bounded in-memory output; raw stdout/stderr and raw arguments are not persisted.",
            "Best-effort display redaction; no complete secret detector is claimed.",
            "Private execution receipts; descriptor-relative, no-follow filesystem operations; bounded artifact export with partial-output cleanup.",
            "Kernel parent-death signalling is registered after the launcher drops to its final UID/GID (Linux clears it on credential changes); unshare --kill-child and controller exception cleanup are regression-tested against surviving descendants.",
            "Generated minimal /etc uses synthetic identity/NSS/hosts files plus bounded no-follow runtime files; the full host /etc is not mounted.",
            "Only the active Python prefix and selected executable toolchain roots beneath /opt are read-only mounted; unrelated host /opt services and repositories are excluded.",
            "Doctor diagnostics are written to private user state outside the immutable install tree; archive-install regression verifies SHA256SUMS remains valid after doctor.",
            "Archive-install tests verify install, doctor, manifest preservation, workspace creation and actual sandbox execution in root-managed and rootless modes.",
            "Rootless archive-install test harness uses explicit setpriv identity switching rather than Python preexec_fn to avoid host-dependent pre-exec deadlocks.",
            "CI workflow with pinned action commit SHAs, Python version matrix, targeted tests, Linux integration tests, archive install modes and deterministic packaging step.",
            "CycloneDX SBOM and unsigned local provenance record generated deterministically.",
            "Workspace snapshots are streamed into private ZIP artifacts with strict path/type/size validation, per-file SHA-256 manifests and atomic no-overwrite publication.",
            "Snapshot verification checks ZIP CRCs and every content digest; restore stages files on the workspace filesystem and publishes with renameat2(RENAME_NOREPLACE), refusing overwrite and cleaning failed staging trees.",
            "Snapshot import opens source paths component-by-component without following symlinks, copies to a private bounded staging file, validates archive metadata/CRC/content digests and publishes atomically without overwriting an existing artifact.",
            "Snapshot creation rechecks directory/file identities and re-inventories the workspace before publication to detect observed concurrent changes.",
        ],
        "validation_evidence": {
            "full_integration_suite": "PASS ONCE — ALL_SANDBOX_TESTS_PASSED observed; a subsequent repeat stalled during optional scientific imports without a completion marker.",
            "installer_regressions": "PASS — 11 cases, including symlink, overwrite, custom path, clean install, rollback and source-tree path confinement",
            "runtime_policy": "PASS — 10 invalid configurations rejected plus unsafe file, duplicate-key, exact bundled policy and pre-execution limit checks",
            "policy_mutation": "PASS — 1,249 deterministic invalid policy mutations rejected",
            "filesystem": "PASS — symlink no-follow and partial artifact cleanup tests",
            "minimal_etc_and_opt": "PASS — exact generated /etc allowlist and only selected Python/toolchain roots under /opt visible inside task chroot",
            "diagnostic_state_dir": "PASS — doctor writes live reports outside immutable install tree and archive install verifies SHA256SUMS still passes",
            "controller": "PASS — independent workspace parallelism, bounded output, no persistent raw output/argv, secret display redaction and controller-crash child cleanup",
            "syscall_probe": "PASS — CLONE_NEWTIME denied; pthread works; clone3 ENOSYS; io_uring and CLONE_NEWUSER denied",
            "archive": "PASS — CRC, path safety, manifest coverage and SHA-256 verification on extracted archive",
            "archive_install_root_managed": "PASS — exact extracted ZIP install, doctor, immutable manifest preservation, task execution and workspace snapshot/import/restore/re-execution",
            "archive_install_rootless": "PASS FUNCTIONALLY — exact final archive freshly extracted and full flow completed as nobody:nogroup via setpriv, including snapshot/import/restore/re-execution. Automated wrapper test had one intermittent timeout at restore; manual recovery and a separate clean direct run passed.",
            "workspace_snapshot_import": "PASS — canonical no-follow source path, bounded private copy, complete verification, no-overwrite publication, and restore/re-execution in root-managed and rootless install tests",
            "ci_remote": "NOT RUN — no repository remote or authenticated GitHub Actions execution in this environment",
            "independent_security_review": "NOT RUN",
        },
        "known_scope_limits": [
            "No independent Firecracker/KVM VM boundary; outer hosted container remains primary isolation.",
            "No writable per-task cgroup delegation or enforceable aggregate task CPU/memory/pids/io quotas on measured host.",
            "Workspace storage limit is sampled; no hard block/inode quota.",
            "Seccomp remains default-allow deny-list, not audited syscall allowlist.",
            "No Landlock support on measured host.",
            "Task network is disabled; controlled egress proxy, DNS pinning and redirect revalidation are not implemented.",
            "No durable multi-tenant scheduler, API identity service, secret broker, remote snapshot store or distributed storage; v3.3.0 snapshots are local ZIP artifacts only.",
            "No signed release, independent reproducible builder, external penetration test or security certification.",
            "No project-level license selected; public redistribution is not authorized by this artifact.",
            "GitHub Actions workflow is authored but has not been observed running remotely.",
        ],
    })
    write_json(root / "release.json", template)

    # Hash every listed file except the manifest itself, including generated metadata.
    rows = inventory(root, final_paths)
    manifest = "".join(f"{row['sha256']}  {row['path']}\n" for row in rows)
    manifest_path = root / "SHA256SUMS"
    write_bytes_atomic(manifest_path, manifest.encode("utf-8"))

    if output.exists() or output.is_symlink():
        raise FileExistsError(f"refusing to overwrite existing output: {output}")
    deterministic_zip(root, final_paths, output, epoch)
    archive_hash, entry_count = verify_archive(output)
    sidecar = output.with_name(output.name + ".sha256")
    sidecar_fd = os.open(sidecar, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0), 0o644)
    try:
        os.write(sidecar_fd, f"{archive_hash}  {output.name}\n".encode("ascii"))
        os.fsync(sidecar_fd)
    finally:
        os.close(sidecar_fd)
    sidecar_dir = os.open(sidecar.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0))
    try:
        os.fsync(sidecar_dir)
    finally:
        os.close(sidecar_dir)

    result = {"version": version, "output": str(output), "sha256": archive_hash,
              "entries": entry_count, "files_verified": len(final_paths),
              "timestamp": timestamp, "sbom_sha256": sbom_hash,
              "provenance_sha256": provenance_hash}
    if check_reproducible:
        with tempfile.TemporaryDirectory(prefix="aisandbox-repro-") as td:
            second = pathlib.Path(td) / output.name
            deterministic_zip(root, final_paths, second, epoch)
            second_hash = hashlib.sha256(second.read_bytes()).hexdigest()
            result["reproducible_same_environment"] = (second_hash == archive_hash)
            if second_hash != archive_hash:
                raise ValueError("second deterministic ZIP build differs from first")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=pathlib.Path, default=ROOT)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--no-repro-check", action="store_true")
    args = parser.parse_args()
    try:
        result = build(args.root.resolve(strict=True), args.output.absolute(), not args.no_repro_check)
    except Exception as exc:
        parser.exit(1, f"release build failed: {exc}\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
