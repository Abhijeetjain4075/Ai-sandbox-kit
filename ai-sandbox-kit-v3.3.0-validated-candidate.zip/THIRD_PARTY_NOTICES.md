# Third-party notices and runtime dependencies

The ZIP contains the project's own Python, shell, C test and documentation files. It does not vendor or redistribute system libraries or Python/Node scientific packages.

The installer/runtime expects the host distribution to provide and license its own copies of:

- Python 3.10 or newer and its standard library;
- util-linux `unshare` with `--kill-child` support;
- libseccomp (`libseccomp.so.2`);
- libcap (`libcap.so.2`);
- a C library exporting Linux `renameat2(RENAME_NOREPLACE)`;
- GCC or a compatible compiler for the native syscall regression test.

Optional scientific packages (NumPy, SciPy, pandas, scikit-learn, Matplotlib, Pillow, PyTorch, JAX and others) are host-provided and are not installed by the sandbox runner. CI test-only pins are listed in `requirements-ci-science.txt`; their licenses and notices remain those of their upstream distributions.

The operator must comply with the licenses and notices of the host distribution and all separately installed packages. This file is an inventory, not a complete legal determination.
